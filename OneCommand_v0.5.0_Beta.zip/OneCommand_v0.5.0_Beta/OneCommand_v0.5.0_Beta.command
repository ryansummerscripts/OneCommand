#!/bin/bash

# OneCommand
# Version: Beta 0.5.0
# by Ryan Summer
# https://shop.ryansummer.com

# === COLOR DEFINITIONS ===
# making color names the same length helps with alignment in certain cases
BO=$'\033[1m'
GR=$'\033[1;32m'
RE=$'\033[1;31m'
BL=$'\033[1;34m'
YE=$'\033[1;33m'
CY=$'\033[1;36m'
NC=$'\033[0m'

# navigation codes
NAV_BACK=0
NAV_CONT=1
NAV_QUIT=2

return_to_menu=false
interrupted=false

# trap 'echo "outside of main menu"; break' SIGINT

# Global Retry
global_retry() {
    echo
    for i in 3 2 1; do
        echo -ne "\rRetrying in $i... "
        # read one char, timeout after 1s
        read -t 1 -n 1 key

        if [[ $? -eq 0 ]]; then
            # user pressed something - check for nav  
            handle_navigation_input "$key"
            nav=$?
            if   [[ $nav -eq $NAV_QUIT ]]; then 
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                # pop one level: return to caller  
                echo    # clean up newline
                return $NAV_BACK
            else
                # any other key (including Enter) breaks out and retries now  
                echo    # clean up newline
                return $NAV_CONT
            fi
        fi
    done
    # countdown expired, so retry normally
    echo -ne "\r                    \r"  # clear countdown line
    return $NAV_CONT
}

# Global Navigation handler
handle_navigation_input() {
    local choice="$1"
    case "$choice" in
        "q"|"Q"|"quit"|"QUIT"|"exit"|"EXIT")
            # echo
            # echo "${BO}👋 Goodbye!${NC}"
            # sleep 1
            # trap 'echo "quitting and SIGINT"' SIGINT
            return_to_menu=false
            interrupted=false
            return $NAV_QUIT   # signal "quit entire script"
            ;;
        "b"|"B"|"back"|"BACK")
            # trap 'echo "back and SIGINT"' SIGINT
            return_to_menu=false
            interrupted=false
            return $NAV_BACK # signal "pop one level"
            ;;
        *)
            # trap 'echo "continue and SIGINT"' SIGINT
            return_to_menu=false
            interrupted=false
            return $NAV_CONT # no navigation event
            ;;
    esac
}

# Resize Terminal window taller via osascript for 14) ⚙️ MacOS Defaults
function set_terminal_height_to_1200p(){
    osascript <<'EOF'
    tell application "Terminal"
        set b to bounds of front window
        set leftEdge to item 1 of b
        set topEdge to item 2 of b
        set rightEdge to item 3 of b
        set bottomEdge to item 4 of b
        
        -- Keep left/top, keep width same (right - left)
        set newBottomEdge to topEdge + 1200 -- increase height by 1200 pixels (adjust as needed)
        set bounds of front window to {leftEdge, topEdge, rightEdge, newBottomEdge}
    end tell
EOF
}

# Resize Terminal window smaller via osascript for 14) ⚙️ MacOS Defaults
function set_terminal_height_to_512p(){
    osascript <<'EOF'
    tell application "Terminal"
        set b to bounds of front window
        set leftEdge to item 1 of b
        set topEdge to item 2 of b
        set rightEdge to item 3 of b
        set bottomEdge to item 4 of b
        
        -- Keep left/top, keep width same (right - left)
        set newBottomEdge to topEdge + 512 -- set height to 512 pixels (adjust as needed)
        set bounds of front window to {leftEdge, topEdge, rightEdge, newBottomEdge}
    end tell
EOF
}

# Global Navigation menu
show_navigation_prompt() {
    echo
    echo "${BL}Navigation${NC}: ${GR}⮑${NC}  Continue | ${GR}B${NC} Back | ${GR}^C${NC} Interrupt/Exit | ${GR}Q${NC} Main Menu "
    echo 
}

# Function to get menu item by index (simulates array access)
get_menu_item() {
    local index=$1
    case $index in
        0) echo " 1) 🛡️  ${BO}${GR}Remove Quarantine${NC}" ;;
        1) echo " 2) 🧪 ${BO}${GR}Generate SHA256 Hash${NC}" ;;
        2) echo " 3) ✍️  ${BO}${GR}CodeSign${NC}" ;;
        3) echo " 4) 🔐 ${BO}${GR}Change RWX Permissions${NC}" ;;
        4) echo " 5) 👥 ${BO}${GR}Change Owner:Group${NC}" ;;
        5) echo " 6) 🔗 ${BO}${GR}Create Symlink${NC}" ;;
        6) echo " 7) 📦 ${BO}${GR}Batch/Auto-Install .pkg${NC}" ;;
        7) echo " 8) 🚫 ${BO}${GR}Edit/Block '/etc/hosts'${NC}" ;;
        8) echo " 9) 📊 ${BO}${GR}Activity Monitor (Top)${NC}" ;;
        9) echo " 10)📡 ${BO}${GR}Speed Test${NC}" ;;
        10) echo "     11) 🔄 ${BO}${GR}iCloud Sync Refresh${NC}" ;;
        11) echo " 12) ℹ️  ${BO}${GR}System Information${NC}" ;;
        12) echo "    13) 🌐 ${BO}${GR}DNS Utility${NC}" ;;
        13) echo " 14) ⚙️  ${BO}${GR}MacOS Defaults${NC}" ;;
        14) echo " 15) 🍏 ${BO}${GR}Create macOS Installer${NC}" ;;
        15) echo " 16) 💿 ${BO}${GR}Disk Image Utility${NC}" ;;
        16) echo " 17) ⚙️  ${BO}${GR}macOS Diff Tracker${NC}" ;;
        17) echo " 18) 🧼 ${BO}${GR}VM Isolation Check${NC}" ;;
        18) echo " 19) ⏳ ${BO}${GR}Time Machine Utility${NC}" ;;
        19) echo " 20) 📝 ${BO}${GR}OneCommand ChangeLog${NC}" ;;
        # 20) echo " 21)  ${BO}${GR}Empty${NC}" ;;
        # 21) echo " 22)  ${BO}${GR}Empty${NC}" ;;
        # Add more menu items here as needed
        *) echo "" ;;
    esac
}

# Function to get total number of menu items
get_menu_item_count() {
    echo 20  # Update this number when you add more menu items
}

# Simple two-column layout (bash 3.2 compatible)
display_two_column_menu() {
    local num_items=$(get_menu_item_count)
    local mid_point=$(( (num_items + 1) / 2 ))
    
    for ((i=0; i<mid_point; i++)); do
        local left_item=$(get_menu_item $i)
        local right_index=$((i + mid_point))
        local right_item=""
        
        if [[ $right_index -lt $num_items ]]; then
            right_item=$(get_menu_item $right_index)
        fi
        
        # Simple formatting - no calculations, just basic spacing
        printf "%-50s %s\n" "$left_item" "$right_item"
    done
}

# Main Menu function
main_menu() {
    while true; do
        trap - SIGINT
        # return_to_menu=false
        # interrupted=false
        # trap 'echo; echo "Exiting..."; break' SIGINT
        set_terminal_height_to_512p
        clear
        echo "${GR}================${NC}"
        echo "🛠️  ${BO}OneCommand ${NC}🛠️"
        echo "${GR}================${NC}"
        # echo
        # echo "                  [Over 150+ Terminal Commands In One!]"
        show_navigation_prompt        
        echo "${GR}Choose a task:${NC}"
        echo
        display_two_column_menu
        
        # echo
        # echo "^C) 🚪 ${BO}${GR}Exit${NC}"
        echo
        read -rp "➡️  ${GR}Enter your choice (or ${BL}navigation${NC} ${GR}choice)${NC}: " choice
        echo
        handle_navigation_input "$choice"
        nav=$?
        if   [[ $nav -eq $NAV_BACK ]]; then 
            continue
        # elif [[ $nav -eq $NAV_BACK ]]; then 
        #     continue  # back to main menu
        fi
        case $choice in
            1) remove_quarantine ;;
            2) generate_sha256 ;;
            3) codesign_files ;;
            4) change_rwx_permissions ;;
            5) change_owner_group ;;
            6) create_symlink ;;
            7) install_pkg_batch ;;
            8) edit_hosts ;;
            9) top_activity_monitor ;;
            10) speed_test ;;
            11) icloud_sync_refresh ;;
            12) system_information ;;
            13) dns_utility ;;
            14) macos_defaults ;;
            15) create_macos_installer ;;
            16) disk_image_utility ;;
            17) macos_diff_tracker ;;
            18) vm_isolation_check ;;
            19) time_machine_utility ;;
            20) change_log ;;
            # 21) NEW ;;
            # 9) 
            #     echo
            # "q"|"Q")  
            #     echo "${BO}👋 Goodbye!${NC}"
            #     sleep 1
            #     break $NAV_QUIT
            #     ;;
            *) 
                echo -ne "❌ ${RE}Invalid choice.${NC} Please try again. "
                sleep 1
                # echo -ne "\r\033[K"  # Clears the line after countdown finishes
                continue
                # read 
                ;;
        esac
    done

    # This should never be reached, but cleanup just in case
    # eval "$FUNCTION_ORIGINAL_TRAP" 2>/dev/null || trap - SIGINT
}

# TRAPS WORK
#====1==== 🛡️ remove_quarantine
function remove_quarantine() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 1"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=======================${NC}"
        echo "${BO}1) 🛡️  Remove Quarantine${NC}"
        echo "${GR}=======================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "➡️  ${GR}Please drag and drop one or more files/folders into this terminal window,${NC}"
        echo "   ${GR}then press Enter: ${NC}"
        echo
        read -rp "" input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            break
        fi

        # Process input to handle escaped spaces and quoted paths
        eval "set -- $input"

        local path_count=$#
        local files_found=()
        local files_to_process=()
        local processed_count=0
        local processed_failed=0
        local processed_skipped=0
        # local interrupted=false  # Add flag to track interruption        

        if [ "$path_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
        fi

        # Extensions to target
        local bundle_exts=("component" "vst" "vst3" "app" "bundle")
        local file_exts=("pkg" "dmg" "sh" "command")

        # Process each input item
        for item in "$@"; do
            if [ -e "$item" ]; then
                if [ -f "$item" ]; then
                    files_found+=("$item") # count files found
                    files_to_process+=("$item") # add files to process cue
                elif [ -d "$item" ]; then
                    echo
                    for ext in "${bundle_exts[@]}"; do
                        while IFS= read -r -d '' match; do
                            files_found+=("$match")
                            files_to_process+=("$match")
                            echo "🔄 ${GR}Prepping ${CY}[DIR]${NC}: ${NC} $(basename "$match")"
                        done < <(find "$item" -maxdepth 1 -type d -iname "*.$ext" -print0)
                    done

                    # File-based items (e.g. .pkg, .dmg, .sh)
                    for ext in "${file_exts[@]}"; do
                        while IFS= read -r -d '' match; do
                            files_found+=("$match")
                            files_to_process+=("$match")
                            echo "🔄 ${GR}Prepping ${CY}[FILE]${NC}: ${NC} $(basename "$match")"
                        done < <(find "$item" -maxdepth 1 -type f -iname "*.$ext" -print0)
                    done

                    # Add any other regular files at top level (e.g. binaries, no extension)
                    while IFS= read -r -d '' nomatch; do
                        if [[ ! " ${files_found[*]} " =~ " $nomatch " ]]; then
                            files_found+=("$nomatch")  # Count, but don't sign
                            ((processed_skipped++)) # Include in "failed" summary
                            # echo "⚠️  Skipping unsupported file: $match"
                            echo "⚠️  ${YE}Skipping ${CY}[FILE]${NC}: ${NC} $(basename "$nomatch")"
                        fi
                    done < <(find "$item" -maxdepth 1 -type f -print0)

                    # prevent the Contents folder within bundles from being shown as Skipped
                    while IFS= read -r -d '' nomatch; do
                        skip_nested=false
                        for bundle in "${files_to_process[@]}"; do
                            [[ "$nomatch" == "$bundle" ]] && continue
                            if [[ "$nomatch" == "$bundle/"* ]]; then
                                skip_nested=true
                                break
                            fi
                        done
                        if [[ "$skip_nested" = false && ! " ${files_found[*]} " =~ " $nomatch " ]]; then
                            files_found+=("$nomatch")
                            ((processed_skipped++)) # add to skipped counter
                            echo "⚠️  ${YE}Skipping ${CY}[DIR]${NC}: ${NC} $(basename "$nomatch")"
                        fi
                    done < <(find "$item" -maxdepth 1 -type d -print0)
                fi
            else
                echo "❌ ${RE}Skipping invalid path: $item${NC}"
            fi
        done

        # check if there are valid items to process
        if [ "${#files_to_process[@]}" -eq 0 ]; then
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        # Set up trap to handle Ctrl+C during loop

        # Iterate over files/bundles in cue to be processed
        for filepath in "${files_to_process[@]}"; do
            # remove path from filename to be displayed
            filename=$(basename "$filepath")

            # echo each filename
            for item in "${filepath[@]}"; do
                echo
                echo "🔄 ${BO}Processing: ${NC}$filename"
            done  

            # trap 'echo "trapping for sudo in func 1"' SIGINT
            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            sudo xattr -rd com.apple.quarantine "$filepath" 2>/dev/null # Remove quarantine flag
            
            # if last command succeeded
            if [ $? -eq 0 ]; then
                echo "✅ ${GR}Done:       ${NC}$filename"
                ((processed_count++)) # add to processed counter
                # echo
            else
                echo "❌ ${RE}Failed:     ${NC}$filename"
                ((processed_failed++)) # add to failed counter
                # echo
                # continue
            fi
        done

        # Clear the local processing trap and restore function-level trap
        # trap 'echo "FUNC_1_SIGINT"' SIGINT # - SIGINT

        echo
        echo "============================"
        echo "${BO}Results:${NC}"
        echo "🛤️  Total paths found:     $path_count"
        echo "📊 Total files found:     ${#files_found[@]}"
        echo "✅ Total files ${GR}processed${NC}: $processed_count"
        echo "⚠️  Total items ${RE}skipped${NC}:   $((processed_failed + processed_skipped))  (${processed_failed} failed, ${processed_skipped} skipped)"
        echo "============================"
        show_navigation_prompt # already padded

        return_to_menu=true
        interrupted=false

        # trap 'echo; echo "Returning to main menu..."; return_to_menu=true; break' SIGINT
        trap 'echo; echo "returning from func 1"; return' SIGINT
        # return_to_menu=false
        # interrupted=false

        read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
        
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            continue # back to upload
        else [[ $nav -eq $NAV_CONT ]]
            continue # back to main menu
        fi   
    done
}

#====2==== 🧪 generate_sha256
function generate_sha256() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 2"; return_to_menu=true; return' SIGINT
        set_terminal_height_to_512p
        clear
        echo "${GR}==========================${NC}"
        echo "${BO}2) 🧪 Generate SHA256 Hash${NC}"
        echo "${GR}==========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "➡️  ${GR}Please drag and drop one or more files/folders into this terminal window,${NC}"
        echo "   ${GR}then press Enter: ${NC}"
        echo

        read -rp "" input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break
        fi

        # Process input to handle escaped spaces and quoted paths
        eval "set -- $input"

        # Initialize Counters
        local input_count=$#
        local files_to_process=()
        local processed_count=0
        local processed_failed=0

        if [ "$input_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        # Define bundle extensions that should be treated as single units
        local bundle_extensions=("app" "bundle" "framework" "component" "vst" "vst3" "plugin" "kext")

        # Function to check if a directory is a bundle
        is_bundle() {
            local path="$1"
            for ext in "${bundle_extensions[@]}"; do
                if [[ "$path" == *."$ext" ]]; then
                    return 0  # true
                fi
            done
            return 1  # false
        }

        # Process each input item to build the list of files to hash
        for item in "$@"; do
            if [ -f "$item" ]; then
                # Regular file - add to processing list
                files_to_process+=("$item")
            elif [ -d "$item" ] && is_bundle "$item"; then
                # Bundle directory (.app, .bundle, etc.) - treat as single unit
                files_to_process+=("$item")
            elif [ -d "$item" ]; then
                # Regular directory - scan contents for hashable files
                echo "📂 ${CY}Directory detected:${NC} $(basename "$item")"
                echo "   ${CY}Scanning for files and bundles...${NC}"
                
                # Find regular files (not inside bundles)
                while IFS= read -r -d '' file; do
                    files_to_process+=("$file")
                done < <(find "$item" -type f -print0)
                
                # Find bundle directories
                for ext in "${bundle_extensions[@]}"; do
                    while IFS= read -r -d '' bundle; do
                        files_to_process+=("$bundle")
                    done < <(find "$item" -type d -name "*.$ext" -print0)
                done
            else

                echo "❌ ${RE}Skipping invalid path:${NC} $item"
                ((processed_failed++))
            fi
        done

        if [ "${#files_to_process[@]}" -eq 0 ]; then
            echo "❌ ${RE}No valid files or bundles found to process.${NC}"
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        echo
        echo "📊 ${BO}Found ${#files_to_process[@]} item(s) to hash${NC}"

        # Hash each file or bundle
        for file in "${files_to_process[@]}"; do

            filename="$(basename "$file")"

            echo
            echo -e "🔍 ${BO}Hashing:${NC} ${GR}$filename${NC}"
            
            # Set up trap for Ctrl+C
            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            if [ -f "$file" ]; then
                # Regular file
                bytes=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file")
                size_mb=$(awk "BEGIN {printf \"%.2f\", $bytes/1024/1024}")
                size="${size_mb} MB"
                start=$(gdate +%s%3N 2>/dev/null || date +%s)
                hash=$(shasum -a 256 "$file" | awk '{print $1}')
                end=$(gdate +%s%3N 2>/dev/null || date +%s)
                duration=$((end - start))
                echo -e "📦 ${BO}Size:${NC}    ${GR}$size${NC}"
                echo -e "🔐 ${BO}SHA256:${NC}  ${GR}$hash${NC}"
                echo -e "⏱️  ${BO}Took:${NC}    ${GR}${duration}ms${NC}"
                ((processed_count++))
            elif [ -d "$file" ] && [[ "$file" == *.app ]]; then
                # .app bundle - hash the main executable
                exec_path="$file/Contents/MacOS/$(ls "$file/Contents/MacOS" | head -n1)"
                if [ -f "$exec_path" ]; then
                    exec_name="$(basename "$exec_path")"
                    bytes=$(stat -f%z "$exec_path" 2>/dev/null || stat -c%s "$exec_path")
                    size_mb=$(awk "BEGIN {printf \"%.2f\", $bytes/1024/1024}")
                    size="${size_mb} MB"
                    start=$(gdate +%s%3N 2>/dev/null || date +%s)
                    hash=$(shasum -a 256 "$exec_path" | awk '{print $1}')
                    end=$(gdate +%s%3N 2>/dev/null || date +%s)
                    duration=$((end - start))
                    echo -e "📦 ${BO}Size:${NC}    ${GR}$size${NC}"
                    echo -e "🔐 ${BO}SHA256:${NC}  ${GR}$hash${NC}"
                    echo -e "⏱️  ${BO}Took:${NC}    ${GR}${duration}ms${NC}"
                    ((processed_count++))
                else
                    echo -e "❌ ${RE}Skipped:${NC} No binary found inside $filename"
                    ((processed_failed++))
                fi
            # elif [ -d "$file" ] && is_bundle "$file"; then
                case "${file##*.}" in
                    "vst"|"vst3")
                        # VST plugins typically have their binary in Contents/MacOS/ (like .app)
                        if [ -d "$file/Contents/MacOS" ]; then
                            exec_file="$file/Contents/MacOS/$(ls "$file/Contents/MacOS" | head -n1)"
                        else
                            # Some VSTs have the binary at the root level
                            exec_file=$(find "$file" -name "*.dylib" -o -name "*.so" | head -n1)
                        fi
                        ;;
                    "component")
                        # Audio Unit components usually in Contents/MacOS/
                        exec_file="$file/Contents/MacOS/$(ls "$file/Contents/MacOS" 2>/dev/null | head -n1)"
                        ;;
                    "bundle")
                        # Generic bundles - look for main executable or dylib
                        if [ -d "$file/Contents/MacOS" ]; then
                            exec_file="$file/Contents/MacOS/$(ls "$file/Contents/MacOS" | head -n1)"
                        else
                            exec_file=$(find "$file" -name "*.dylib" -o -type f -perm +111 | head -n1)
                        fi
                        ;;
                    "framework")
                        # Frameworks have their main binary at the framework root
                        framework_name=$(basename "$file" .framework)
                        exec_file="$file/$framework_name"
                        ;;
                    "kext")
                        # Kernel extensions have their binary in Contents/MacOS/
                        exec_file="$file/Contents/MacOS/$(ls "$file/Contents/MacOS" 2>/dev/null | head -n1)"
                        ;;
                    *)
                        # Fallback to finding first executable
                        exec_file=$(find "$file" -type f -perm +111 | head -n1)
                        ;;
                esac
            elif [ -d "$file" ] && is_bundle "$file"; then
                # Other bundle types - you might want to add specific logic for each type
                # For now, we'll look for the first executable file in the bundle
                exec_file=$(find "$file" -type f -perm +111 | head -n1)
                if [ -f "$exec_file" ]; then
                    bytes=$(stat -f%z "$exec_file" 2>/dev/null || stat -c%s "$exec_file")
                    size_mb=$(awk "BEGIN {printf \"%.2f\", $bytes/1024/1024}")
                    size="${size_mb} MB"
                    start=$(gdate +%s%3N 2>/dev/null || date +%s)
                    hash=$(shasum -a 256 "$exec_file" | awk '{print $1}')
                    end=$(gdate +%s%3N 2>/dev/null || date +%s)
                    duration=$((end - start))
                    echo -e "📦 ${BO}Size:${NC}    ${GR}$size${NC}"
                    echo -e "🧪 ${BO}SHA256:${NC}  ${GR}$hash${NC}"
                    echo -e "⏱️  ${BO}Took:${NC}    ${GR}${duration}ms${NC}"
                    ((processed_count++))
                else
                    echo -e "❌ ${RE}Skipped:${NC} No executable found inside $filename"
                    ((processed_failed++))
                fi
            else
                echo -e "❌ ${RE}Skipped:${NC} $filename is not a valid file or supported bundle."
                ((processed_failed++))
            fi
        done

        echo
        echo "========================="
        echo "${BO}Results:${NC}"
        echo "📁 Total items found:  $input_count"
        echo "🧪 Total items ${GR}hashed${NC}: $processed_count"
        echo "⚠️  Total items ${RE}failed${NC}: $processed_failed"
        echo "========================="
        echo
        echo "${BO}Let's hash it out next time${NC} ✌️"
        show_navigation_prompt # already padded

        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 2"; return' SIGINT

        read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            continue
        else [[ $nav -eq $NAV_CONT ]]
            continue
        fi   
    done
    set_terminal_height_to_512p
}

#====3==== ✍️ codesign_files
function codesign_files() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 3"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}==============${NC}"
        echo "${BO}3) ✍️  Codesign${NC}"
        echo "${GR}==============${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "➡️  ${GR}Please drag and drop one or more files/folders into this terminal window,${NC}"
        echo "   ${GR}then press Enter: ${NC}"
        echo
        read -rp "" input
        
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            break
        fi   

        # Process input to handle escaped spaces and quoted paths
        eval "set -- $input"

        local files_found=()
        local files_to_process=()
        local processed_count=0
        local processed_failed=0
        local processed_skipped=0
        local path_count=$#
        # local interrupted=false  # Add flag to track interruption        

        if [ "$path_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        # Extensions to target
        local bundle_exts=("component" "vst" "vst3" "app" "bundle")
        local file_exts=("pkg" "dmg" "sh" "command")

        # files_to_process=()
        # Process each input item
        for item in "$@"; do
            if [ -e "$item" ]; then
                if [ -f "$item" ]; then
                    files_found+=("$item") # count files found
                    files_to_process+=("$item") # add files to process cue
                elif [ -d "$item" ]; then
                    echo
                    echo "📂 ${CY}Folder or bundle detected. Scanning for eligible files...${NC}"
                    # echo "📁 Scanning ${CY}[DIR]${NC}: ${CY}$(basename "$item")${NC}"
                    # echo "📁 Provided ${CY}[DIR]${NC}:  ${CY}$(basename "$item")${NC}"
                    echo
                    # Bundle-like directories (e.g. .component, .vst, vst3, .app .bundle)
                    for ext in "${bundle_exts[@]}"; do
                        while IFS= read -r -d '' match; do
                            files_found+=("$match")
                            files_to_process+=("$match")
                            echo "🔄 ${GR}Prepping ${CY}[DIR]${NC}: ${NC} $(basename "$match")"
                        done < <(find "$item" -maxdepth 1 -type d -iname "*.$ext" -print0)
                    done

                    # File-based items (e.g. .pkg, .dmg, .sh)
                    for ext in "${file_exts[@]}"; do
                        while IFS= read -r -d '' match; do
                            files_found+=("$match")
                            files_to_process+=("$match")
                            echo "🔄 ${GR}Prepping ${CY}[FILE]${NC}: ${NC} $(basename "$match")"
                        done < <(find "$item" -maxdepth 1 -type f -iname "*.$ext" -print0)
                    done

                    # Add any other regular files at top level (e.g. binaries, no extension)
                    while IFS= read -r -d '' nomatch; do
                        if [[ ! " ${files_found[*]} " =~ " $nomatch " ]]; then
                            files_found+=("$nomatch")  # Count, but don't sign
                            ((processed_skipped++)) # Include in "failed" summary
                            # echo "⚠️  Skipping unsupported file: $match"
                            echo "⚠️  ${YE}Skipping ${CY}[FILE]${NC}: ${NC} $(basename "$nomatch")"
                        fi
                    done < <(find "$item" -maxdepth 1 -type f -print0)

                    # prevent the Contents folder within bundles from being shown as Skipped
                    while IFS= read -r -d '' nomatch; do
                        skip_nested=false
                        for bundle in "${files_to_process[@]}"; do
                            [[ "$nomatch" == "$bundle" ]] && continue
                            if [[ "$nomatch" == "$bundle/"* ]]; then
                                skip_nested=true
                                break
                            fi
                        done
                        if [[ "$skip_nested" = false && ! " ${files_found[*]} " =~ " $nomatch " ]]; then
                            files_found+=("$nomatch")
                            ((processed_skipped++)) # add to skipped counter
                            echo "⚠️  ${YE}Skipping ${CY}[DIR]${NC}: ${NC} $(basename "$nomatch")"
                        fi
                    done < <(find "$item" -maxdepth 1 -type d -print0)

                    # echo
                fi
            else
                echo
                echo "❌ ${RE}Skipping invalid path: $item${NC}"
            fi
        done

        if [ "${#files_to_process[@]}" -eq 0 ]; then
            # echo
            echo "❌ ${RE}No valid files or bundles found to process.${NC}"
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        # Iterate over files/bundles in cue to be processed
        for filepath in "${files_to_process[@]}"; do
            
            # Check if we've been interrupted
            # if [ "$interrupted" = true ]; then
            #     echo "1. interrupted = true"
            #     break
            # fi

            # remove path from filename to be displayed
            filename=$(basename "$filepath")
            # echo
            # echo "🔄 ${BO}Processing: $filename${NC}"
            # echo

            # Set up trap to handle Ctrl+C during codesigning loop
            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            sudo xattr -cr "$filepath" 2>/dev/null # Clear extended attributes 
            
            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            sudo xattr -rd com.apple.quarantine "$filepath" 2>/dev/null # Remove quarantine flag

            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            sudo codesign --force --deep --sign - "$filepath" 2>/dev/null # Code sign with ad-hoc identity

            # if last command succeeded
            if [ $? -eq 0 ]; then
                echo "✅ ${GR}Signed:${NC} $filename"
                ((processed_count++)) # add to processed counter
            else
                echo "❌ ${RE}Failed to sign:${NC} $filename"
                ((processed_failed++)) # add to failed counter
            fi
        done

        # Final Summary
        echo
        echo "============================"
        echo "${BO}Results:${NC}"
        echo "🛤️  Total paths found:     $path_count"
        echo "📊 Total files found:     ${#files_found[@]}"
        echo "✅ Total files ${GR}processed${NC}: ${BO}$processed_count${NC}"
        echo "⚠️  Total items ${RE}skipped${NC}:   $((processed_failed + processed_skipped))  (${processed_failed} failed, ${processed_skipped} skipped)"
        echo "============================"        
        show_navigation_prompt # already padded
        
        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 3"; return' SIGINT        

        read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
        
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            continue
        else [[ $nav -eq $NAV_CONT ]]
            continue
        fi   
    done
}

#====4==== 🔐 change_rwx_permissions
function change_rwx_permissions() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 4"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}============================${NC}"
        echo "${BO}4) 🔐 Change RWX Permissions${NC}"
        echo "${GR}============================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "➡️  ${GR}Please drag and drop one or more files/folders into this terminal window,${NC}"
        echo "   ${GR}then press Enter: ${NC}"
        echo
        read -rp "" input

        # Handle navigation
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break
        fi

        # Process input to handle escaped spaces and quoted paths
        eval "set -- $input"

        local input_count=$#
        local files_to_process=()
        local processed_count=0

        if [ "$input_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            sleep 1
            continue # Restart file selection
        fi

        # FILE SELECTION BLOCK
        # Process each input item
        for item in "$@"; do
            if [ -d "$item" ]; then
                filename=$(basename "$item")
                echo "📁 ${CY}Directory/Bundle detected:${NC} $filename"
                echo "🔄 ${YE}Scanning top-level contents only...${NC}"
                
                # Find only top-level items (maxdepth 1)
                while IFS= read -r -d '' top_level_item; do
                    # Exclude .DS_Store
                    if [[ "$(basename "$top_level_item")" != ".DS_Store" ]]; then
                        files_to_process+=("$top_level_item")
                    fi
                done < <(find "$item" -maxdepth 1 -mindepth 1 -print0)

            elif [ -e "$item" ]; then
                # Exclude .DS_Store at top level too
                if [[ "$(basename "$item")" != ".DS_Store" ]]; then
                    files_to_process+=("$item")
                    # ((processed_skipped++)) # add to skipped counter
                fi
            else
                echo
                echo "❌ ${RE}Invalid path.${NC}"
                # echo "$item"
                sleep 1
            fi
        done

        # check if there are valid items to process
        if [ "${#files_to_process[@]}" -eq 0 ]; then
            echo "Please try again."
            sleep 1
            continue  # Restart file selection
        fi

        # Function to convert numeric chmod to symbolic format
        format_numeric_permissions() {
            local num_mode="$1"
            local symbolic=""
            
            # Handle 4-digit modes (like 0755) by taking last 3 digits
            if [[ ${#num_mode} -eq 4 ]]; then
                num_mode="${num_mode:1}"
            fi
            
            # Convert each digit to rwx format
            for i in {0..2}; do
                digit="${num_mode:$i:1}"
                case $digit in
                    0) symbolic="${symbolic}---" ;;
                    1) symbolic="${symbolic}--x" ;;
                    2) symbolic="${symbolic}-w-" ;;
                    3) symbolic="${symbolic}-wx" ;;
                    4) symbolic="${symbolic}r--" ;;
                    5) symbolic="${symbolic}r-x" ;;
                    6) symbolic="${symbolic}rw-" ;;
                    7) symbolic="${symbolic}rwx" ;;
                esac
            done
            
            # Format as usr|grp|all
            echo "${symbolic:0:3}|${symbolic:3:3}|${symbolic:6:3}"
        }

        # PERMISSION SELECTION BLOCK
        local mode=""
        while true; do                
            clear
            echo "${GR}======================${NC}"
            echo "${BO}Choose RWX Permissions${NC}"
            echo "${GR}======================${NC}"
            echo "↩️  Change RWX Permissions"
            show_navigation_prompt # already padded
            echo "${GR} Current permissions | Items to be processed${NC}"
            
            # Iterate over files/bundles in cue to be processed & list current permissions
            for item in "${files_to_process[@]}"; do                   
                if [ -e "$item" ]; then
                    perms_sym_raw=$(stat -f "%Sp" "$item") # Symbolic permissions e.g. -rwxr-xr-x
                    perms_num=$(stat -f "%A" "$item") # Numeric (octal) permissions e.g. 755
                    perms_sym_fmt="${perms_sym_raw:1:3}|${perms_sym_raw:4:3}|${perms_sym_raw:7:3}" # formatted
                    item_type=" ${GR}[FILE]${NC}"
                    if [ -d "$item" ]; then
                        item_type=" ${CY}[DIR]${NC}"
                    fi
                    echo -e "   $perms_sym_fmt ($perms_num) | $(basename "$item")${item_type}"
                fi
            done

            echo
            echo "🔐 ${GR}Choose new permissions to apply:${NC}"
            echo "${BL}   usr|grp|all${NC}"
            echo "1) rwx|r-x|r-x (755) — typical for executables/bundles"
            echo "2) rw-|r--|r-- (644) — typical for config/text files"
            echo "3) rwx|---|--- (700) — owner-only access"
            echo "4) rwx|rwx|rwx (777) — open to all (⚠️  unsafe)"
            echo "5) Custom (enter manually)"

            # show_navigation_prompt # already padded
            echo
            read -p "${GR}Enter choice [1-5] (or ${BL}navigation${NC} ${GR}choice):${NC} " choice

            # Handle navigation in permission selection
            handle_navigation_input "$choice"
            nav=$?
            if   [[ $nav -eq $NAV_QUIT ]]; then 
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then 
                continue 2   # pop back to file-selection (loop 1)
            fi

            # Map selection to actual values
            case $choice in
                1) mode="755" ;;
                2) mode="644" ;;
                3) mode="700" ;;
                4) mode="777" ;;
                5)
                    # custom-perms sub-loop (loop level 3)
                    while true; do
                        echo
                        read -p "${GR}Enter custom numeric chmod value (e.g. 600):${NC} " mode

                        handle_navigation_input "$mode"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            continue 2  # back to file selection
                        fi

                        if [[ "$mode" =~ ^[0-7]{3,4}$ ]]; then
                            break  # Break out of both loops
                        else
                            echo "❌ ${RE}Invalid chmod value.${NC}"
                            echo "   Must be 3-4 octal digits (0-7)."
                            sleep 2
                            continue 2
                        fi
                    done
                    ;;
                *) 
                    echo "❌ ${RE}Invalid choice.${NC}"
                    # global_retry # "Invalid menu choice - please select 1-5"
                    sleep 1
                    continue # Stay in perms selection loop
                    ;;
            esac

            # RECURSIVE OPTION BLOCK (Nested Loop 3)
            while true; do
                local chmod_flags=""
                chosen_mode=$(format_numeric_permissions "$mode")
                clear
                echo "${GR}=====================${NC}"
                echo "${BO}Set Recursive Options${NC}"
                echo "${GR}=====================${NC}"
                echo "↩️  Choose RWX Permissions"

                show_navigation_prompt # already padded

                echo " ${GR}Current permissions | Items to be processed${NC}"
                echo -e "   $perms_sym_fmt ($perms_num) | $(basename "$item")${item_type}"
                echo
                echo "🔐 ${GR}Chosen permissions to apply:${NC}"
                echo "${BL}   usr|grp|all${NC}"
                echo -e "   $chosen_mode ($mode) | $(basename "$item")${item_type}"
                echo
                echo "🔄 ${GR}Apply recursively?${NC}"
                echo "   ${YE}Note: Only use recursive for bundles that${NC}"
                echo "   ${YE}need internal file permissions changed${NC}"
                echo
                echo "1) No  - Apply to items only (recommended)"
                echo "2) Yes - Apply recursively (-R flag)"
                echo
                read -p "${GR}Enter choice [1-2] (or ${BL}navigation${NC} ${GR}choice):${NC} " recursive_choice

                handle_navigation_input "$recursive_choice"
                nav=$?
                if   [[ $nav -eq $NAV_QUIT ]]; then 
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then 
                    break
                fi

                case $recursive_choice in
                    1) chmod_flags="" ;;
                    2) chmod_flags="-R" ;;
                    *) 
                        echo "❌ ${RE}Invalid choice.${NC} Please select 1 or 2."
                        sleep 1
                        continue
                        ;;
                esac

                # CONFIRMATION BLOCK
                local recursive_text=""
                if [ -n "$chmod_flags" ]; then
                    recursive_text=" (recursively)"
                fi
                    
                while true; do
                    # EXECUTION BLOCK
                    local processed_failed=0
                    for item in "${files_to_process[@]}"; do

                        # if there's anything to process...
                        if [ -e "$item" ]; then
                            local display_name=$(basename "$item")
                            local item_type="${GR}[FILE]${NC}"
                            
                            if [ -d "$item" ]; then
                                item_type="${CY}[DIR]${NC}"
                            fi

                            # Set up trap for Ctrl+C
                            return_to_menu=false
                            interrupted=false
                            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

                            sudo chmod $chmod_flags "$mode" "$item" 2>/dev/null

                            # if last command succeeded
                            if [ $? -eq 0 ]; then
                                echo "✅ chmod $chmod_flags ${GR}$mode${NC} $display_name $item_type"
                                ((processed_count++)) # add to processed counter
                            else
                                echo "❌ ${RE}Failed to chmod: $display_name $item_type"
                                ((processed_failed++)) # add to failed counter
                                
                            fi
                        fi
                    done
        
                    # SUMMARY
                    echo
                    echo "============================"
                    echo "${BO}Results:${NC}"
                    echo "🛣️  Total paths found:     $input_count"
                    echo "✅ Total files ${GR}processed${NC}: $processed_count"
                    echo "⚠️  Total items ${RE}failed${NC}:    $processed_failed"
                    echo "============================"        
                    show_navigation_prompt # already padded

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 1"; return' SIGINT

                    read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice):${NC} " input
                    
                    handle_navigation_input "$input"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break 2 # back to choose file
                    else [[ $nav -eq $NAV_CONT ]]
                        break 3 # back to main menu
                    fi
                done
            done
        done
    done
}

#====5==== 👥 change_owner_group
function change_owner_group() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 5"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}========================${NC}"
        echo "${BO}5) 👥 Change Owner:Group${NC}"
        echo "${GR}========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "➡️  ${GR}Please drag and drop one or more files/folders into this terminal window,${NC}"
        echo "   ${GR}then press Enter: ${NC}"
        echo
        read -rp "" input

        # Handle navigation
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            return 0
        fi

        # Process input to handle escaped spaces and quoted paths
        eval "set -- $input"

        # Initialize Counters
        local input_count=$#
        local files_to_process=()
        local processed_count=0

        if [ "$input_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            echo "   Please try again."
            sleep 1
            continue # Restart file selection
        fi

        # FILE SELECTION BLOCK
        # Process each input item
        for item in "$@"; do
            if [ -d "$item" ]; then
                filename=$(basename "$item")
                echo "📁 ${CY}Directory/Bundle detected:${NC} $filename"
                echo "🔄 ${YE}Scanning top-level contents only...${NC}"
                
                # Find only top-level items (maxdepth 1)
                while IFS= read -r -d '' top_level_item; do
                    # Exclude .DS_Store
                    if [[ "$(basename "$top_level_item")" != ".DS_Store" ]]; then
                        files_to_process+=("$top_level_item")
                    fi
                done < <(find "$item" -maxdepth 1 -mindepth 1 -print0)

            elif [ -e "$item" ]; then
                # Exclude .DS_Store at top level too
                if [[ "$(basename "$item")" != ".DS_Store" ]]; then
                    files_to_process+=("$item")
                    # ((processed_skipped++)) # add to skipped counter
                fi
            else
                echo "❌ ${RE}Invalid path: ${NC}"
                # echo "'$item'"
            fi
        done

        # check if there are valid items to process
        if [ "${#files_to_process[@]}" -eq 0 ]; then
            echo "Please try again."
            sleep 1
            continue # Restart file selection
        fi

        while true; do
            clear
            echo "${GR}==================${NC}"
            echo "${BO}Choose Owner:Group${NC}"
            echo "${GR}==================${NC}"
            echo "↩️  Change Owner:Group"

            show_navigation_prompt # already padded

            echo " ${GR}Current ownership | Items to be processed${NC}"
            
            # get current file ownership stats, format it and specify whether a directory
            for item in "${files_to_process[@]}"; do

                if [ -e "$item" ]; then
                    owner=$(stat -f "%Su" "$item")  # File owner (user)
                    group=$(stat -f "%Sg" "$item")  # File group
                    item_type="${GR}[FILE]${NC}"
                    if [ -d "$item" ]; then
                        item_type="${CY}[DIR]${NC}"
                    fi
                    echo -e "   $owner:$group | $(basename "$item") ${item_type}"
                fi
            done

            # Get currently logged-in user
            local REAL_USER
            REAL_USER=$(stat -f "%Su" /dev/console)
            
            # Input Validation - Validate owner:group format and existence
            validate_owner_group() {
                local owner_group="$1"
                local user="${owner_group%:*}"
                local group="${owner_group#*:}"
                
                # Check if user exists
                if ! id "$user" >/dev/null 2>&1; then
                    echo "❌ ${RE}USER '$user' does not exist${NC}"
                    echo "Please provde a valid USER."
                    sleep 2
                    continue 2
                fi
                
                # Check if group exists (macOS compatible)
                if ! dscl . -read /Groups/"$group" >/dev/null 2>&1; then
                    echo "❌ ${RE}GROUP '$group' does not exist${NC}"
                    echo "Please provde a valid GROUP."
                    sleep 2
                    continue 2
                fi
                
                # break
            }

            # Owner-Selection (Nested Loop 2)
            local OWNER=""
            
            echo
            echo "👥 ${GR}Choose new owner:group to apply:${NC}"
            echo "   ${BL}user:group${NC}"
            echo "1) $REAL_USER:staff"
            echo "2) $REAL_USER:admin"
            echo "3) root:wheel"
            echo "4) root:admin"
            echo "5) Custom (enter manually)"

            # show_navigation_prompt # already padded
            echo
            read -p "${GR}Enter choice [1-6] (or ${BL}navigation${NC} ${GR}choice):${NC} " choice

            # Handle navigation in ownership selection
            handle_navigation_input "$choice"
            nav=$?
            if   [[ $nav -eq $NAV_QUIT ]]; then 
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then 
                break
            fi

            OWNER="" # reset flag
            # Map selection to actual values
            case "$choice" in
                1) OWNER="$REAL_USER:staff";;
                2) OWNER="$REAL_USER:admin" ;;
                3) OWNER="root:wheel" ;;
                4) OWNER="root:admin" ;;
                5) 
                    # custom-owner sub-loop (loop level 3)
                    while true; do
                        echo
                        read -p "${GR}Enter custom owner:group (e.g., user:group):${NC} " OWNER

                        handle_navigation_input "$OWNER"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            continue 2
                        fi
                        
                        if validate_owner_group "$OWNER"; then
                            break
                        else
                            echo "❌ ${RE}Invalid chown value.${NC}"
                            sleep 1
                            continue
                        fi
                    done
                    ;;
                *) 
                    # echo
                    echo "❌ ${RE}Invalid selection.${NC}"
                    sleep 1
                    continue # Stay in owner selection loop
                    ;;
            esac

            # If we didn't pick a valid OWNER, loop again
            [[ -z "$OWNER" ]] && continue

            # RECURSIVE OPTION BLOCK (Nested Loop 3)
            while true; do
                local chown_flags=""
                echo
                clear
                echo "${GR}=====================${NC}"
                echo "${BO}Set Recursive Options${NC}"
                echo "${GR}=====================${NC}"
                echo "↩️  Choose Owner:Group"

                show_navigation_prompt # already padded

                echo " ${GR}Current ownership | Items to be processed${NC}"
                echo -e "   $owner:$group | $(basename "$item") ${item_type}"
                echo
                echo "👥 ${GR}Chosen owner:group to apply:${NC}"
                echo "   ${BL}user:group${NC}"
                echo -e "   $OWNER | $(basename "$item") ${item_type}"
                echo
                echo "🔄 ${GR}Apply recursively?${NC}"
                echo "   ${YE}Note: Only use recursive for bundles that${NC}"
                echo "   ${YE}need internal file ownership changed${NC}"
                echo
                echo "1) No  - Apply to items only (recommended)"
                echo "2) Yes - Apply recursively (-R flag)"
                echo
                read -p "${GR}Enter choice [1-2] (or ${BL}navigation${NC} ${GR}choice):${NC} " recursive_choice

                handle_navigation_input "$recursive_choice"
                nav=$?
                if   [[ $nav -eq $NAV_QUIT ]]; then 
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then 
                    break
                fi
                
                case $recursive_choice in
                    1) chown_flags="" ;;
                    2) chown_flags="-R" ;;
                    *)  
                        echo "❌ ${RE}Invalid choice.${NC} Please select 1 or 2."
                        sleep 1
                        continue 
                        ;;
                esac

                while true; do
                    # EXECUTION BLOCK
                    local processed_failed=0
                    for item in "${files_to_process[@]}"; do

                        # if there's anything to process...
                        if [ -e "$item" ]; then
                            local display_name=$(basename "$item")
                            local item_type="${GR}[FILE]${NC}"
                            
                            if [ -d "$item" ]; then
                                item_type="${CY}[DIR]${NC}"
                            fi
                            
                            # Set up trap for Ctrl+C
                            return_to_menu=false
                            interrupted=false
                            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

                            sudo chown $chown_flags "$OWNER" "$item" 2>/dev/null

                            # if last command succeeded
                            if [ $? -eq 0 ]; then
                                echo "✅ chown $chown_flags ${GR}$OWNER${NC} $display_name $item_type"
                                ((processed_count++)) # add to processed counter
                            else
                                echo "❌ ${RE}Failed to chown:${NC} $display_name $item_type"
                                ((processed_failed++)) # add to failed counter
                            fi
                        fi
                    done

                    # SUMMARY
                    echo
                    echo "============================"  
                    echo "${BO}Results:${NC}"
                    echo "🛣️  Total paths found:     $input_count"
                    echo "✅ Total files ${GR}processed${NC}: $processed_count"
                    echo "⚠️  Total items ${RE}failed${NC}:    $processed_failed"
                    echo "============================"  
                    show_navigation_prompt # already padded

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 1"; return' SIGINT

                    read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice):${NC} " input
                    
                    handle_navigation_input "$input"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break 2 # back to main menu
                    else [[ $nav -eq $NAV_CONT ]]
                        break 3 # back to main menu
                    fi   
                done
            done    
        done 
    done
}

#====6==== 🔗 create_symlink
function create_symlink() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 6"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=======================${NC}"
        echo "${BO}6) 🔗 Create Symlink(s)${NC}"
        echo "${GR}=======================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        # Step 1: Prompt for Source files
        echo "📂 ${BO}Step 1 of 2:${NC}"
        echo "${GR}Please drag and drop one or more"
        echo "SOURCE files/folders onto this terminal window,"
        echo "then press Enter:${NC}"
        echo
        read -rp "" input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break
        fi

        # Process input to handle escaped spaces and special characters
        eval "set -- $input"

        # Initialize Counters
        local input_count=$#
        local files_found=()
        local paths_to_process=()
        #local symlink_count=0
        local processed_count=0
        local processed_failed=0
        local processed_skipped=0

        if [ "$input_count" -eq 0 ]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            sleep 1
            echo "Please drag and drop valid files and try again."
            sleep 1
            continue
        fi

        # Validate Source Paths
        for source in "$@"; do
            if [ -e "$source" ]; then
                # sfilename=$(basename "$source")
                paths_to_process+=("$source")
                #((symlink_count++))
            else    
                echo "❌ ${RE}Invalid source path: $source${NC}"
            fi
        done
        if [ "${#paths_to_process[@]}" -eq 0 ]; then
            echo "Please drag and drop valid files and try again."
            global_retry
            continue
        fi

        # Destination Directory Selection (Nested Loop 2)
        while true; do
            show_navigation_prompt # already padded
            # Step 2: Prompt for Destination folder
            echo "📁 ${BO}Step 2 of 2:${NC}"
            echo "${GR}Drop the DESTINATION folder here,"
            echo "then press Enter:${NC}"
            echo
            read -rp "" dest_input

            handle_navigation_input "$dest_input"
            nav=$?
            if   [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                continue 2   # pop back to main menu
            fi
            
            while true; do
                # Process and validate the destination path
                destination="$(eval echo "$dest_input")"
                
                if [ ! -d "$destination" ]; then
                    xfilename=$(basename "$destination")
                    # echo
                    echo "❌ ${RE}Destination is not a valid directory:${NC}"
                    # echo "$xfilename"
                    global_retry
                    nav=$?
                    if [[ $nav -eq $NAV_BACK ]]; then
                        return 0
                    fi
                    continue 2
                fi

                while true; do
                    # Create symlinks
                    for source in "${paths_to_process[@]}"; do

                        # Check if we've been interrupted before processing
                        # if [ "$interrupted" = true ]; then
                        #     break 4
                        # fi

                        sfilename=$(basename "$source")
                        dfilename=$(basename "$destination")
                        # echo
                        # echo "🔗 ${BO}${GR}sudo ln -s${NC} $sfilename... → ${CY}$dfilename${NC}"
                        # echo
                        # echo "$sfilename... → ${CY}$dfilename${NC}"
                        # echo

                        return_to_menu=false
                        interrupted=false
                        trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

                        sudo ln -s "$source" "$destination/$basename" 2>/dev/null

                        if [ $? -eq 0 ]; then
                            # echo
                            # echo "✅ ${BO}Done.${NC}"
                            echo "🔗 ${GR}sudo ln -s${NC} $sfilename → ${CY}$dfilename${NC}"
                            ((processed_count++)) # add to processed counter
                        else
                            # echo
                            echo "❌ ${RE}Failed to create symlink(s).${NC}"
                            ((processed_failed++)) # add to failed counter
                        fi
                        # Check for interruption after updating counters
                        # if [ "$interrupted" = true ]; then
                        #     break 4  # Break out of all loops to reach summary
                        # fi 
                    done
                    # If we completed all symlinks without interruption, break out
                    break 3 # Break out to summary
                done

                break 2 # This should never be reached due to break 3 above
            done   
        done     

                # break

        # Final summary
        echo
        echo "============================"  
        echo "${BO}Results:${NC}"
        echo "🛣️  Total paths found:     ${NC}$input_count"
        echo "🔗 Total links ${GR}processed${NC}: $processed_count"
        echo "⚠️  Total items ${RE}failed${NC}:    $processed_failed"
        echo "============================"  
        echo
        echo "${BO}Let's link later${NC} 🦾" 
        show_navigation_prompt # already padded

        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 1"; return' SIGINT

        read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
        
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            continue # back to main menu
        else [[ $nav -eq $NAV_CONT ]]
            continue # back to main menu
        fi   
    done
}

#====7==== 📦 install_pkg_batch
function install_pkg_batch() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 7"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=============================${NC}"
        echo "${BO}7) 📦 Batch/Auto-Install .pkg${NC}"
        echo "${GR}=============================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        echo "ℹ️  Usage: Please drag and drop one of the following, then press enter:"
        echo
        echo "- 📁 ${GR}A folder containing .pkg files ${NC}"
        echo "- 📦 ${GR}Individual .pkg files ${NC}"
        echo
        read -rp "" input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            return 0   # pop back to main menu
        fi

        # Process input to handle escaped spaces and special characters
        eval "set -- $input"

        # Initialize installation counter
        local input_count=$#
        local files_to_process=()
        # local installed_count=0
        local processed_count=0
        local processed_failed=0
        local processed_skipped=0

        if [[ $input_count -eq 0 ]]; then
            echo "❌ ${RE}No valid input provided.${NC}"
            echo "Please drag and drop valid files and try again."
            global_retry # Restart file selection
            continue
        fi

        # trap 'interrupted=true; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary...";' SIGINT

        # Process each input item to build files_to_process array
        for item in "$@"; do
            if [ -d "$item" ]; then
                # Directory detected - scan for .pkg files
                local folder_name=$(basename "$item")
                echo "📁 ${BL}Directory detected:${NC} $folder_name"
                echo "🔄 ${YE}Scanning for .pkg files...${NC}"
                
                local original_pwd="$(pwd)"
                if cd "$item"; then
                    local found_pkgs=false
                    for pkg in *.pkg; do
                        if [ -f "$pkg" ]; then
                            files_to_process+=("$item/$pkg")
                            found_pkgs=true
                        fi
                    done
                    
                    if [ "$found_pkgs" = false ]; then
                        echo "⚠️  ${YE}No .pkg files found in directory${NC}"
                    fi
                    cd "$original_pwd"
                else
                    echo "❌ ${RE}Failed to access directory: $folder_name${NC}"
                    ((processed_skipped++))
                fi
                
            elif [ -f "$item" ] && [[ "$item" == *.pkg ]]; then
                # Valid .pkg file
                files_to_process+=("$item")
                
            elif [ -f "$item" ]; then
                # File exists but not a .pkg
                local filename=$(basename "$item")
                echo "⚠️  ${YE}Skipping non-.pkg file: $filename${NC}"
                ((processed_skipped++))
                
            else
                # Item doesn't exist
                local filename=$(basename "$item")
                echo "❌ ${RE}Item not found: $filename${NC}"
                ((processed_skipped++))
            fi
        done

        # Check if we have any files to process
        if [ "${#files_to_process[@]}" -eq 0 ]; then
            # echo
            echo "❌ No valid .pkg files to process"
            global_retry
            continue
        fi

        # Show what will be processed
        echo
        echo "${GR}Found ${#files_to_process[@]} .pkg(s) to install:${NC}"
        for pkg_file in "${files_to_process[@]}"; do
            local filename=$(basename "$pkg_file")
            echo "📦 $filename"
        done

        # Process all .pkg files
        echo
        echo "🔄 ${GR}Installing .pkg files...${NC}"
        echo
        
        local current_file=1
        local total_files=${#files_to_process[@]}

        for pkg_file in "${files_to_process[@]}"; do
            # Check for interruption
            # if [ "$interrupted" = true ]; then
            #     # trap 'interrupted=true; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary...";' SIGINT
            #     echo "🛑 ${RE}Processing interrupted${NC}"; SIGINT
            #     break
            # fi
            
            local filename=$(basename "$pkg_file")
            echo "[$current_file/$total_files] 🔄 ${GR}Installing: ${NC}$filename..."
            
            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC} Showing summary..."; interrupted=true; break' SIGINT

            # Install the package
            if sudo installer -pkg "$pkg_file" -target /; then
                echo "✅ ${GR}Successfully installed: $filename${NC}"
                ((processed_count++))
            else
                echo "❌ ${RE}Failed to install: $filename${NC}"
                ((processed_failed++))
            fi
            
            ((current_file++))
            # echo
        done

        # Final summary
        local total_attempted=$((processed_count + processed_failed))
        echo
        echo "============================"
        echo "${BO}Results:${NC}"
        echo "🛣️  Total paths found:     $input_count"
        echo "📦 Total .pkgs ${GR}installed${NC}: $processed_count"
        echo "⚠️  Total .pkgs ${RE}failed${NC}:    $processed_failed"
        echo "⚠️  Total items ${RE}skipped${NC}:   $processed_skipped"
        if [ $total_attempted -gt 0 ]; then
            local success_rate=$(( (processed_count * 100) / total_attempted ))
            echo "📈 Success rate:          ${success_rate}%"
        fi
        echo "============================"
        echo
        echo "${BO}Until next time${NC} ✌️"
        show_navigation_prompt # already padded

        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 7"; return' SIGINT

        read -rp "➡️  ${GR}Process another file? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
        
        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            continue # back to main menu
        else [[ $nav -eq $NAV_CONT ]]
            continue # back to main menu
        fi   
    done
}

#====8==== 🚫 Edit/Block Hosts
function edit_hosts() { 
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 8"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=============================${NC}"
        echo "${BO}8) 🚫 Edit/Block '/etc/hosts'${NC}"
        echo "${GR}=============================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded

        while true; do
            echo "🚫 ${GR}Opening /etc/hosts for editing...${NC}"
            echo
            echo "Tip: Arrow Keys = Navigate | ^O = WriteOut | Enter = Save | ^X = Exit"
            echo

            return_to_menu=false
            interrupted=false
            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

            # Check if nano is available, fallback to vim or vi
            if command -v nano &> /dev/null; then
                sudo nano /etc/hosts
                echo
                echo "✅ ${GR}Done!${NC}"
                break 1
            elif command -v vim &> /dev/null; then
                sudo vim /etc/hosts
                echo
                echo "✅ ${GR}Done!${NC}"
                break 1
            elif command -v vi &> /dev/null; then
                sudo vi /etc/hosts
                echo
                echo "✅ ${GR}Done!${NC}"
                break 1
            else
                error_exit "No suitable text editor found (nano, vim, or vi)"
                global_retry
                break 1
            fi
        done

        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 8"; return' SIGINT
        
        echo
        read -rp "➡️  ${GR}Need to check your work? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input

        handle_navigation_input "$input"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            break # back to main menu
        else [[ $nav -eq $NAV_CONT ]]
            continue # continue
        fi   


    done
}

#====9==== 📊 Activity Monitor (Top)
function top_activity_monitor() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 9"; return_to_menu=true; return' SIGINT
        set_terminal_height_to_512p
        clear
        echo "${GR}=============================${NC}"
        echo "${BO}9) 📊 Activity Monitor (Top)${NC}"
        echo "${GR}=============================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded

        echo "🔄 ${GR}Starting Activity Monitor...${NC}"
        echo
        echo "Tip: q = Quit | ? = Help | Space = Force Update"
        echo "     o = Sort Options; (then type: -cpu, -mem, etc.)"
        echo "     s = Set Update Interval; (then type: 1, 2, 3, etc.)"
        echo

        echo "${GR}Press Enter to start Activity Monitor (or ${BL}navigation${NC} ${GR}choice${NC}): "
        read -rp "" input
        handle_navigation_input "$input"
        nav=$?
        if [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            return 1  # back to main menu
        fi
        
        return_to_menu=false
        interrupted=false
        trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

    # Inner loop: keep re-running top until user chooses "back" or "quit"
    # while true; do
        if [[ "$OSTYPE" == "darwin"* ]]; then
            set_terminal_height_to_1200p
            top -o cpu -s 2
            # break 1
        else
            set_terminal_height_to_1200p
            top -d 2
            # break 1
        fi
        
        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 1"; return' SIGINT

    # done
    done
    # set_terminal_height_to_512p
}
# TRAPS WORK
#====10==== 📡 Speed Test
function speed_test() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 10"; return_to_menu=true; return' SIGINT
        # set_terminal_height_to_512p
        clear        
        echo "${GR}=================${NC}"
        echo "${BO}10) 📡 Speed Test${NC}"
        echo "${GR}=================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        
        # Check if networkquality exists first
        if ! command -v networkquality &> /dev/null; then
            echo "❌ ${RE}networkquality command not found!${NC}"
            echo "   This requires macOS 12 (Monterey) or later"
            echo
            for i in 3 2 1; do
                echo -ne "\r${GR}🚪 Returning to Main Menu in $i...${NC} "
                # read one char, timeout after 1s
                read -t 1 -n 1 key

                if [[ $? -eq 0 ]]; then
                    # user pressed something - check for nav  
                    handle_navigation_input "$key"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        echo
                        return $NAV_BACK
                    else
                        echo
                        return $NAV_CONT
                    fi
                fi
            done
            # countdown expired, so retry normally
            echo -ne "\r                    \r"  # clear countdown line
            return $NAV_CONT
        fi
        
        echo "Choose test type:"
        echo
        echo "1) ${GR}Standard${NC}     -  Clean summary output"
        echo "2) ${GR}Verbose${NC}      -  Detailed test output"
        echo "3) ${GR}Config Only${NC}  -  Show network configuration"
        echo
       
       while true; do
            read -rp "➡️  ${GR}Select option ${NC}[1-3]: " choice
            
            case $choice in
                1)  # Default option (Enter key or 1)
                    clear
                    echo "${GR}========================${NC}"
                    echo "${BO}1) 📡 Speed Test (Standard)${NC}"
                    echo "${GR}========================${NC}"
                    echo "↩️  Speed Test"
                    echo "${BL}Navigation${NC}: ${GR}^C${NC} to interrupt test"
                    echo
                    echo "📡 ${GR}Testing network quality...${NC}"
                    echo "⏱️  ${YE}This may take 10-20 seconds...${NC}"
                    echo
                    
                    interrupted=false
                    trap 'interrupted=true; echo; kill $networkquality_pid 2>/dev/null' SIGINT
                    
                    # Run networkquality in background and capture its PID
                    networkquality &
                    networkquality_pid=$!
                    
                    # Wait for networkquality to complete or be interrupted
                    if wait $networkquality_pid 2>/dev/null; then
                        # Command completed normally
                        echo
                        echo "✅ ${GR}Done!${NC}"
                        return_to_menu=true
                        interrupted=false
                        trap 'echo; echo "returning from func 10"; return' SIGINT

                    else
                        # Command was interrupted or failed
                        trap 'echo; echo "returning from func 10"; return' SIGINT
                        if [ "$interrupted" = true ]; then
                            echo
                            echo "🛑 ${RE}Test interrupted by user.${NC}"
                            interrupted=false
                        fi
                    fi
                    break
                    ;;
                2)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}==========================${NC}"
                    echo "${BO}2) 📡 Speed Test (Verbose)${NC}"
                    echo "${GR}==========================${NC}"
                    echo "↩️  Speed Test"
                    echo "${BL}Navigation${NC}: ${GR}^C${NC} to interrupt test"
                    echo
                    echo "📡 ${GR}Testing network quality...${NC}"
                    echo "⏱️  ${YE}This may take 10-30 seconds...${NC}"
                    echo
                    
                    interrupted=false
                    trap 'interrupted=true; kill $networkquality_pid 2>/dev/null' SIGINT
                    
                    # Run networkquality in background and capture its PID
                    networkquality -v &
                    networkquality_pid=$!
                    
                    # Wait for networkquality to complete or be interrupted
                    if wait $networkquality_pid 2>/dev/null; then
                        # Command completed normally
                        echo
                        echo "✅ ${GR}Done!${NC}"

                        return_to_menu=true
                        interrupted=false
                        trap 'echo; echo "returning from func 10"; return' SIGINT
                    else
                        # Command was interrupted or failed
                        trap 'echo; echo "returning from func 10"; return' SIGINT
                        if [ "$interrupted" = true ]; then
                            echo
                            echo "🛑 ${RE}Test interrupted by user.${NC}"
                            interrupted=false  # Reset the flag
                        fi
                    fi
                    break
                    ;;
                3)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}===========================${NC}"
                    echo "${BO}3) 🔧 Network Configuration${NC}"
                    echo "${GR}===========================${NC}"
                    echo "↩️  Speed Test"
                    show_navigation_prompt # already padded
                    echo "📡 ${GR}Showing network configuration...${NC}"
                    echo "⏱️  ${YE}This may take 10-20 seconds...${NC}"
                    echo
                    
                    interrupted=false
                    trap 'interrupted=true; kill $networkquality_pid 2>/dev/null' SIGINT
                    
                    # Run networkquality in background and capture its PID
                    networkquality -c &
                    networkquality_pid=$!
                    
                    # Wait for networkquality to complete or be interrupted
                    if wait $networkquality_pid 2>/dev/null; then
                        # Command completed normally
                        echo
                        echo "✅ ${GR}Done!${NC}"
                        return_to_menu=true
                        interrupted=false
                        trap 'echo; echo "returning from func 10"; return' SIGINT
                    else
                        # Command was interrupted or failed
                        trap 'echo; echo "returning from func 10"; return' SIGINT
                        if [ "$interrupted" = true ]; then
                            echo
                            echo "🛑 ${RE}Test interrupted by user.${NC}"
                            interrupted=false
                        fi
                    fi
                    break
                    ;;
                *)
                    handle_navigation_input "$choice"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        return
                    fi
                    echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
                    sleep 1
                    continue 2
                    ;;
            esac
        done

        # Post-test handling
        # while true; do   
            # echo
            # echo "✅ ${GR}Finished${NC}"
        
        # Post-test handling
        while true; do
            show_navigation_prompt # already padded

            return_to_menu=true
            interrupted=false
            trap 'echo; echo "returning from func 10"; return' SIGINT

            read -rp "➡️  ${GR}Run another test? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
            handle_navigation_input "$input"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                set_terminal_height_to_512p
                break
            else
                set_terminal_height_to_512p
                break
            fi
        done
    done
}
# TRAPS WORK
#====11==== 🔄 iCloud Sync Refresh
function icloud_sync_refresh() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 11"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}==========================${NC}"
        echo "${BO}11) 🔄 iCloud Sync Refresh${NC}"
        echo "${GR}==========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        
        echo "🔄 ${GR}Starting iCloud Sync Refresh...${NC}"
        echo
        echo "ℹ️  ${YE}This will restart the iCloud daemon (cloudd)${NC}"
        echo "   • iCloud sync will pause briefly and then resume"
        echo "   • May help resolve sync issues or stuck uploads"
        echo "   • All iCloud services will be affected momentarily"
        echo
        
        while true; do
            read -rp "➡️  ${GR}Refresh iCloud sync? (y/N)${NC}: " confirm

            # handle_navigation_input "$input"
            # nav=$?
            # if [[ $nav -eq $NAV_QUIT ]]; then
            #     return 0
            # elif [[ $nav -eq $NAV_BACK ]]; then
            #     return
            # fi

            case $confirm in
                [Yy]|[Yy][Ee][Ss])
                    echo
                    echo "☁️  ${GR}Restarting iCloud daemon...${NC}"
                    
                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    # Kill the cloudd processes
                    # they will restart automatically - regarless of internet connection
                    killall cloudd
                    
                    echo "✅ ${GR}iCloud daemon restarted${NC}"
                    echo "   Sync processes will resume automatically."
                    # sleep 1
                    # echo
                    # echo "✅ ${GR}Done!${NC}"
                    # sleep 1
                    break
                    ;;

                [Nn]|[Nn][Oo])
                    echo
                    echo "❌ ${YE}iCloud refresh cancelled${NC}"
                    # sleep 1
                    break
                    ;;
                *)
                    handle_navigation_input "$confirm"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break 2 # back to main menu
                    fi
                    echo "❌ ${RE}Please enter y/yes or n/no${NC}"
                    # global_retry
                    sleep 1
                    continue 2
                    ;;
            esac
        done
        while true; do
            show_navigation_prompt # already padded

        return_to_menu=true
        interrupted=false
        trap 'echo; echo "returning from func 11"; return' SIGINT

            read -rp "➡️  ${GR}Return to main menu? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
            handle_navigation_input "$input"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                break # back to main menu
            else
                break 2 # run again
            fi
        done
    done
}
# TRAPS WORK
#====12==== 🖥️ System Information
function system_information() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 12"; return_to_menu=true; return' SIGINT
        set_terminal_height_to_512p
        clear
        echo "${GR}=========================${NC}"
        echo "${BO}12) 🖥️  System Information${NC}"
        echo "${GR}=========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        
        echo "Choose information to be displayed:"
        echo "1) ${GR}System Profile Overview${NC}  Hardware, Software, Users"
        echo "2) ${GR}Hardware Summary${NC} ....... Model, CPU, Memory, Serial"
        echo "3) ${GR}Software Summary${NC} ....... macOS Version, Kernel, Uptime"
        echo "4) ${GR}Network Interfaces${NC} ..... Network hardware and config"
        echo "5) ${GR}USB Devices${NC} ............ Connected USB devices"
        echo "6) ${GR}Storage Devices${NC} ........ Disks and storage info"
        echo "7) ${GR}User Account Details${NC} ... Current user and system users"
        echo
        
        while true; do
            read -rp "➡️  ${GR}Select option (1-6) (or ${BL}navigation${NC} ${GR}choice${NC}): " choice
            
            case $choice in
                1)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}=============================${NC}"
                    echo "${BO}1) 📋 System Profile Overview${NC}"
                    echo "${GR}=============================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering complete system information...${NC}"
                    # echo "⏱️  This may take a few seconds..."
                    # echo
                    system_profiler SPHardwareDataType SPSoftwareDataType
                    echo "${BO}👤 User Account Details${NC}"
                    echo
                    echo "📊 ${GR}Current User Information:${NC}"
                    echo "${BO}Username:${NC} $(whoami)"
                    echo "${BO}UID:${NC}      $(id -u)"
                    echo "${BO}GID:${NC}      $(id -g)"
                    echo "${BO}Groups:${NC}   $(id -Gn)"
                    echo
                    echo "📋 ${GR}All System Users (UID 500+):${NC}"
                    dscl . -list /Users UniqueID | awk '$2 >= 500 {print "User: " $1 " | UID: " $2}' | sort -k4 -n
                    echo
                    echo "🔍 ${GR}Currently Logged In Users:${NC}"
                    w | tail -n +3 | awk '{print "User: " $1 " | UID: " $2 " | Login: " $4 " | From: " $3}'
                    echo
                    break
                    ;;
                2)
                    clear
                    echo "${GR}======================${NC}"
                    echo "${BO}2) 🖥️  Hardware Summary${NC}"
                    echo "${GR}======================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering hardware information...${NC}"
                    # echo
                    system_profiler SPHardwareDataType
                    break
                    ;;
                3)
                    clear
                    echo "${GR}======================${NC}"
                    echo "${BO}3) 💿 Software Summary${NC}"
                    echo "${GR}======================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering software information...${NC}"
                    # echo
                    system_profiler SPSoftwareDataType
                    break
                    ;;
                4)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}========================${NC}"
                    echo "${BO}4) 🌐 Network Interfaces${NC}"
                    echo "${GR}========================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering network information...${NC}"
                    # echo
                    system_profiler SPNetworkDataType
                    break
                    ;;
                5)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}=================${NC}"
                    echo "${BO}5) 🔌 USB Devices${NC}"
                    echo "${GR}=================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering USB device information...${NC}"
                    # echo
                    system_profiler SPUSBDataType
                    break
                    ;;
                6)
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}=====================${NC}"
                    echo "${BO}6) 💾 Storage Devices${NC}"
                    echo "${GR}=====================${NC}"
                    echo "↩️  System Information"
                    echo
                    # echo "📊 ${GR}Gathering storage information...${NC}"
                    # echo
                    system_profiler SPStorageDataType SPSerialATADataType
                    break
                    ;;
                7)
                    # set_terminal_height_to_1200p
                    clear
                    echo "${GR}==========================${NC}"
                    echo "${BO}7) 👤 User Account Details${NC}"
                    echo "${GR}==========================${NC}"
                    echo "↩️  System Information"
                    echo
                    echo "📊 ${GR}Current User Information:${NC}"
                    echo "${BO}Username:${NC} $(whoami)"
                    echo "${BO}UID:${NC}      $(id -u)"
                    echo "${BO}GID:${NC}      $(id -g)"
                    echo "${BO}Groups:${NC}   $(id -Gn)"
                    echo
                    echo "📋 ${GR}All System Users (UID 500+):${NC}"
                    dscl . -list /Users UniqueID | awk '$2 >= 500 {print "User: " $1 " | UID: " $2}' | sort -k4 -n
                    echo
                    echo "🔍 ${GR}Currently Logged In Users:${NC}"
                    w | tail -n +3 | awk '{print "User: " $1 " | UID: " $2 " | Login: " $4 " | From: " $3}'
                    echo
                    break
                    ;;
                *)
                    handle_navigation_input "$choice"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break 2
                    fi
                    echo "❌ ${RE}Invalid option. Please choose 1-6.${NC}"
                    sleep 1
                    continue 2
                    ;;
            esac
        done     
        while true; do
            trimmed_output="$(show_navigation_prompt)"
            # Remove leading/trailing empty lines
            echo "$trimmed_output" | sed -e '1{/^$/d;}' -e '${/^$/d;}'
            echo
            # show_navigation_prompt # already padded

            return_to_menu=true
            interrupted=false
            trap 'echo; echo "returning from func 12"; return' SIGINT

            read -rp "➡️  ${GR}Choose another option? Press Enter (or ${BL}navigation${NC} ${GR}choice${NC}): " input
            handle_navigation_input "$input"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                break
            else
                break
            fi
        done
    done
    set_terminal_height_to_512p
}

#====13==== 🌐 DNS Utility
function dns_utility() {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 13"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}==================${NC}"
        echo "${BO}13) 🌐 DNS Utility${NC}"
        echo "${GR}==================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt # already padded
        
        echo "Choose DNS operation:"
        echo "1) ${GR}Clear DNS Cache${NC}     - Flush all cached DNS entries"
        echo "2) ${GR}Show DNS Settings${NC}   - Display current DNS servers"
        echo "3) ${GR}Test DNS Resolution${NC} - Test specific domain lookup"
        echo
        read -rp "➡️  ${GR}Select option (1-3)${NC}: " choice
        while true; do            
            case $choice in
                1)
                    echo
                    echo "🌐 Clear DNS cache..."
                    echo
                    read -rp "➡️  ${GR}Continue? (y/N)${NC}: " confirm
                    handle_navigation_input "$confirm"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        continue 2
                    fi

                    case $confirm in
                        [Yy]|[Yy][Ee][Ss])
                            echo
                            echo "🔄 Flushing DNS cache..."

                            return_to_menu=false
                            interrupted=false
                            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                            sudo dscacheutil -flushcache
                            echo "🔄 Restarting DNS responder..."
                            sudo killall -HUP mDNSResponder
                            echo "✅ Done"
                            break
                            ;;
                        [Nn]|[Nn][Oo])
                            echo
                            echo "❌ ${YE}Operation cancelled${NC}"
                            sleep 1
                            continue 2
                            ;;
                        *)
                            echo "❌ ${RE}Please enter y/yes or n/no${NC}"
                            sleep 1
                            continue
                            ;;
                    esac
                    # break
                    ;;
                2)
                    echo
                    echo "🔍 ${GR}Displaying current DNS settings${NC}:"
                    echo
                    scutil --dns | grep 'nameserver\[[0-9]*\]'
                    break
                    ;;
                3)
                    echo
                    while true; do
                        read -rp "➡️  ${GR}Enter domain to test (e.g., google.com)${NC}: " domain
                        
                        # Check navigation input FIRST
                        handle_navigation_input "$domain"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            continue 3 # break out of option selection loop
                        fi

                        if [[ -n "$domain" ]]; then
                            echo
                            echo "🔍 ${GR}Testing DNS resolution for${NC}: $domain"
                            echo
                            nslookup "$domain"
                            break
                        else
                            handle_navigation_input "$domain"
                            nav=$?
                            if [[ $nav -eq $NAV_QUIT ]]; then
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then
                                break 2 # break out of option selection loop
                            fi
                            echo "❌ ${RE}Please enter a domain name${NC}"
                            sleep 1
                            continue
                        fi
                    done
                    break
                    ;;
                *)
                    handle_navigation_input "$choice"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        return 1 # back to main menu
                    fi
                    echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
                    sleep 1
                    continue 2
                    ;;
            esac
        done
        
        # Post-execution handling
        while true; do
            # echo "✅ ${GR}Done!${NC}"
            echo

            return_to_menu=true
            interrupted=false
            trap 'echo; echo "returning from func 13"; return' SIGINT
            
            read -rp "➡️  ${GR}Run another DNS operation? Press Enter (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
            handle_navigation_input "$input"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                break # back to main menu
            else # [[ $nav -eq $NAV_CONT ]]
                break # restart operation selection
            fi
        done
    done
}

#====14==== ⚙️ MacOS Defaults
function macos_defaults() {
    return_to_menu=true
    trap 'echo; echo "Returning to main menu...from func 14"; return_to_menu=true; return' SIGINT
    set_terminal_height_to_1200p
    # Define preference commands with their active/inactive/reset actions
    declare -a preference_commands=(

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🆕 [NEW for macOS Sonoma 14 - Sequoia 15]|"
        "🚫 Dock: Disable 'click walpaper to show Desktop' (Sonoma 14+)|com.apple.WindowManager|EnableStandardClickToShowDesktop|false|true|true||"
        "🚫 Dock: Disable 'Drag windows to screen edges to tile' (Sequoia 15+)|com.apple.WindowManager|EnableTilingByEdgeDrag|false|true|true|delete|"
        "🚫 Dock: Disable 'Drag windows to menu bar to fill screen' (Sequoia 15+)|com.apple.WindowManager|EnableTopTilingByEdgeDrag|false|true|true|delete|"
        "🪟 Dock: Enable 'Hold ⌥ key while dragging windows to tile' (Sequoia 15+)|com.apple.WindowManager|EnableTilingOptionAccelerator|true|false|true|delete|"
        "🚫 Dock: Disable 'Tiled windows have margins' (Sequoia 15+)|com.apple.WindowManager|EnableTiledWindowMargins|false|true|true|delete|"
        "🔑 Passwords: Show Passwords In The Menu Bar (Sequoia 15+) [Please enable manually]|com.apple.Passwords|EnableMenuBarExtra|true|false|false|PasswordManager|Shows the Passwords sub-menu icon in the menu bar"
        "🚫 Apple AI: Disable Apple Intelligence|com.apple.CloudSubscriptionFeatures.optIn|Dynamic (check with 'defaults read com.apple.CloudSubscriptionFeatures.optIn')|false|true|false|disable_Apple_Intelligence|Disables Apple Intelligence"
        "🕵️‍♂️  Spotlight: Disable 'Help Apple Improve Search'|com.apple.assistant.support|Search Queries Data Sharing Status|2|1|ture|delete|Disables 'Help Apple Improve Search'"
        "♿️ Accessibility: Zoomed Image While Screen Sharing|com.apple.universalaccess|closeViewZoomScreenShareEnabledKey|true|false|false|delete|Enables showing zoomed image while screen sharing"
        "🔎 Accessibility: Zoom Each Display Independently|com.apple.universalaccess|closeViewZoomIndividualDisplays|true|false|false|delete|Zooms each display independently"
        "⚡️ Energy: Show Low Power Mode in Menu Bar|com.apple.controlcenter|EnergyModeModule|9|19|19|-currentHost|Shows Low Power Mode control in the menu bar"
        "🚫 Finder: Hide Warning before removing from iCloud Drive (Sequoia 15+)|com.apple.bird|com.apple.clouddocs.unshared.moveOut.suppress|1|0||delete|Disables the 'Remove from iCloud Drive' warning."

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|♿️ [Accessibility]|⚠️  ${YE}(Terminal requires Full Disk Access to write changes)${NC}"
        "🔎 Enable Zoom Hot Keys|com.apple.universalaccess|closeViewHotkeysEnabled|true|false|false|delete|Enables global zoom functionality via hot keys"
        "🔎 Zoom Continuously with Pointer|com.apple.universalaccess|closeViewPanningMode|false|true|false|false|Zooms continuously with pointer"
        "🔎 Zoom Always Follows Keyboard Focus|com.apple.universalaccess|closeViewZoomFocusFollowModeKey|1|2|2|delete|Zoom always follows keyboard focus when typing"
        "🔎 Keyboard Focus Centers Screen Image|com.apple.universalaccess|closeViewZoomFocusMovement|false|true|true|delete|Keyboard focus centers screen image"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|⚓️ [Dock]|"
        "🗑️  Wipe all app icons from Dock ${BO}(for fresh installs)${NC}|com.apple.dock|persistent-apps|-array|||delete|Removes all default app icons from the Dock."
        "👻 Dim Dock Icons of Hidden Apps|com.apple.dock|showhidden|true|false||delete|Makes hidden app icons appear dimmed in the Dock"
        "🫥 Auto-hide the Dock when the mouse is out|com.apple.dock|autohide|true|false||delete|Automatically hides the Dock when the cursor leaves the Dock area"
        "⚡ Make the dock appear faster ${BO}(Initial Auto-hide must be enabled)${NC}|com.apple.dock|autohide-time-modifier|0.0|0.5||delete|Make the dock appear faster (when auto-hide is active)"
        "⚡ Make the dock disappear faster ${BO}(Initial Auto-hide must be enabled)${NC}|com.apple.dock|autohide-delay|0|0.2|0.2|0.2|Make the dock disappear faster (when auto-hide is active)"
        "⚡ Minimize windows using Scale effect instead of Genie|com.apple.dock|mineffect|scale|genie||delete|Changes minimize animation from Genie to Scale effect"
        "📥 Minimize windows into their application icon|com.apple.dock|minimize-to-application|true|false||delete|Minimizes windows into their app icon instead of separate dock tile"
        "🚫 Disable Recent Items in Dock|com.apple.dock|show-recents|false|true||delete|Hides recent items from the Dock"
        "🚫 Speed Up Drag and Drop Spring Delay on Dock items|com.apple.dock|enable-spring-load-actions-on-all-items|false|true|true|true|Speeds up drag and drop spring delay on dock items."
        "⚪️ Show indicator lights for open apps (depreciated)|com.apple.dock|show-process-indicators|true|false||delete|Shows dots under open applications in the Dock"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        # "GROUP|🖥️  [Desktop & Other Icon Views]|"
        # "⚙️  Set Custom Icon Views: Info/Labels/Arrange/Text/Icon/Grid|~/Library/Preferences/com.apple.finder.plist|PLISTBUDDY|Set :DesktopViewSettings:IconViewSettings:showItemInfo true|||-|plistbuddy|Applies multiple icon-view settings"
        # "⚙️  Set Custom Icon Views: Batch Apply|~/Library/Preferences/com.apple.finder.plist|PLISTBUDDY|'Set :DesktopViewSettings:IconViewSettings:showItemInfo true||Set :FK_StandardViewSettings:IconViewSettings:showItemInfo true||Set :StandardViewSettings:IconViewSettings:showItemInfo true||Set :DesktopViewSettings:IconViewSettings:labelOnBottom true||Set :FK_StandardViewSettings:IconViewSettings:labelOnBottom true||Set :StandardViewSettings:IconViewSettings:labelOnBottom true||Set :DesktopViewSettings:IconViewSettings:arrangeBy name||Set :FK_StandardViewSettings:IconViewSettings:arrangeBy name||Set :StandardViewSettings:IconViewSettings:arrangeBy name||Set :DesktopViewSettings:IconViewSettings:textSize 14||Set :FK_StandardViewSettings:IconViewSettings:textSize 12||Set :StandardViewSettings:IconViewSettings:textSize 12||Set :DesktopViewSettings:IconViewSettings:iconSize 72||Set :FK_StandardViewSettings:IconViewSettings:iconSize 64||Set :StandardViewSettings:IconViewSettings:iconSize 72||Set :DesktopViewSettings:IconViewSettings:gridSpacing 71||Set :FK_StandardViewSettings:IconViewSettings:gridSpacing 54||Set :StandardViewSettings:IconViewSettings:gridSpacing 71'||||plistbuddy|Desktop and icon-view layout"


        # "Show item info near icons on desktop & other icon views|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:showItemInfo|true|false|false|IconView_showItemInfo|"
        # "Show item info below icons on desktop & other icon views|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:labelOnBottom|true|false|false|IconView_labelOnBottom|"
        # "Enable sort-by-name for icons on desktop & other icon views|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:arrangeBy|name|false|false|IconView_arrangeBy|"
        # "Set text size for item info on desktop to 14|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:textSize|true|false|false|IconView_textSize|"
        # "Increase the size for item info on desktop to 72|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:iconSize|true|false|false|IconView_iconSize|"
        # "Increase grid spacing for icons on the desktop|~/Library/Preferences/com.apple.finder.plist|:DesktopViewSettings:IconViewSettings:gridSpacing|true|false|false|IconView_gridSpacing|"
        
        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"        
        "GROUP|🔍 [Spotlight]|"
        "🚫 Disable Indexing for Custom Items (When using FindAnyFile)|com.apple.spotlight|orderedItems|'{\"enabled\"=1;\"name\"=\"APPLICATIONS\";}' '\"{\"enabled\"=0;\"name\"=\"MENU_EXPRESSION\";}\" … (etc)’||defaults_array|Sets Spotlight orderedItems"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🔄 [Automatic Updates]|🔧 ${YE}(Shows current states only. Please adjust manually)${NC}"
        # "OLD=🚫 Disable macOS Auto-Update|softwareupdate|schedule|off|on||sudo|Disables automatic software updates"
        "🔄 Automatically Download macOS Updates|/Library/Preferences/com.apple.SoftwareUpdate|AutomaticDownload|true|false||SoftwareUpdates|"
        "🔄 Automatically Install macOS Updates|/Library/Preferences/com.apple.SoftwareUpdate|AutomaticallyInstallMacOSUpdates|true|false||SoftwareUpdates|"
        "🔄 Automatically Check for macOS Updates|/Library/Preferences/com.apple.SoftwareUpdate|AutomaticCheckEnabled|true|false||SoftwareUpdates|"
        "🔄 Automatically Install Config Data|/Library/Preferences/com.apple.SoftwareUpdate|ConfigDataInstall|true|false||SoftwareUpdates|"
        "🔄 Automatically Install Critical Updates|/Library/Preferences/com.apple.SoftwareUpdate|CriticalUpdateInstall|true|false||SoftwareUpdates|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|⚙️  [System & UI]|"
        "🗂️  Always prefer tabs when opening documents|NSGlobalDomain|AppleWindowTabbingMode|always|manual||delete|Always prefer tabs when opening documents, not just in full-screen"
        "📜 Always Show Scroll Bars|NSGlobalDomain|AppleShowScrollBars|Always|Automatic||delete|Always shows scroll bars instead of auto-hiding"
        "🖱️  Change scrollbar to jump to the spot that's clicked|NSGlobalDomain|AppleScrollerPagingBehavior|true|false||delete|Makes scrollbars jump to clicked position"
        "📂 Expand Save Panel by Default (in Carbon/Cocoa apps)|NSGlobalDomain|NSNavPanelExpandedStateForSaveMode|true|false||delete|Expands save dialogs system-wide (in Carbon/Cocoa apps) by default"
        "📂 Expand Save Panel by Default (in modern apps)|NSGlobalDomain|NSNavPanelExpandedStateForSaveMode2|true|false||delete|Expands save dialogs system-wide (in modern apps) by default"
        "⚠️  Always ask to keep changes when closing documents|NSGlobalDomain|NSCloseAlwaysConfirmsChanges|true|false||delete|Always ask to keep changes when closing documents"
        "🖼️  Keep All Windows After Quitting An Application|NSGlobalDomain|NSQuitAlwaysKeepsWindows|1|0||delete|When enabled, open documents and windows will be restored when you re-open an application."
        "🚫 Disable Universal Control|com.apple.universalcontrol|Disable|1|delete|delete|-currentHost|Disables Universal Control"
        "🚫 Disable Dashboard (depreciated)|com.apple.dashboard|mcx-disabled|true|false|false|false|Disables Dashboard and widgets on older macOS's"
        "🚫 Disable Notification Center (depreciated)|launchctl|/System/Library/LaunchAgents/com.apple.notificationcenterui|unload|load|load|launchctl|Disables Notification Center on older macOS's"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🪄 [Animations]|"
        "🚫 Disable Automatic Window Animations|NSGlobalDomain|NSAutomaticWindowAnimationsEnabled|false|true||delete|Disables automatic window animations system-wide"
        "🚫 Disable Finder Info Window Animations|com.apple.finder|DisableAllAnimations|true|false||delete|Disables all Finder info window animations"
        "🚫 Disable QuickLook Animations|NSGlobalDomain|QLPanelAnimationDuration|0.0|0.25||delete|Disables QuickLook panel animations"
        "🚀 Speed Up Mission Control Animations|com.apple.dock|expose-animation-duration|0.1|0.5||delete|Speeds up Mission Control animations"
        "🚀 Speed Up Finder's Drag and Drop Spring Delay|NSGlobalDomain|com.apple.springing.delay|0.2|0.5||delete|Reduces spring delay for Finder drag and drop"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|💾 [Disks]|"
        "💾 Show internal hard disks on desktop|com.apple.finder|ShowHardDrivesOnDesktop|true|false||delete|Shows internal hard disks on desktop"
        "💾 Show external hard disks on desktop|com.apple.finder|ShowExternalHardDrivesOnDesktop|true|false||delete|Shows external hard disks on desktop"
        "💾 Show removable media on desktop|com.apple.finder|ShowRemovableMediaOnDesktop|true|false||delete|Shows removable media (CDs, DVDs and iPods) on desktop"
        "💾 Show mounted servers on desktop|com.apple.finder|ShowMountedServersOnDesktop|true|false||delete|Shows mounted servers on desktop"
        "💾 Show all devices in Disk Utility|com.apple.DiskUtility|SidebarShowAllDevices|true|false||delete|Shows all devices in sidebar of Disk Utility"
        "🚫 Disable new disk requests for Time Machine|com.apple.TimeMachine|DoNotOfferNewDisksForBackup|true|false||delete|Disables new disk requests for Time Machine"
        "🔄 Set Time Machine backup frequency to 'Manually'|/Library/Preferences/com.apple.TimeMachine|AutoBackup|false|true|true|true|Sets Time Machine backup frequency to 'Manually'"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📁 [Finder]|"
        "🏷️  Show All File Extensions|NSGlobalDomain|AppleShowAllExtensions|true|false||delete|Shows file extensions for all files"
        "🛤️  Show Path Bar in Finder|com.apple.finder|ShowPathbar|true|false||delete|Shows the path bar at the bottom of Finder windows"
        "📊 Show Status Bar in Finder|com.apple.finder|ShowStatusBar|true|false||delete|Shows the status bar at the bottom of Finder windows"
        "🗂️  Show Tab Bar in Finder|com.apple.finder|NSWindowTabbingShoudShowTabBarKey-com.apple.finder.TBrowserWindow|true|false|false|delete|Shows the tab bar at the top of Finder windows by default"
        "📚 Show hidden User ~/Library folder by default|com.apple.FinderInfo|ShowLibrary|nohidden|hidden||chflags|Makes the Library folder visible in Finder"
        "🗂️  Always open folders in a new tab|com.apple.finder|FinderSpawnTab|true|false||delete|Always opens folders in new tabs instead of new windows"
        "🏠 Set new Finder windows to show the Desktop folder|com.apple.finder|NewWindowTarget|PfDe|PfAF||delete|Sets new Finder windows to open the Desktop folder"
        # "🏠 Set Desktop folder path for new Finder windows|com.apple.finder|NewWindowTargetPath|file://${HOME}/Desktop/|file://${HOME}/||delete|Sets new Finder windows to open the Desktop folder"
        "📄 Set Default Finder to List View|com.apple.finder|FXPreferredViewStyle|Nlsv|icnv||delete|Sets Finder's default view to List instead of Icon"
        "🔍 Search the current folder when performing a search|com.apple.finder|FXDefaultSearchScope|SCcf|SCev||delete|Uses the current folder when performing a search"
        "📏 Set Finder/Settings sidebar icons to small instead of medium|NSGlobalDomain|NSTableViewDefaultSizeMode|1|2||delete|Sets Finder/Settings sidebar icons to small instead of medium"
        "👻 Show hidden files (or toggle them with ⌘ ⇧ .)|com.apple.finder|AppleShowAllFiles|true|false||delete|Shows hidden files. (You can also show them temporarily with ⌘ + ⇧ + .)"
        "🚫 Disable the warning when changing a file extension|com.apple.finder|FXEnableExtensionChangeWarning|false|true||delete|Disables the warning when changing a file extension in the Finder"
        "🚫 Hide Warning before removing from iCloud Drive (macOS Sonoma 14 and below)|com.apple.finder|FXEnableRemoveFromICloudDriveWarning|1|0|0|delete|Disables the 'Remove from iCloud Drive' warning."
        "🏷️  Remove the Tags section from Sidebar|com.apple.finder|ShowRecentTags|false|true||delete|Removes the Tags section from Sidebar."
        # "🔍 Set Custom Get Info Pane Layout|com.apple.finder|FXInfoPanesExpanded|'{General=true;Comments=false;MetaData=true;Name=true;OpenWith=true;Preview=false;Privileges=true;}'|{}||defaults_dict|Sets Get Info pane expand/collapse"
        # "🔍 Set Custom Toolbar Items|com.apple.finder|NSToolbar Configuration Browser|'{\"TB Default Item Identifiers\"=(\"com.apple.finder.BACK\",\"com.apple.finder.SWCH\",NSToolbarSpaceItem,\"com.apple.finder.ARNG\",\"com.apple.finder.SHAR\",\"com.apple.finder.LABL\",\"com.apple.finder.ACTN\",NSToolbarSpaceItem,\"com.apple.finder.SRCH\");\"TB Display Mode\"=2;\"TB Icon Size Mode\"=1;\"TB Is Shown\"=1;\"TB Item Identifiers\"=(\"com.apple.finder.BACK\",\"com.apple.finder.loc \",\"com.apple.finder.AirD\",\"com.apple.finder.CNCT\",\"com.apple.finder.NFLD\",\"com.apple.finder.SHAR\",\"com.apple.finder.SWCH\",NSToolbarSpaceItem,\"com.apple.finder.ACTN\",NSToolbarSpaceItem,\"com.apple.finder.SRCH\");\"TB Size Mode\"=1;}'|{}||defaults_dict|Sets Finder toolbar"    
        
        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📸 [Screencapture, Photo & Video]|"
        "🚫 Disable Screenshot border and shadow|com.apple.screencapture|disable-shadow|true|false||delete|Removes default border and shadow from screenshots"
        "🖼️  Set default Screenshot Format from PNG to JPG|com.apple.screencapture|type|jpg|png||delete|Changes default screenshot format from PNG to JPG"
        "🚫 Disable Screenshot Preview Thumbnails|com.apple.screencapture|show-thumbnail|false|true||delete|Disables screenshot preview thumbnails in order to save immediately"
        "🚫 Disable date and time in filenames|com.apple.screencapture|include-date|false|true|false|false|Disables screenshot preview thumbnails in order to save immediately"
        "🎥 Show Mouse Pointer in Screenshots|com.apple.screencapture|showsCursor|true|false||delete|Shows mouse cursor when screen recording"
        "🎥 Show Mouse Clicks When Screen Recording|com.apple.screencapture|showsClicks|true|false||delete|Shows mouse clicks when screen recording"
        "▶️  Auto-play videos when opened with QuickTime Player|com.apple.QuickTimePlayerX|MGPlayMovieOnOpen|true|false||false|Auto-plays videos when opened with QuickTime Player"
        "🚫 Prevent Photos from opening automatically when devices are plugged in|com.apple.ImageCapture|disableHotPlug|true|false|false|-currentHost|Prevents Photos from opening automatically when devices are plugged in"


        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🖱️  [Mouse]|"
        "🚫 Disable Natural Scrolling (applies globally)|NSGlobalDomain|com.apple.swipescrolldirection|false|true||delete|Disables natural scrolling direction (applies globally)"
        "🚀 Increase Mouse Tracking Speed beyond default ${NC}(Requires a restart)${NC}|NSGlobalDomain|com.apple.mouse.scaling|5|3.0||delete|Increases mouse tracking speed beyond default"
        "🖱️  Enable secondary button (on bluetooth multi-touch mice)|com.apple.driver.AppleBluetoothMultitouch.mouse|MouseButtonMode|TwoButton|OneButton||delete|Enables secondary button (on bluetooth multi-touch mice)"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        # "GROUP|💻 [TrackPad - Built-In]|"
        "GROUP|💻 [TrackPad]|"
        "💨 Increase Trackpad Tracking Speed|NSGlobalDomain|com.apple.trackpad.scaling|3|0.5||delete|Increases tracking speed to fastest setting"
        # "⚙️  Enable Tap to click|com.apple.AppleMultitouchTrackpad|Clicking|1|0||delete|Enables 'Tap to click' on built-in Trackpads"
        # "⚙️  Enable Tap to click (in login screen)|NSGlobalDomain|com.apple.mouse.tapBehavior|1|0||-currentHost|Enables 'Tap to click' on built-in Trackpads (in login screen)."
        "⚙️  Enable Tap To Click|NSGlobalDomain|com.apple.mouse.tapBehavior|1|0||-currentHost|Enables 'Tap to click' on Trackpads."
        "⚙️  Enable Two-Finger Tap To Right Click AND Bottom Right Click. ${BO}(Requires Logging Out)${NC}|Various|Various|true|false|delete|Two_Finger_Tap_To_Right_Click_AND_Bottom_Right_Click|Enables Two-Finger Tap To Right Click AND Bottom Right Click. 📝 ${YE}Note that System Settings will show only 'Click in Bottom Right Corner' selected, but 'Click or Tap with Two Fingers' is also applied!'${NC}"
        # "⚙️  Enable secondary click|NSGlobalDomain|com.apple.trackpad.enableSecondaryClick|true|false||-currentHost|Enables bottom-right right-click on built-in Trackpads (in login screen)."
        # "⚙️  Enable two-finger tap to right-click|com.apple.AppleMultitouchTrackpad|TrackpadRightClick|true|false||delete|Enable two-finger right-click on built-in Trackpads"
        # "⚙️  Enable corner right-click (disables 'tap to right-click')|NSGlobalDomain|com.apple.trackpad.trackpadCornerClickBehavior|1|0||-currentHost|Enables corner right-click on built-in Trackpads (in login screen)."

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        # "GROUP|💻 [TrackPad - External/Bluetooth|"
        # "⚙️  Enable Tap to click|com.apple.driver.AppleBluetoothMultitouch.trackpad|Clicking|1|0||delete|Enables 'Tap to click' on bluetooth Trackpads"
        # "⚙️  Enable two-finger tap to right-click|com.apple.driver.AppleBluetoothMultitouch.trackpad|TrackpadRightClick|1|0||delete|Enable two-finger right-click on bluetooth Trackpads"
        # "⚙️  Enable pinch-to-zoom|com.apple.driver.AppleBluetoothMultitouch.trackpad|TrackpadPinch|1|0||delete|Enables pinch-to-zoom on bluetooth Trackpads"
        # "⚙️  Enable corner right-click (disables 'tap to right-click')|com.apple.driver.AppleBluetoothMultitouch.trackpad|TrackpadCornerSecondaryClick|0|1||delete|Enables corner right-click on bluetooth Trackpads (disables tap to right click)"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|⌨️   [Keyboard]|📝 ${YE}Note that the last two require a restart to take effect.${NC}"
        "💨 Speed Up Initial Key Repeat Rate|NSGlobalDomain|KeyRepeat|2|6||delete|Speeds up the repeat of pressed keys"
        "💨 Speed Up Delay Until Key Repeat|NSGlobalDomain|InitialKeyRepeat|15|25||delete|Speeds up the delay until pressed keys are repeated"
        "🚫 Disable auto-capitalization|NSGlobalDomain|NSAutomaticCapitalizationEnabled|false|true|true|delete|Disables automatic capitalization"
        "🚫 Disable auto-correct|NSGlobalDomain|NSAutomaticSpellingCorrectionEnabled|false|true||delete|Disables automatic capitalization"
        "🚫 Disable auto-period substitution|NSGlobalDomain|NSAutomaticPeriodSubstitutionEnabled|false|true||delete|Disables automatic period substitution"
        "↔️  Allow tab navigation across UI|NSGlobalDomain|AppleKeyboardUIMode|2|0|2|delete|Enables full keyboard access for all controls"
        "😌 Fn/🌐 key Shows Emoji & Symbols ${BO}(Requires Restart)${NC}|com.apple.HIToolbox|AppleFnUsageType|2|0|0|0|Fn/🌐 key Shows Emoji & Symbols. ${BO}Note that this requires a restart to take effect.${NC}"
        "🚫 Disable accent options when a key is held down ${BO}(Requires Restart)${NC}|NSGlobalDomain|ApplePressAndHoldEnabled|false|true|true|true|Disables accent options when a key is held down. ${BO}Note that this requires a restart to take effect.${NC}"
        # "⌨️  Finder: Custom Shortcuts|com.apple.finder|NSUserKeyEquivalents|'{\"Get Info\"=\"@~i\";\"Show Inspector\"=\"@i\";\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets Finder keyboard shortcuts"
        # "⌨️  Ableton Live: Custom Shortcuts|com.ableton.live|NSUserKeyEquivalents|'{\"Freeze Track\"=\"@~f\";\"Plug-In Windows\"=\"@~w\";\"Record to Arrangement\"=\"@ \";}'|{}||key_equivalents|Sets Live keyboard shortcuts"
        # "⌨️  Preview: Toggle Markup Toolbar|com.apple.Preview|NSUserKeyEquivalents|'{\"Hide Markup Toolbar\"=\"@~m\";\"Show Markup Toolbar\"=\"@~m\";}'|{}||key_equivalents|Sets Preview keyboard shortcuts"
        # "⌨️  Safari: Next/Prev Tab|com.apple.Safari|NSUserKeyEquivalents|'{\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets Safari tab shortcuts"
        # "⌨️  Terminal: Common Shortcuts|com.apple.Terminal|NSUserKeyEquivalents|'{New=\"@t\";\"Show Fonts\"=\"@n\";\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets Terminal shortcuts"
        # "⌨️  Apparency: Next/Prev Tab|com.mothersruin.Apparency|NSUserKeyEquivalents|'{\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets Apparency tab shortcuts"
        # "⌨️  Suspicious Package: Tab Shortcuts|com.mothersruin.SuspiciousPackageApp|NSUserKeyEquivalents|'{\"Next Tab in Package\"=\"@~]\";\"Previous Tab in Package\"=\"@~[\";\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets Suspicious Package shortcuts"
        # "⌨️  TextEdit: Next/Prev Tab|com.apple.TextEdit|NSUserKeyEquivalents|'{\"Show Next Tab\"=\"@~\\U2192\";\"Show Previous Tab\"=\"@~\\U2190\";}'|{}||key_equivalents|Sets TextEdit tab shortcuts"
        # "⌨️  Sononym: Play/Stop|com.sononym.sononym|NSUserKeyEquivalents|'{\"Play Selected File\"=\"\\U2192\";\"Stop Playback/Recording\"=\"\\U2190\";}'|{}||key_equivalents|Sets Sononym shortcuts"
        # "⌨️  UTM: Common Shortcuts|com.utmapp.UTM|NSUserKeyEquivalents|'{\"Hide UTM\"=\"~h\";\"Open...\"=\"~o\";\"Quit UTM\"=\"~q\";}'|{}||key_equivalents|Sets UTM shortcuts"
        # "⌨️  MediaInfo: Close All|net.mediaarea.mediainfo.mac|NSUserKeyEquivalents|'{\"Close All Files\"=\"@~w\";}'|{}||key_equivalents|Sets MediaInfo shortcut"
        # "⌨️  FindAnyFile: Close All|org.tempel.findanyfile|NSUserKeyEquivalents|'{\"Close All Files\"=\"@~w\";}'|{}||key_equivalents|Sets FindAnyFile shortcut"        

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📋 [Menu Bar & Control Center]|${YE}(To prevent clutter, hide all and just use Control Center 👍)${NC}"
        "🖥️  Never Hide Menu Bar In Fullscreen|NSGlobalDomain|AppleMenuBarVisibleInFullscreen|true|false|false|delete|Never hides the menu bar when in full screen;"
        # "🍱 Show Control Center in Menu Bar|com.apple.controlcenter|NSStatusItem Visible BentoBox|true|false|true|delete|Shows Control Center in the menu bar"
        "🛜 Show WiFi in Menu Bar|com.apple.controlcenter|WiFi|2|8|8|-currentHost|Shows WiFi in Menu Bar"
        "🔵 Show Bluetooth in Menu Bar [Always]|com.apple.controlcenter|Bluetooth|2|8|8|-currentHost|Shows Bluetooth control in the menu bar"
        "🌀 Show AirDrop in Menu Bar [Always]|com.apple.controlcenter|AirDrop|2|8|8|-currentHost|Shows AirDrop control in the menu bar"
        "📵 Show Focus in Menu Bar [Always]|com.apple.controlcenter|FocusModes|18|8|2|-currentHost|Shows Focus control in the menu bar"
        "🚀 Show Stage Manager in Menu Bar [Always]|com.apple.controlcenter|StageManager|2|8|8|-currentHost|Shows Now Playing in the menu bar"
        "🖥️  Show Screen Mirroring in Menu Bar [Always]|com.apple.controlcenter|ScreenMirroring|18|8|2|-currentHost|Shows Screen Mirroring control in the menu bar"
        "🖥️  Show Display in Menu Bar [Always]|com.apple.controlcenter|Display|18|8|2|-currentHost|Shows Display control in the menu bar"
        "🔊 Show Sound in Menu Bar [Always]|com.apple.controlcenter|Sound|18|8|2|-currentHost|Shows sound control in the menu bar"
        "🚀 Show Now Playing in Menu Bar [Always]|com.apple.controlcenter|NowPlaying|18|8|2|-currentHost|Shows Now Playing in the menu bar"
        "♿️ Show Accessibility in Menu Bar|com.apple.controlcenter|AccessibilityShortcuts|3|9|9|-currentHost|Shows Now Playing in the menu bar"
        "📣 Show Music Recognition in Menu Bar|com.apple.controlcenter|MusicRecognition|6|12|12|-currentHost|"
        "🦻 Show Hearing in Menu Bar|com.apple.controlcenter|Hearing|2|8|8|-currentHost|"
        "🎤 Show Voice Control in Menu Bar|com.apple.controlcenter|VoiceControl|18|8|8|-currentHost|"
        "👤 Show Fast User Switching in Menu Bar|com.apple.controlcenter|UserSwitcher|2|8|8|-currentHost|"
        "🕒 Display the time with seconds|com.apple.menuextra.clock|ShowSeconds|true|false|false|delete|Displays the time with seconds in menu bar"
        "🔮 Show Siri in Menu Bar|com.apple.controlcenter|Siri|2|8|8|-currentHost|"
        "⏳ Show Time Machine in Menu Bar|com.apple.systemuiserver|NSStatusItem Visible com.apple.menuextra.TimeMachine|true|false|false|Show_Time_Machine_Menu_Bar_Item|Shows Time Machine in the menu bar"
        "⏳ Show VPN in Menu Bar|com.apple.systemuiserver|NSStatusItem Visible com.apple.menuextra.vpn|true|false|false|Show_VPN_Menu_Bar_Item|Shows VPN in the menu bar"
        # "🚀 Show Shortcuts in Menu Bar|com.apple.controlcenter|NSStatusItem Visible Shortcuts|true|false|false|delete|Shows Shortcuts control in the menu bar"
        # "🎥 Show FaceTime in Menu Bar|com.apple.controlcenter|NSStatusItem Visible FaceTime|true|false|delete|delete|Shows FaceTime control in the menu bar"
        "🔤 Show Text Input in Menu Bar|com.apple.TextInputMenu|visible|true|false|delete|delete|Shows text input in the Menu Bar"
        "🕹️  Show Remote Management in Menu Bar|/Library/Preferences/com.apple.RemoteManagement|LoadRemoteManagementMenuExtra|true|false|false|Remote_Management_Menu_Bar|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📋 [Menu Bar & Control Center - For Laptops]|"
        "🔋 Show Battery in Menu Bar|com.apple.controlcenter|Battery|3|9|9|-currentHost|Shows battery in the menu bar"
        "💯 Show Battery Percentage in Menu Bar|com.apple.controlcenter|BatteryShowPercentage|1|0|0|-currentHost|Shows battery percentage in the menu bar"
        "⌨️  Show Keyboard Brightness in Menu Bar|com.apple.controlcenter|KeyboardBrightness|3|9|9|-currentHost|Shows Keyboard Brightness in the menu bar"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📶 [Connectivity]|"
        "🌐 Enable AirDrop over Ethernet|com.apple.NetworkBrowser|BrowseAllInterfaces|true|false||delete|Enables AirDrop over Ethernet and on unsupported Macs"
        "🚫 Disable AirPlay Receiver|com.apple.controlcenter|AirplayReceiverEnabled|false|true|true|-currentHost|Disables AirPlay Receiver"


        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|📝 [TextEdit]|"
        "🗂️  Always show tab bar in TextEdit|com.apple.TextEdit|NSWindowTabbingShoudShowTabBarKey-NSWindow-DocumentWindowController-DocumentWindowController-VT-FS|1|delete|delete|delete|Shows Tab Bar by default in TextEdit"
        "📝 Create a new document by default when opening TextEdit|com.apple.TextEdit|NSShowAppCentricOpenPanelInsteadOfUntitledFile|false|true||delete|Opens new document by default in TextEdit"
        "📝 Use Plain Text Mode for TextEdit|com.apple.TextEdit|RichText|false|true|true|true|Sets TextEdit to use Plain Text instead of Rich Text by default"
        "📂 Expand Default Save Panel in TextEdit (1 of 2)|com.apple.TextEdit|NSNavPanelExpandedStateForSaveMode|true|false|false|false|Expands the save dialog in TextEdit by default"
        "📂 Expand Default Save Panel in TextEdit (2 of 2)|com.apple.TextEdit|NSNavPanelExpandedStateForSaveMode2|true|false|false|false|Expands the save dialog in TextEdit by default"
        "📂 Set Default Save Panel in TextEdit to List View (1 of 2)|com.apple.TextEdit|NSNavPanelFileListModeForSaveMode2|2|3||delete|Sets default save panel in TextEdit to list view"
        "📂 Set Default Save Panel in TextEdit to List View (2 of 2)|com.apple.TextEdit|NSNavPanelFileLastListModeForSaveModeKey|2|3||delete|Sets default save panel in TextEdit to list view"
        "📂 Set Font Size to 14 in TextEdit|com.apple.TextEdit|NSFixedPitchFontSize|14|11|11|delete|Sets default font size from 11 to 14 in Text Edit."

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|👾 [Terminal]|"
        "🗂️  Always show tab bar in Terminal|com.apple.Terminal|NSWindowTabbingShoudShowTabBarKey-TTWindow-TTWindowController-TTWindowController-VT-FS|1|delete||delete|Shows Tab Bar by default in Terminal"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🗜️  [Archive Utility]|"
        "🗑️  Move archives to trash after expanding|com.apple.archiveutility|dearchive-move-after|~/.Trash|.|.|.|"
        "🗑️  Move files to trash after archiving|com.apple.archiveutility|archive-move-after|~/.Trash|.|.|.|"
        "🚫 Don't reveal archives after expanding|com.apple.archiveutility|dearchive-reveal-after|false|true|true|true|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|🌐 [Safari - General]|⚠️  ${YE}(Terminal requires Full Disk Access to read/write changes)${NC}"
        "🗂️  Always Show Tab Bar in Safari|com.apple.Safari|AlwaysShowTabBar|1|0||0|"
        "🌐 Show Overlay Status Bar|com.apple.Safari|ShowOverlayStatusBar|true|false||false|"
        "⭐️ Show Favorites Bar|com.apple.Safari|ShowFavoritesBar-v2|true|false||true|"
        "🎞️  Safari opens with all windows from last session|com.apple.Safari|AlwaysRestoreSessionAtLaunch|true|false||false|"
        "🌐 New windows open with Empty Page|com.apple.Safari|NewWindowBehavior|1|4||4|"
        "🌐 New tabs open with Empty Page|com.apple.Safari|NewTabBehavior|1|4||4|"
        "🚫 Disable Auto Open Safe Downloads|com.apple.Safari|AutoOpenSafeDownloads|false|true||false|Disables 'Auto-open safe downloads'"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|[Safari - Tabs]|"
        "🌐 Always show website titles in tabs|com.apple.Safari|EnableNarrowTabs|false|true||true|"
        "🚫 Disable compact tab layout|com.apple.Safari|ShowStandaloneTabBar|true|false||true|"
        "🗂️  Close Tabs Manually|com.apple.Safari|CloseTabsAutomatically|false|true||false|"
        "🗂️  Command + Click Opens New Tab or Window In Background|com.apple.Safari|OpenNewTabsInFront|false|true||false|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|[Safari - AutoFill]|"
        "🚫 Disable AutoFill Contacts|com.apple.Safari|AutoFillFromAddressBook|false|true|false|false|"
        "🚫 Disable AutoFill Passwords|com.apple.Safari|AutoFillPasswords|false|true|false|false|"        
        "🚫 Disable AutoFill Credit Cards|com.apple.Safari|AutoFillCreditCardData|false|true|false|false|"
        "🚫 Disable AutoFill Other Forms|com.apple.Safari|AutoFillMiscellaneousForms|false|true|false|false|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|[Safari - Search]|"
        "🔎 Use DuckDuckGo as default search provider in ALL Browsing|com.apple.Safari|SearchProviderShortName|DuckDuckGo|Google||Google|"
        "🔎 Private Search Engine Uses Same Search Engine|com.apple.Safari|PrivateSearchEngineUsesNormalSearchEngineToggle|true|false||true|"
        "🚫 Disable Search Engine Suggestions|com.apple.Safari|SuppressSearchSuggestions|true|false||true|"
        "🚫 Disable Previously Visited Website Suggestions|com.apple.Safari|WebsiteSpecificSearchEnabled|false|true||false|"
        "🚫 Disable Preload Top Hit|com.apple.Safari|PreloadTopHit|false|true||false|"
        "🚫 Disable Favorites Suggestions|com.apple.Safari|ShowFavoritesUnderSmartSearchField|false|true||false|"
        "🔎 Private Search Engine Uses Same Search Engine|com.apple.Safari|PrivateSearchEngineUsesNormalSearchEngineToggle|true|false||true|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|[Safari - Security]|"
        "🔒 Enable Safe Browsing|com.apple.Safari.SafeBrowsing|SafeBrowsingEnabled|true|false||delete|Enables Safe Browsing."
        "⚠️  Warn About Fraudulent Websites|com.apple.Safari|WarnAboutFraudulentWebsites|true|false||delete|Enables 'Warn About Fraudulent Websites'"
        "🌐 Warn before connecting to a website over HTTP|com.apple.Safari|UseHTTPSOnly|true|false||true|"
        "🕵️‍♂️  Private Browsing Requires Authentication|com.apple.Safari|PrivateBrowsingRequiresAuthentication|true|false||true|"
        "🚫 Disallow Websites To Send Notifications|com.apple.Safari|CanPromptForPushNotifications|false|true||false|"

        # Format: "Display Name|Domain|Key|Active Value|Inactive Value|Reset Command|Type|Description"
        # Or group header: "GROUP|<Title>|<Optional Subtext>"
        "GROUP|[Safari - Advanced]|"
        "🌐 Show Full Website URL In Address Bar|com.apple.Safari|ShowFullURLInSmartSearchField|true|false||true|Shows full website URL in the address bar"
        "🕵️‍♂️  Enable Enhanced Privacy In ALL Browsing|com.apple.Safari|EnableEnhancedPrivacyInRegularBrowsing|true|false||true|"
        "🚫 Disallow Privacy-Preserving Measurment of Ad Effectiveness|com.apple.Safari|WebKitPreferences.privateClickMeasurementEnabled|false|true||false|"
        "🛠  Show Features For Web Developers|com.apple.Safari.SandboxBroker|ShowDevelopMenu|true|false||false|Enables Safari's Developer menu."

    )

    # Helper function to get current preference state
    get_preference_current_state() {
        local domain="$1"
        local key="$2"
        local type="$3"
        local active_val="$4"
        local inactive_val="$5"
        
        if [[ "$type" == "sudo" ]]; then
            echo "unknown"
            return
        fi

        if [[ "$domain" == "launchctl" ]]; then
            echo "unknown"
            return
        fi

        # Complex payload types: treat as custom to avoid brittle deep comparisons
        if [[ "$type" == "key_equivalents" || "$type" == "defaults_dict" || "$type" == "defaults_array" || "$type" == "plistbuddy" ]]; then
            echo "custom"
            return
        fi
        
        local current_value
        if [[ "$type" == "chflags" ]]; then
            if [[ "$key" == "ShowLibrary" ]]; then
                if [[ -d ~/Library ]] && [[ "$(ls -ldO ~/Library | grep hidden)" ]]; then
                    echo "inactive"
                    return
                else
                    echo "active"
                    return
                fi
            fi
            echo "unknown"
            return
        fi 

        # Handle special cases that return large amounts of data
        if [[ "$domain" == "com.apple.dock" && "$key" == "persistent-apps" ]]; then
            local app_count=$(defaults read "$domain" "$key" 2>/dev/null | grep "CFBundleIdentifier" 2>/dev/null | wc -l 2>/dev/null || echo "0")
            app_count=${app_count:-0}  # Ensure it's not empty
            if [[ "$app_count" -gt 0 ]]; then
                echo "custom"
            else
                echo "default"
            fi
            return
        fi

        # Handle trackpad tap to right click
        if [[ "$type" == "Two_Finger_Tap_To_Right_Click_AND_Bottom_Right_Click" ]]; then
            if [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick)" == "2" ]] &&
               [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick)" == "1" ]] &&
               [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior)" == "1" ]] &&
               [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.enableSecondaryClick)" == "1" ]] &&
               [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick)" == "2" ]] &&
               [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadRightClick)" == "1" ]]; then
                echo "active"
                return
            else
                if [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick)" == "0" ]] &&
                   [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior)" == "0" ]] &&
                   [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.enableSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadRightClick)" == "0" ]]; then
                    echo "inactive"
                    return
                else
                    echo "custom"
                    return
                fi
            fi
        fi

        # Handle Time Machine menu bar item
        if [[ "$type" == "Show_Time_Machine_Menu_Bar_Item" ]]; then
            # Check if TimeMachine is in menuExtras array
            tm_in_array="false"
            if /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "TimeMachine"; then
                tm_in_array="true"
            fi
            # Get visibility setting
            tm_visible=$(defaults read com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.TimeMachine" 2>/dev/null || echo "0")
            # Check if both conditions are met for "active" state
            if [[ "$tm_visible" == "1" ]] && [[ "$tm_in_array" == "true" ]]; then
                echo "active"
                return
            else
                if [[ "$tm_visible" == "0" ]] && [[ "$tm_in_array" == "false" ]]; then
                    echo "inactive"
                    return
                else
                    echo "default"
                    return
                fi
            fi
        fi

        # Handle VPN menu bar item
        if [[ "$type" == "Show_VPN_Menu_Bar_Item" ]]; then
            # Check if VPN is in menuExtras array
            tm_in_array="false"
            if /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "VPN"; then
                tm_in_array="true"
            fi
            # Get visibility setting
            tm_visible=$(defaults read com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.vpn" 2>/dev/null || echo "0")
            # Check if both conditions are met for "active" state
            if [[ "$tm_visible" == "1" ]] && [[ "$tm_in_array" == "true" ]]; then
                echo "active"
                return
            else
                if [[ "$tm_visible" == "0" ]] && [[ "$tm_in_array" == "false" ]]; then
                    echo "inactive"
                    return
                else
                    echo "custom"
                    return
                fi
            fi
        fi

        if [[ "$type" == "disable_Apple_Intelligence" ]]; then
            # Handle Apple Intelligence - Check current state first
            domain="com.apple.CloudSubscriptionFeatures.optIn"
            
            # Check if any keys are enabled (set to 1)
            enabled_keys=$(defaults read "$domain" 2>/dev/null | grep -E "^\s+[0-9]+ = 1;" | awk '{print $1}')
            disabled_keys=$(defaults read "$domain" 2>/dev/null | grep -E "^\s+[0-9]+ = 0;" | awk '{print $1}')
            
            if [[ -n "$enabled_keys" ]]; then
                echo "inactive"
                return
            elif [[ -n "$disabled_keys" ]]; then
                echo "active" 
                return
            else
                echo "custom"
                return
            fi
        fi    

        current_value=$(defaults read "$domain" "$key" 2>/dev/null || echo "")

        # Handle currentHost type
        if [[ "$type" == *"-currentHost"* ]]; then
            current_value=$(defaults -currentHost read "$domain" "$key" 2>/dev/null || echo "not set")
            if [[ -z "$current_value" ]]; then
                echo "default"
                return
            fi
        fi   

        # if [[ -z "$current_value" ]]; then
        #     echo "default"
        #     return
        # fi

        # Normalize values for comparison (handle 0 vs 0.0, YES/NO vs true/false)
        norm() {
            local v="$1"
            # Uppercase booleans/YES/NO for consistency
            v=$(echo "$v" | tr '[:lower:]' '[:upper:]')
            # Strip surrounding quotes if any
            v=$(echo "$v" | sed 's/^"\(.*\)"$/\1/')
            # If numeric, strip trailing .0s
            if echo "$v" | grep -E '^[0-9]+(\.[0-9]+)?$' >/dev/null 2>&1; then
                echo "$v" | sed 's/\.[0]*$//'
            else
                echo "$v"
            fi
        }

        local n_current=$(norm "$current_value")
        local n_active=$(norm "$active_val")
        local n_inactive=$(norm "$inactive_val")

        if [[ -n "$n_active" ]] || [[ -n "$n_inactive" ]]; then
            if [[ "$n_current" == "$n_active" ]]; then
                echo "active"
                return
            elif [[ "$n_current" == "$n_inactive" ]]; then
                echo "inactive"
                return
            fi
            # Special handling for common boolean synonyms
            if [[ "$n_active" == "TRUE" && ( "$n_current" == "YES" || "$n_current" == "1" ) ]]; then
                echo "active"; return
            fi
            if [[ "$n_inactive" == "FALSE" && ( "$n_current" == "NO" || "$n_current" == "0" ) ]]; then
                echo "inactive"; return
            fi
            if [[ "$n_active" == "FALSE" && ( "$n_current" == "NO" || "$n_current" == "0" ) ]]; then
                echo "active"; return
            fi
            if [[ "$n_inactive" == "TRUE" && ( "$n_current" == "YES" || "$n_current" == "1" ) ]]; then
                echo "inactive"; return
            fi
            echo "custom"
            return
        fi

        # Fallback generic mapping if no active/inactive values provided
        if [[ "$n_current" == "TRUE" || "$n_current" == "YES" || "$n_current" == "1" ]]; then
            echo "active"
        elif [[ "$n_current" == "FALSE" || "$n_current" == "NO" || "$n_current" == "0" ]]; then
            echo "inactive"
        else
            echo "custom"
        fi
    }

    # Helper function to get current preference value
    get_preference_current_value() {
        local domain="$1"
        local key="$2"
        local type="$3"
        
        if [[ "$type" == "sudo" ]]; then
            echo "sudo command - cannot read current value"
            return
        fi
        
        if [[ "$type" == "chflags" ]]; then
            if [[ "$key" == "ShowLibrary" ]]; then
                if [[ -d ~/Library ]] && [[ "$(ls -la ~/ | grep Library | grep hidden)" ]]; then
                    echo "hidden"
                    return
                else
                    echo "visible"
                    return
                fi
            fi
            echo "unknown"
            return
        fi

        # Complex payload types: don't try to print giant dicts/arrays; indicate custom
        if [[ "$type" == "key_equivalents" || "$type" == "defaults_dict" || "$type" == "defaults_array" || "$type" == "plistbuddy" ]]; then
            echo "custom"
            return
        fi

        # Handle trackpad tap to right click
        if [[ "$type" == "Two_Finger_Tap_To_Right_Click_AND_Bottom_Right_Click" ]]; then
            if [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick)" == "2" ]] &&
               [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick)" == "1" ]] &&
               [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior)" == "1" ]] &&
               [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.enableSecondaryClick)" == "1" ]] &&
               [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick)" == "2" ]] &&
               [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadRightClick)" == "1" ]]; then
                echo "true"
                return
            else
                if [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick)" == "0" ]] &&
                   [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior)" == "0" ]] &&
                   [[ "$(defaults -currentHost read NSGlobalDomain com.apple.trackpad.enableSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick)" == "0" ]] &&
                   [[ "$(defaults read com.apple.AppleMultitouchTrackpad TrackpadRightClick)" == "0" ]]; then
                    echo "false"
                    return
                else
                    echo "custom"
                    return
                fi
            fi
        fi
        # Handle Time Machine menu bar item
        if [[ "$type" == "Show_Time_Machine_Menu_Bar_Item" ]]; then
            # Check if TimeMachine is in menuExtras array
            tm_in_array="false"
            if /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "TimeMachine"; then
                tm_in_array="true"
            fi
            # Get visibility setting
            tm_visible=$(defaults read com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.TimeMachine" 2>/dev/null || echo "0")
            # Check if both conditions are met for "active" state
            if [[ "$tm_visible" == "1" ]] && [[ "$tm_in_array" == "true" ]]; then
                echo "true"
                return
            else
                if [[ "$tm_visible" == "0" ]] && [[ "$tm_in_array" == "false" ]]; then
                    echo "false"
                    return
                else
                    echo "custom"
                    return
                fi
            fi
        fi
        # Handle VPN menu bar item
        if [[ "$type" == "Show_VPN_Menu_Bar_Item" ]]; then
            # Check if VPN is in menuExtras array
            tm_in_array="false"
            if /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "VPN"; then
                tm_in_array="true"
            fi
            # Get visibility setting
            tm_visible=$(defaults read com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.vpn" 2>/dev/null || echo "0")
            # Check if both conditions are met for "active" state
            if [[ "$tm_visible" == "1" ]] && [[ "$tm_in_array" == "true" ]]; then
                echo "true"
                return
            else
                if [[ "$tm_visible" == "0" ]] && [[ "$tm_in_array" == "false" ]]; then
                    echo "false"
                    return
                else
                    echo "custom"
                    return
                fi
            fi
        fi

        if [[ "$type" == "disable_Apple_Intelligence" ]]; then
            # Handle Apple Intelligence - Check current state first
            domain="com.apple.CloudSubscriptionFeatures.optIn"
            
            # Check if any keys are enabled (set to 1)
            enabled_keys=$(defaults read "$domain" 2>/dev/null | grep -E "^\s+[0-9]+ = 1;" | awk '{print $1}')
            disabled_keys=$(defaults read "$domain" 2>/dev/null | grep -E "^\s+[0-9]+ = 0;" | awk '{print $1}')
            
            if [[ -n "$enabled_keys" ]]; then
                echo "true"
                return
            elif [[ -n "$disabled_keys" ]]; then
                echo "false" 
                return
            else
                echo "custom"
                return
            fi
        fi 

        # Handle currentHost type
        if [[ "$type" == *"-currentHost"* ]]; then
            local current_value=$(defaults -currentHost read "$domain" "$key" 2>/dev/null || echo "not set")
            # Limit output length for very long values
            if [[ ${#current_value} -gt 50 ]]; then
                echo "${current_value:0:47}..."
            else
                echo "$current_value"
            fi
            return
        fi
        
        # Handle special cases that return large amounts of data
        if [[ "$domain" == "com.apple.dock" && "$key" == "persistent-apps" ]]; then
            local app_count=$(defaults read "$domain" "$key" 2>/dev/null | grep "CFBundleIdentifier" 2>/dev/null | wc -l 2>/dev/null || echo "0")
            app_count=${app_count:-0}  # Ensure it's not empty
            if [[ "$app_count" -gt 0 ]]; then
                echo "$app_count app(s) in Dock"
            else
                echo "no apps in Dock"
            fi
            return
        fi
        
        if [[ "$domain" == "launchctl" ]]; then
            echo "launchctl command - cannot read current value"
            return
        fi
        
        local current_value=$(defaults read "$domain" "$key" 2>/dev/null || echo "not set")
        
        # Limit output length for very long values
        if [[ ${#current_value} -gt 50 ]]; then
            echo "${current_value:0:47}..."
        else
            echo "$current_value"
        fi
    }

    # Helper: write defaults with correct type based on value (bash 3.2 compatible)
    write_defaults_typed() {
        local domain="$1"
        local key="$2"
        local value="$3"
        local type="$4"

        # Determine if we need -currentHost flag
        local host_flag=""
        if [[ "$type" == *"-currentHost"* ]]; then
            host_flag="-currentHost"
        fi

        # Normalize for checks
        local upper=$(echo "$value" | tr '[:lower:]' '[:upper:]')

        # Empty array sentinel
        if [[ "$value" == "-array" ]]; then
            defaults $host_flag write "$domain" "$key" -array
            return
        fi

        # Boolean synonyms
        if [[ "$upper" == "TRUE" || "$upper" == "YES" ]]; then
            defaults $host_flag write "$domain" "$key" -bool true
            return
        fi
        if [[ "$upper" == "FALSE" || "$upper" == "NO" ]]; then
            defaults $host_flag write "$domain" "$key" -bool false
            return
        fi

        # Numeric detection (float before int)
        if echo "$value" | grep -E '^[0-9]+\.[0-9]+$' >/dev/null 2>&1; then
            defaults $host_flag write "$domain" "$key" -float "$value"
            return
        fi
        if echo "$value" | grep -E '^[0-9]+$' >/dev/null 2>&1; then
            defaults $host_flag write "$domain" "$key" -int "$value"
            return
        fi

        # Fallback: string
        defaults $host_flag write "$domain" "$key" -string "$value"
    }

    # Helper function to apply preference change
    apply_preference_change() {
        local domain="$1"
        local key="$2"
        local value="$3"
        local type="$4"
        local action="$5"
        
        echo
        # echo "${YE}Applying $action for $key...${NC}"
        echo "${YE}Applying changes...${NC}"  

        # Handles type cases
        case "$type" in
            "delete")
                # For delete type, we need to handle active/inactive differently
                # Active/inactive should use defaults write, only reset should use defaults delete
                if [[ "$action" == "active" || "$action" == "inactive" ]]; then
                    # Use the provided value for active/inactive with proper typing
                    write_defaults_typed "$domain" "$key" "$value"
                else
                    # Use delete for reset to default
                    defaults delete "$domain" "$key" 2>/dev/null || true
                fi
                sleep 1
                ;;
            "key_equivalents")
                # Write a full NSUserKeyEquivalents dictionary blob as-is
                # Expect value to be a valid plist-style dict string: '{"Menu Item"="@~i"; ... }'
                defaults write "$domain" "$key" "$value"
                sleep 1
                ;;
            "defaults_dict")
                # Write complex dict payloads (e.g., Finder panes/toolbar)
                defaults write "$domain" "$key" "$value"
                sleep 1
                ;;
            "defaults_array")
                # Write an array payload. Allow multiple dict items passed in value.
                # If value already contains properly quoted items, use eval to expand them.
                eval "defaults write \"$domain\" \"$key\" -array $value"
                sleep 1
                ;;
            "plistbuddy")
                # Run one or more PlistBuddy commands against a plist path in domain
                # Commands are separated by '||' in value
                echo "$value" | sed 's/||/\n/g' | while IFS= read -r __cmd; do
                    if [[ -n "$__cmd" ]]; then
                        /usr/libexec/PlistBuddy -c "$__cmd" "$domain" 2>/dev/null || true
                    fi
                done
                # Refresh Finder to reflect Finder plist changes
                killall Finder 2>/dev/null || true
                sleep 1
                ;;
            *"-currentHost"*)
                # Handle currentHost types
                if [[ "$action" == "reset" ]]; then
                    # Use delete with -currentHost flag for reset
                    defaults -currentHost delete "$domain" "$key" 2>/dev/null || true
                else
                    # Use write with proper typing for active/inactive
                    write_defaults_typed "$domain" "$key" "$value" "$type"
                fi
                sleep 1
                ;;
            "Two_Finger_Tap_To_Right_Click_AND_Bottom_Right_Click")
                # Handle trackpad tap to right click
                if [[ "$action" == "active" ]]; then
                    defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick -int 2
                    defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick -bool true
                    defaults -currentHost write NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior -int 1
                    defaults -currentHost write NSGlobalDomain com.apple.trackpad.enableSecondaryClick -bool true
                    defaults write com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick -int 2
                    defaults write com.apple.AppleMultitouchTrackpad TrackpadRightClick -bool true
                    echo "👤 ${BO}Note: Please log out for this to take effect.${NC}"
                else
                    if [[ "$action" == "inactive" ]]; then
                        defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick -int 0
                        defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick -bool false
                        defaults -currentHost write NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior -int 0
                        defaults -currentHost write NSGlobalDomain com.apple.trackpad.enableSecondaryClick -bool false
                        defaults write com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick -int 0
                        defaults write com.apple.AppleMultitouchTrackpad TrackpadRightClick -bool false
                        echo "👤 ${BO}Note: Please log out for this to take effect.${NC}"
                    fi
                fi
                sleep 1
                ;;
            "Show_Time_Machine_Menu_Bar_Item")
                # Handle Time Machine Menu Bar item
                if [[ "$action" == "active" ]]; then
                    defaults write com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.TimeMachine" -bool true

                    # Check if TimeMachine is already in menuExtras before adding
                    if ! /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "TimeMachine"; then
                        /usr/libexec/PlistBuddy -c "Add :menuExtras: string '/System/Library/CoreServices/Menu Extras/TimeMachine.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                    fi 
                else [[ "$action" == "inactive" ]]
                    defaults write com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.TimeMachine" -bool false
                    
                    # Find and remove TimeMachine from menuExtras array
                    for i in {0..10}; do
                        item=$(/usr/libexec/PlistBuddy -c "Print :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null)
                        if [[ $item == *"TimeMachine"* ]]; then
                            /usr/libexec/PlistBuddy -c "Delete :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                            break
                        fi
                    done
                fi
                sleep 1
                ;;
            "PasswordManager")
                # Handle Password Menu Bar item
                if [[ "$action" == "active" ]]; then
                    defaults write com.apple.Passwords EnableMenuBarExtra -bool true
                    defaults write com.apple.Passwords.MenuBarExtra "NSStatusItem Visible Item-0" -bool true
                else [[ "$action" == "inactive" ]]
                    defaults write com.apple.Passwords EnableMenuBarExtra -bool false
                    defaults write com.apple.Passwords.MenuBarExtra "NSStatusItem Visible Item-0" -bool false
                fi
                sleep 1
                ;;
            "Show_VPN_Menu_Bar_Item")
                # Handle VPN Menu Bar item
                if [[ "$action" == "active" ]]; then
                    defaults write com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.vpn" -bool true
                    # Check if VPN is already in menuExtras before adding
                    # if ! /usr/libexec/PlistBuddy -c "Print :menuExtras" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null | grep -q "VPN"; then
                    #     /usr/libexec/PlistBuddy -c "Add :menuExtras: string '/System/Library/CoreServices/Menu Extras/VPN.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                    # fi
                    /usr/libexec/PlistBuddy -c "Add :menuExtras: string '/System/Library/CoreServices/Menu Extras/VPN.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                else [[ "$action" == "inactive" ]]
                    defaults write com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.vpn" -bool false
                    
                    # Find and remove VPN from menuExtras array
                    # for i in {0..10}; do
                    #     item=$(/usr/libexec/PlistBuddy -c "Print :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null)
                    #     if [[ $item == *"VPN"* ]]; then
                    #         /usr/libexec/PlistBuddy -c "Delete :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                    #         break
                    #     fi
                    # done
                    /usr/libexec/PlistBuddy -c "Delete :menuExtras: string '/System/Library/CoreServices/Menu Extras/VPN.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                fi
                sleep 1
                ;;
            "disable_Apple_Intelligence")
                # Handle Apple Intelligence
                if [[ "$action" == "active" ]]; then
                    for key in $(defaults read com.apple.CloudSubscriptionFeatures.optIn 2>/dev/null | grep -E "^\s+[0-9]+ = 1;" | awk '{print $1}'); do
                        defaults write com.apple.CloudSubscriptionFeatures.optIn "$key" -bool false
                    done
                else [[ "$action" == "inactive" ]]
                    for key in $(defaults read com.apple.CloudSubscriptionFeatures.optIn 2>/dev/null | grep -E "^\s+[0-9]+ = 0;" | awk '{print $1}'); do
                        defaults write com.apple.CloudSubscriptionFeatures.optIn "$key" -bool true
                    done
                fi
                sleep 1
                ;;
            "Remote_Management_Menu_Bar")
                # Handle Remote Management Menu Bar
                if [[ "$action" == "active" ]]; then
                    # Only show warning if sudo credentials aren't cached
                    if ! sudo -n true 2>/dev/null; then
                        echo "📝 This requires sudo privileges. Please type your admin password, then press enter."
                    fi
                    sudo defaults write /Library/Preferences/com.apple.RemoteManagement.plist LoadRemoteManagementMenuExtra -bool true
                else
                    if [[ "$action" == "inactive" ]]; then
                        # Only show warning if sudo credentials aren't cached
                        if ! sudo -n true 2>/dev/null; then
                            echo "📝 This requires sudo privileges. Please type your admin password then press enter."
                        fi
                        sudo defaults write /Library/Preferences/com.apple.RemoteManagement.plist LoadRemoteManagementMenuExtra -bool false
                    fi
                fi
                sleep 1
                ;;
            "chflags")
                if [[ "$key" == "ShowLibrary" ]]; then
                    if [[ "$action" == "active" ]]; then
                        chflags nohidden ~/Library 2>/dev/null || true
                        xattr -d com.apple.FinderInfo ~/Library 2>/dev/null || true
                    else
                        chflags hidden ~/Library 2>/dev/null || true
                    fi
                fi
                sleep 1
                ;;
            "sudo")
                if [[ "$key" == "schedule" ]]; then
                    if [[ "$action" == "active" ]]; then
                        sudo softwareupdate --schedule on
                    else
                        sudo softwareupdate --schedule off
                    fi
                else
                    if [[ "$type" == "SoftwareUpdates" ]]; then
                        sudo defaults write "$domain" "$key" "$value"
                    fi
                fi
                ;;
            "launchctl")
                # No defaults write; handled in restart block
                sleep 1
                ;;
            *)
                write_defaults_typed "$domain" "$key" "$value" "$type"
                sleep 1
                ;;
        esac
        
        # Restart affected services
        case "$domain" in
            "com.apple.dock")
                killall Dock 2>/dev/null || true
                echo "${YE}Restarted Dock...${NC}"
                ;;
            "com.apple.finder")
                killall Finder 2>/dev/null || true
                echo "${YE}Restarted Finder...${NC}"
                ;;
            "com.apple.screencapture")
                killall SystemUIServer 2>/dev/null || true
                echo "${YE}Restarted SystemUIServer...${NC}"
                ;;
            "com.apple.controlcenter")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.menuextra.clock")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.systemuiserver")
                # killall ControlCenter 2>/dev/null || true
                killall SystemUIServer 2>/dev/null || true
                ;;
            "com.apple.universalcontrol")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.universalaccess")
                killall UniversalAccessApp 2>/dev/null || true
                # killall UniversalAccessAuthWarning 2>/dev/null || true
                # killall "System Preferences" 2>/dev/null
                echo "${YE}Restarted UniversalAccess...${NC}"
                ;;
            "NSGlobalDomain")
                killall SystemUIServer 2>/dev/null || true
                echo "${YE}Restarted SystemUIServer...${NC}"
                ;;
            "launchctl")
                if [[ "$action" == "active" ]]; then
                    launchctl load -w "$key" 2>/dev/null || true
                else
                    launchctl unload -w "$key" 2>/dev/null || true
                fi
                ;;
        esac
        
        # echo "${GR}✅ $action completed successfully!${NC}"
        # echo "${GR}✅ Done!${NC}"        
        sleep 0.5
    }

    # Helper function to reset preference to default
    reset_preference_to_default() {
        local domain="$1"
        local key="$2"
        local reset_cmd="$3"
        local type="$4"
        
        echo
        # echo "${YE}Resetting $key to default...${NC}"
        echo "${YE}Applying changes...${NC}"  
        
        # Handles type cases
        case "$type" in
            "delete")
                defaults delete "$domain" "$key" 2>/dev/null || true
                ;;
            "chflags")
                if [[ "$key" == "ShowLibrary" ]]; then
                    chflags hidden ~/Library 2>/dev/null || true
                fi
                ;;
            *"-currentHost"*)
                # Handle currentHost types
                if [[ "$action" == "reset" ]]; then
                    # Use delete with -currentHost flag for reset
                    defaults -currentHost delete "$domain" "$key" 2>/dev/null || true
                else
                    # Use write with proper typing for active/inactive
                    write_defaults_typed "$domain" "$key" "$value" "$type"
                fi
                ;;
            "Two_Finger_Tap_To_Right_Click_AND_Bottom_Right_Click")
                # Handle trackpad tap to right click
                if [[ "$action" == "reset" ]]; then
                    defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadCornerSecondaryClick -int 0
                    defaults write com.apple.driver.AppleBluetoothMultitouch.trackpad TrackpadRightClick -bool false
                    defaults -currentHost write NSGlobalDomain com.apple.trackpad.trackpadCornerClickBehavior -int 0
                    defaults -currentHost write NSGlobalDomain com.apple.trackpad.enableSecondaryClick -bool false
                    defaults write com.apple.AppleMultitouchTrackpad TrackpadCornerSecondaryClick -int 0
                    defaults write com.apple.AppleMultitouchTrackpad TrackpadRightClick -bool false
                    echo "👤 ${BO}Note: Please log out for this to take effect.${NC}"
                else
                    echo "⚠️  ${BO}Could not reset to default: Two-Finger Tap To Right Click/Bottom Right Click.${NC}"
                fi
                ;;
            "Show_Time_Machine_Menu_Bar_Item")
                # Handle VPN Menu Bar item
                # if [[ "$key" == "Show_VPN_Menu_Bar_Item" ]]; then
                defaults delete com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.TimeMachine" 2>/dev/null
                
                # Find and remove VPN from menuExtras array
                # for i in {0..10}; do
                #     item=$(/usr/libexec/PlistBuddy -c "Print :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null)
                #     if [[ $item == *"VPN"* ]]; then
                #         /usr/libexec/PlistBuddy -c "Delete :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                #         break
                #     fi
                # done
                /usr/libexec/PlistBuddy -c "Delete :menuExtras: string '/System/Library/CoreServices/Menu Extras/TimeMachine.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null  
                # else
                #     echo "⚠️ ${BO}Could not reset to default: VPN Menu Bar item.${NC}"
                # fi
                ;;
            "Show_VPN_Menu_Bar_Item")
                # Handle VPN Menu Bar item
                # if [[ "$key" == "Show_VPN_Menu_Bar_Item" ]]; then
                defaults delete com.apple.systemuiserver "NSStatusItem Visible com.apple.menuextra.vpn" 2>/dev/null
                
                # Find and remove VPN from menuExtras array
                # for i in {0..10}; do
                #     item=$(/usr/libexec/PlistBuddy -c "Print :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null)
                #     if [[ $item == *"VPN"* ]]; then
                #         /usr/libexec/PlistBuddy -c "Delete :menuExtras:$i" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                #         break
                #     fi
                # done
                /usr/libexec/PlistBuddy -c "Delete :menuExtras: string '/System/Library/CoreServices/Menu Extras/VPN.menu'" ~/Library/Preferences/com.apple.systemuiserver.plist 2>/dev/null
                    
                # else
                #     echo "⚠️ ${BO}Could not reset to default: VPN Menu Bar item.${NC}"
                # fi
                ;;
            "Remote_Management_Menu_Bar")
                # Handle Remote Management Menu Bar
                if [[ "$action" == "reset" ]]; then
                    # Only show warning if sudo credentials aren't cached
                    if ! sudo -n true 2>/dev/null; then
                        echo "📝 This requires sudo privileges. Please type your admin password, then press enter."
                    fi
                    sudo defaults write /Library/Preferences/com.apple.RemoteManagement.plist LoadRemoteManagementMenuExtra -bool false
                else
                    echo "⚠️ ${BO}Could not reset Remote Management Menu Bar icon.${NC}"
                fi
                ;;
            "sudo")
                if [[ "$key" == "schedule" ]]; then
                    sudo softwareupdate --schedule on
                fi
                ;;
        esac
        
        # Restart affected services
        case "$domain" in
            "com.apple.dock")
                killall Dock 2>/dev/null || true
                echo "${YE}Restarted Dock...${NC}"
                ;;
            "com.apple.finder")
                killall Finder 2>/dev/null || true
                echo "${YE}Restarted Finder...${NC}"
                ;;
            "com.apple.screencapture")
                killall SystemUIServer 2>/dev/null || true
                echo "${YE}Restarted SystemUIServer...${NC}"
                ;;
            "com.apple.controlcenter")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.menuextra.clock")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.systemuiserver")
                # killall ControlCenter 2>/dev/null || true
                killall SystemUIServer 2>/dev/null || true
                ;;
            "com.apple.universalcontrol")
                killall SystemUIServer 2>/dev/null || true
                killall ControlCenter 2>/dev/null || true
                echo "${YE}Restarted ControlCenter & SystemUIServer...${NC}"
                ;;
            "com.apple.universalaccess")
                killall UniversalAccessApp 2>/dev/null || true
                # killall UniversalAccessAuthWarning 2>/dev/null || true
                # killall "System Preferences" 2>/dev/null
                echo "${YE}Restarted UniversalAccess...${NC}"
                ;;
            "NSGlobalDomain")
                killall SystemUIServer 2>/dev/null || true
                echo "${YE}Restarted SystemUIServer...${NC}"
                ;;
        esac
        
        # echo "${GR}✅ Reset back to default${NC}"
        sleep 2
    }
        
    # Show Info (Loop 1)
    while true; do    
        clear
        # echo "Show Info (Loop 1)"
        # sleep 1
        echo "${GR}=====================${NC}"
        echo "${BO}14) ⚙️  MacOS Defaults${NC}"
        echo "${GR}=====================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        # Warning about Terminal.app access request (show only once per session)
        if [[ -z "$TERMINAL_ACCESS_WARNING_SHOWN" ]]; then
            # echo "--------------------------------------------------------------------------------"
            echo "ℹ️  This sub-menu allows you to change over 150+ default macOS preferences"
            echo "   as well as show their active/inactive status."
            echo
            echo "Ex. ✅ ${GR}[Active]${NC} | ❌ ${RE}[Inactive]${NC} | ❔ ${YE}[Default/Not Set]${NC}"
            echo
            echo "   If a status shows '"${YE}[Default/Not Set]${NC}"', this will usually change after"
            echo "   applying 1 of the following 3 available options:"
            echo
            echo "1) ${GR}✅ Activate${NC} 2) ${RE}❌ Deactivate${NC} 3) ${YE}🔄 Reset to Default${NC} <- (If available)"
            echo
            echo
            echo "📝 ${BO}Instructions:${NC}"
            echo "Step 1. Press Enter at this first step to generate the list of preferences." # (this page wont show again until the script is quit.)
            echo "Step 2. Once the preferences load, press Enter to 'cache' the results,"
            echo "        (allowing them to load faster at next step)"
            echo "Step 3. Choose from one of the preferences by typing their number, then press"
            echo "        Enter to view more details."
            echo "Step 4. Review and choose an option. (status's here will refresh automatically)"
            echo "Step 5. Press b once to go back to Step 3, or again to refresh list at Step 2."
            echo
            echo
            echo "Some changes may require logging out or restarting to take effect."
            echo "${YE}(You'll be prompted if this is the case)${NC}"
            echo
            echo "${BO}For best results, please quit all other open applications.${NC}"
            echo
            echo "--------------------------------------------------------------------------------"
            echo "⚠️  ${YE}Note:${NC}"
            echo "Terminal may request access to other apps to check current preference states."
            echo "This is required to display the current status of these macOS preferences:"
            echo "- ${BO}TextEdit${NC}"
            echo "- ${BO}QuickTime${NC}"
            echo
            echo "Additionally, Terminal requires ${BO}Full Disk Access${NC} to read/write preferences for:"
            echo "- ${BO}Safari"
            echo "- ${BO}Accessibility${NC}"
            # echo
            echo "--------------------------------------------------------------------------------"
            # show_navigation_prompt
            # echo "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: "
            # read -rp "" input
            echo
            read -rp "1. ${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
            handle_navigation_input "$input"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then 
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then 
                break 1
            fi
            #TERMINAL_ACCESS_WARNING_SHOWN="true"
        fi
        
        # Display all preferences with current state (Loop 2)
        while true; do
            clear
            # echo "Display all preferences with current state (Loop 2)"
            # sleep 1
            echo "${GR}=====================${NC}"
            echo "${BO}14) ⚙️  MacOS Defaults${NC}  ${CY}Legend: ✅ Active | ❌ Inactive | ❔ Default/Not Set${NC}"
            echo "${GR}=====================${NC}"
            show_navigation_prompt # already padded

            # Display all preferences with current state
            echo "${GR}Available preferences:${NC}"
            local i=1
            local visible_indices=()
            local preference_states=()  # Cache the states for fast mode
            local idx
            local current_group=""


            for idx in "${!preference_commands[@]}"; do
                local pref="${preference_commands[$idx]}"
                # Handle group headers (format: GROUP|Title|Subtext)
                if [[ "$pref" == GROUP\|* ]]; then
                    IFS='|' read -r _ group_title group_subtext <<< "$pref"
                    current_group="$group_title"   # <- track group
                    echo
                    # echo "${BO}$group_title${NC}"
                    if [[ -n "$group_subtext" ]]; then
                        echo "${BO}$group_title${NC}  $group_subtext"
                    else
                        echo "${BO}$group_title${NC}"
                    fi
                    continue
                fi

                IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"

                # Get FRESH state (this is the slow part)
                local current_state=$(get_preference_current_state "$domain" "$key" "$type" "$active_val" "$inactive_val")
                preference_states[$((i-1))]="$current_state"  # Cache it

                local status_icon="❔ ${YE}[Default/Not Set]${NC}"
                if [[ "$current_state" == "active" ]]; then
                    status_icon="✅ ${GR}[Active]${NC}"
                elif [[ "$current_state" == "inactive" ]]; then
                    status_icon="❌ ${RE}[Inactive]${NC}"
                fi

                printf "%2d) %s %s\n" "$i" "$name" "$status_icon"
                visible_indices[$((i-1))]="$idx"
                visible_groups[$((i-1))]="$current_group"   # store group title
                ((i++))
            done

            show_navigation_prompt # already padded
            # echo "${GR}Available preferences:${NC} ${CY}(using cached states)${NC}"
            echo -e "2. ${GR}Press Enter to first cache results (or ${BL}navigation${NC} ${GR}choice)${NC}:"
            echo -e "   ${YE}This allows for faster loading time at the next step.${NC}"
            echo -e "   ${YE}Come back here to refresh at any time by pressing 'b'.${NC}"
            read -rp "" choice
            # Check for navigation input first
            handle_navigation_input "$choice"
            nav=$?
            if [[ $nav -eq $NAV_QUIT ]]; then
                return 0
            elif [[ $nav -eq $NAV_BACK ]]; then
                break 1 # Exit this while loop, back to main 
            fi

            # Fast Mode (Loop 3) - Uses cached states
            while true; do
                clear
                # echo "Fast Mode (Loop 3) - Uses cached states"
                # sleep 1
                echo "${GR}=====================${NC}"
                echo "${BO}14) ⚙️  MacOS Defaults${NC}  ${CY}Legend: ✅ Active | ❌ Inactive | ❔ Default/Not Set ${YE}[Cached]${NC}"
                echo "${GR}=====================${NC}"
                show_navigation_prompt
                
                # Display all preferences using CACHED states (FAST)
                echo "${GR}Available preferences:${NC} ⚠️  ${RE}(displaying cached results) ${YE}[Press ${GR}b ${YE}to refresh]${NC}"
                local display_i=1
                local current_group=""
                
                for idx in "${!preference_commands[@]}"; do
                    local pref="${preference_commands[$idx]}"
                    if [[ "$pref" == GROUP\|* ]]; then
                        IFS='|' read -r _ group_title group_subtext <<< "$pref"
                        current_group="$group_title"
                        echo
                        if [[ -n "$group_subtext" ]]; then
                            echo "${BO}$group_title${NC} 🔒 ${RE}[Cached]${NC} $group_subtext"
                        else
                            echo "${BO}$group_title${NC} 🔒 ${RE}[Cached]${NC}"
                        fi
                        continue
                    fi
                    
                    IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
                    
                    # Use CACHED state (no fresh calls)
                    local cached_state="${preference_states[$((display_i-1))]}"
                    local status_icon="❔ ${YE}[Default/Not Set]${NC}"
                    if [[ "$cached_state" == "active" ]]; then
                        status_icon="✅ ${GR}[Active]${NC}"
                    elif [[ "$cached_state" == "inactive" ]]; then
                        status_icon="❌ ${RE}[Inactive]${NC}"
                    fi
                    
                    printf "%2d) %s %s\n" "$display_i" "$name" "$status_icon"
                    ((display_i++))
                done

                # echo " Main Choice Selection (Loop 4)"
                # sleep 1
                local max_choice=${#visible_indices[@]}
                echo
                echo -e "🔒 ${RE}Displaying cached results ${YE}[press ${GR}b ${YE}to refresh]${NC}"
                echo -e "   ${YE}(Updated statuses will always be shown in the next (or previous) step).${NC}"
                show_navigation_prompt # already padded
                echo -e "3. ${GR}Select a preference${NC} (1-$max_choice) ${GR}(or ${BL}navigation${NC} ${GR}choice)${NC}: "
                read -rp "" choice

                # Check for navigation input first
                handle_navigation_input "$choice"
                nav=$?
                if [[ $nav -eq $NAV_QUIT ]]; then
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then
                    break
                fi

                if [[ "$choice" =~ ^[0-9]+$ ]] && [[ $choice -ge 1 ]] && [[ $choice -le $max_choice ]]; then
                    local arr_idx="${visible_indices[$((choice-1))]}"
                    local current_group="${visible_groups[$((choice-1))]}"   # <- grab group here
                    local selected_pref="${preference_commands[$arr_idx]}"
                    IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$selected_pref"
                else
                    echo "❌ ${RE}Invalid option. Please choose 1-$max_choice.${NC}"
                    sleep 1
                    continue
                fi
                # Main Choice Selection (Loop 4)
                # while true; do
                #     echo " Main Choice Selection (Loop 4)"
                #     sleep 1
                #     local max_choice=${#visible_indices[@]}
                #     show_navigation_prompt # already padded
                #     read -rp "➡️  ${GR}Select a preference${NC} (1-$max_choice) ${GR}(or ${BL}navigation${NC} ${GR}choice)${NC}: " choice
                    
                #     # Check for navigation input first
                #     handle_navigation_input "$choice"
                #     nav=$?
                #     if [[ $nav -eq $NAV_QUIT ]]; then
                #         return 0
                #     elif [[ $nav -eq $NAV_BACK ]]; then
                #         break
                #     fi

                #     if [[ "$choice" =~ ^[0-9]+$ ]] && [[ $choice -ge 1 ]] && [[ $choice -le $max_choice ]]; then
                #         local arr_idx="${visible_indices[$((choice-1))]}"
                #         local current_group="${visible_groups[$((choice-1))]}"   # <- grab group here
                #         local selected_pref="${preference_commands[$arr_idx]}"
                #         IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$selected_pref"
                #     else
                #         echo "❌ ${RE}Invalid option. Please choose 1-$max_choice.${NC}"
                #         sleep 1
                #         continue
                #     fi

                # Show Individual Preference States/Options (Loop 5)
                while true; do
                    clear
                    # echo " Main Choice Selection (Loop 5)"
                    # sleep 1
                    echo "${GR}================================================================================${NC}"
                    echo "${BO}$current_group${NC}"
                    # printf "%+3s %s\n" "${BO}$current_group${NC}"
                    # echo "${NC}Choice: $choice) $name${NC}"
                    # printf "Choice: %-3s %s\n" "$choice)" "$name"
                    # printf "%-3s %s\n" "$choice)" "$name"
                    printf "%-3s %s\n" "$choice)" "$name"
                    # echo "$choice) $name"
                    echo "${GR}================================================================================${NC}"
                    echo "${CY}Description:${NC} $desc"
                    echo
                    
                    # Show current state
                    local current_state=$(get_preference_current_state "$domain" "$key" "$type" "$active_val" "$inactive_val")
                    local current_value=$(get_preference_current_value "$domain" "$key" "$type")
                    echo "${BO}Current State:${NC} ${YE}(refreshes automatically)${NC}"
                    if [[ "$current_state" == "active" ]]; then
                        echo "  Status: ✅ ${GR}Active${NC}"
                    elif [[ "$current_state" == "inactive" ]]; then
                        echo "  Status: ❌ ${RE}Inactive${NC}"
                    else
                        echo "  Status: ❔ ${YE}Default/Not Set${NC}"
                    fi
                    if [[ -n "$current_value" ]]; then
                        echo "  Value:  $current_value"
                        echo "  Key:    $key"
                        echo "  Domain: $domain"
                        # echo "  Type:   $type"
                    fi
                    
                    # local read_display_ch=$(defaults -currentHost read "$domain" | grep "$key" 2>/dev/null || true)
                    # local read_display=$(defaults read "$domain" | grep "$key" 2>/dev/null || true)
                    # if [[ -z "$read_display" ]]; then
                    #     echo "  Key:    $read_display_ch"
                    # else
                    #     echo "  Key:    $read_display"
                    # fi
                    # echo "$read_display_ch"
                    # echo "$read_display"

                    # if [[$(defaults read "$domain" "$key")]]
                    echo
                    # Display actions
                    echo "${BO}Available actions:${NC}"
                    echo "1) ✅ ${GR}Activate${NC} (sets to: "$active_val")"
                    echo "2) ❌ ${RE}Deactivate${NC} (sets to: "$inactive_val")"
                    if [[ -n "$reset_cmd" ]]; then
                        echo "3) 🔄 ${YE}Reset to Default${NC} (sets to: "$reset_cmd")"
                    fi
                    show_navigation_prompt
                    
                    read -rp "4. ${GR}Select action (or ${BL}navigation${NC} ${GR}choice)${NC}: " action_choice
                    
                    # Check for navigation input first
                    handle_navigation_input "$action_choice"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break  # Exit this while loop, back to preference selection
                    fi

                    # Apply Actions (Loop 5)
                    while true; do
                        case $action_choice in
                            1)
                                if apply_preference_change "$domain" "$key" "$active_val" "$type" "active"; then
                                    echo "✅ ${GR}Preference activated successfully!${NC}"
                                    echo "🔄 Refreshing state..."
                                else
                                    echo "❌ ${RE}Failed to activate preference.${NC}"
                                    echo "Please try again..."
                                fi
                                sleep 1
                                break
                                ;;
                            2)
                                if apply_preference_change "$domain" "$key" "$inactive_val" "$type" "inactive"; then
                                    echo "✅ ${GR}Preference deactivated successfully!${NC}"
                                    echo "🔄 Refreshing state..."
                                else
                                    echo "❌ ${RE}Failed to deactivate preference.${NC}"
                                    echo "Please try again..."
                                fi
                                sleep 1
                                break
                                ;;
                            3)
                                if [[ -n "$reset_cmd" ]]; then
                                    if reset_preference_to_default "$domain" "$key" "$reset_cmd" "$type"; then
                                        echo "✅ ${GR}Preference reset to default successfully!${NC}"
                                        echo "🔄 Refreshing state..."
                                    else
                                        echo "❌ ${RE}Failed to reset preference.${NC}"
                                        echo "Please try again..."
                                    fi
                                    sleep 1
                                    break
                                else
                                    echo "❌ ${RE}Reset not available for this preference.${NC}"
                                    sleep 1
                                    break
                                fi
                                ;;
                            *)
                                echo "❌ ${RE}Invalid option. Please try again.${NC}"
                                sleep 1
                                break
                                ;;
                        esac
                        # Summary (Loop 7)
                        # while true; do
                        #     echo
                        #     show_navigation_prompt
                        #     read -rp "➡️  ${GR}Process another preference? Press Enter (or ${BL}navigation${NC}): " input
                        #     handle_navigation_input "$input"
                        #     nav=$?
                        #     if [[ $nav -eq $NAV_QUIT ]]; then
                        #         return 0
                        #     elif [[ $nav -eq $NAV_BACK ]]; then
                        #         break 2  # Exit this while loop, back to action
                        #     else
                        #         continue 5  # Continue to main selection method menu
                        #     fi
                        # done    
                    done    
                done
                
            done    
        done    
    done

        # Show the selection method options
        # while true; do
        #     echo "${BO}Choose selection method:${NC}"
        #     echo "1)  ${GR}📋${NC} Single preference (with options)"
        #     echo "2)  ${GR}🔢${NC} Multiple preferences (comma/range separated)"
        #     echo "3)  ${GR}📊${NC} Show current states of all preferences"
        #     echo
            
        #     read -rp "➡️  ${GR}Select option (1-3): ${NC}" choice
            
        #     handle_navigation_input "$choice"
        #     nav=$?
        #     if [[ $nav -eq $NAV_QUIT ]]; then
        #         return 0
        #     elif [[ $nav -eq $NAV_BACK ]]; then
        #         break 3
        #     fi

        #         # Single preference selection (Loop 3)
        #         while true; do
        #             clear
        #             echo "${GR}===========================${NC}"
        #             echo "${NC}Single Preference Selection${NC}"
        #             echo "${GR}===========================${NC}"
        #             show_navigation_prompt
                    
        #             # Display all preferences with current state
        #             echo "${BO}Available preferences:${NC}"
        #             local i=1
        #             for pref in "${preference_commands[@]}"; do
        #                 IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
        #                 local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        #                 local status_icon="❔"
        #                 if [[ "$current_state" == "activated" ]]; then
        #                     status_icon="✅"
        #                 elif [[ "$current_state" == "deactivated" ]]; then
        #                     status_icon="❌"
        #                 fi
        #                 printf "%2d) %s %s\n" "$i" "$name" "$status_icon"
        #                 ((i++))
        #             done
        #             echo
                    
        #             read -rp "➡️  ${GR}Select preference (1-42): ${NC}" choice
                    
        #             # Check for navigation input first
        #             handle_navigation_input "$choice"
        #             nav=$?
        #             if [[ $nav -eq $NAV_QUIT ]]; then
        #                 return 0
        #             elif [[ $nav -eq $NAV_BACK ]]; then
        #                 break 2 # Exit this while loop, back to main selection method menu
        #             fi
                    
        #             if [[ "$choice" =~ ^[0-9]+$ ]] && [[ $choice -ge 1 ]] && [[ $choice -le 42 ]]; then
        #                 local selected_pref="${preference_commands[$((choice-1))]}"
        #                 IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$selected_pref"
                        
        #                 # Show preference options
        #                 while true; do
        #                     clear
        #                     echo "${GR}========================${NC}"
        #                     echo "${NC}Preference: $name${NC}"
        #                     echo "${GR}========================${NC}"
        #                     echo "${CY}Description:${NC} $desc"
        #                     echo
                            
        #                     # Show current state
        #                     local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        #                     local current_value=$(get_preference_current_value "$domain" "$key" "$type")
        #                     echo "${BO}Current State:${NC}"
        #                     if [[ "$current_state" == "activated" ]]; then
        #                         echo "  Status: ${GR}✅ Activated${NC}"
        #                     elif [[ "$current_state" == "deactivated" ]]; then
        #                         echo "  Status: ${RE}❌ Deactivated${NC}"
        #                     else
        #                         echo "  Status: ${YE}❔ Default/Unknown${NC}"
        #                     fi
        #                     if [[ -n "$current_value" ]]; then
        #                         echo "  Value: $current_value"
        #                     fi
        #                     echo
                            
        #                     echo "${BO}Available actions:${NC}"
        #                     echo "1) ${GR}✅ Activate${NC}"
        #                     echo "2) ${RE}❌ Deactivate${NC}"
        #                     if [[ -n "$reset_cmd" ]]; then
        #                         echo "3) ${YE}🔄 Reset to Default${NC}"
        #                     fi
        #                     echo
                            
        #                     read -rp "➡️  ${GR}Select action: ${NC}" action_choice
                            
        #                     # Check for navigation input first
        #                     handle_navigation_input "$action_choice"
        #                     nav=$?
        #                     if [[ $nav -eq $NAV_QUIT ]]; then
        #                         return 0
        #                     elif [[ $nav -eq $NAV_BACK ]]; then
        #                         break 4  # Exit this while loop, back to preference selection
        #                     fi
                            
        #                     case $action_choice in
        #                         1)
        #                             if apply_preference_change "$domain" "$key" "$active_val" "$type" "active"; then
        #                                 echo "✅ ${GR}Preference activated successfully!${NC}"
        #                             else
        #                                 echo "❌ ${RE}Failed to activate preference.${NC}"
        #                             fi
        #                             break
        #                             ;;
        #                         2)
        #                             if apply_preference_change "$domain" "$key" "$inactive_val" "$type" "inactive"; then
        #                                 echo "✅ ${GR}Preference deactivated successfully!${NC}"
        #                             else
        #                                 echo "❌ ${RE}Failed to deactivate preference.${NC}"
        #                             fi
        #                             break
        #                             ;;
        #                         3)
        #                             if [[ -n "$reset_cmd" ]]; then
        #                                 if reset_preference_to_default "$domain" "$key" "$reset_cmd" "$type"; then
        #                                     echo "✅ ${GR}Preference reset to default successfully!${NC}"
        #                                 else
        #                                     echo "❌ ${RE}Failed to reset preference.${NC}"
        #                                 fi
        #                                 break
        #                             else
        #                                 echo "❌ ${RE}Reset not available for this preference.${NC}"
        #                                 sleep 1
        #                                 continue
        #                             fi
        #                             ;;
        #                         *)
        #                             echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
        #                             sleep 1
        #                             continue
        #                             ;;
        #                     esac
        #                 done
                        
        #                 echo
        #                 show_navigation_prompt
        #                 read -rp "➡️  ${GR}Process another preference? Press Enter (or ${BL}navigation${NC}): " input
        #                 handle_navigation_input "$input"
        #                 nav=$?
        #                 if [[ $nav -eq $NAV_QUIT ]]; then
        #                     return 0
        #                 elif [[ $nav -eq $NAV_BACK ]]; then
        #                     break 3  # Exit this while loop, back to main selection method menu
        #                 else
        #                     continue  # Continue with same preference selection
        #                 fi
                        
        #             else
        #                 echo "❌ ${RE}Invalid option. Please choose 1-42.${NC}"
        #                 sleep 1
        #                 continue
        #             fi
        #         done

        # # case $choice in
        # #     1)
        # #         # Single preference selection
        # #         while true; do
        # #             clear
        # #             echo "${GR}===========================${NC}"
        # #             echo "${NC}Single Preference Selection${NC}"
        # #             echo "${GR}===========================${NC}"
        # #             show_navigation_prompt
                    
        # #             # Display all preferences with current state
        # #             echo "${BO}Available preferences:${NC}"
        # #             local i=1
        # #             for pref in "${preference_commands[@]}"; do
        # #                 IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
        # #                 local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        # #                 local status_icon="❔"
        # #                 if [[ "$current_state" == "activated" ]]; then
        # #                     status_icon="✅"
        # #                 elif [[ "$current_state" == "deactivated" ]]; then
        # #                     status_icon="❌"
        # #                 fi
        # #                 printf "%2d) %s %s\n" "$i" "$name" "$status_icon"
        # #                 ((i++))
        # #             done
        # #             echo
                    
        # #             read -rp "➡️  ${GR}Select preference (1-42): ${NC}" choice
                    
        # #             # Check for navigation input first
        # #             handle_navigation_input "$choice"
        # #             nav=$?
        # #             if [[ $nav -eq $NAV_QUIT ]]; then
        # #                 return 0
        # #             elif [[ $nav -eq $NAV_BACK ]]; then
        # #                 break 2 # Exit this while loop, back to main selection method menu
        # #             fi
                    
        # #             if [[ "$choice" =~ ^[0-9]+$ ]] && [[ $choice -ge 1 ]] && [[ $choice -le 42 ]]; then
        # #                 local selected_pref="${preference_commands[$((choice-1))]}"
        # #                 IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$selected_pref"
                        
        # #                 # Show preference options
        # #                 while true; do
        # #                     clear
        # #                     echo "${GR}========================${NC}"
        # #                     echo "${NC}Preference: $name${NC}"
        # #                     echo "${GR}========================${NC}"
        # #                     echo "${CY}Description:${NC} $desc"
        # #                     echo
                            
        # #                     # Show current state
        # #                     local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        # #                     local current_value=$(get_preference_current_value "$domain" "$key" "$type")
        # #                     echo "${BO}Current State:${NC}"
        # #                     if [[ "$current_state" == "activated" ]]; then
        # #                         echo "  Status: ${GR}✅ Activated${NC}"
        # #                     elif [[ "$current_state" == "deactivated" ]]; then
        # #                         echo "  Status: ${RE}❌ Deactivated${NC}"
        # #                     else
        # #                         echo "  Status: ${YE}❔ Default/Unknown${NC}"
        # #                     fi
        # #                     if [[ -n "$current_value" ]]; then
        # #                         echo "  Value: $current_value"
        # #                     fi
        # #                     echo
                            
        # #                     echo "${BO}Available actions:${NC}"
        # #                     echo "1) ${GR}✅ Activate${NC}"
        # #                     echo "2) ${RE}❌ Deactivate${NC}"
        # #                     if [[ -n "$reset_cmd" ]]; then
        # #                         echo "3) ${YE}🔄 Reset to Default${NC}"
        # #                     fi
        # #                     echo
                            
        # #                     read -rp "➡️  ${GR}Select action: ${NC}" action_choice
                            
        # #                     # Check for navigation input first
        # #                     handle_navigation_input "$action_choice"
        # #                     nav=$?
        # #                     if [[ $nav -eq $NAV_QUIT ]]; then
        # #                         return 0
        # #                     elif [[ $nav -eq $NAV_BACK ]]; then
        # #                         break 4  # Exit this while loop, back to preference selection
        # #                     fi
                            
        # #                     case $action_choice in
        # #                         1)
        # #                             if apply_preference_change "$domain" "$key" "$active_val" "$type" "active"; then
        # #                                 echo "✅ ${GR}Preference activated successfully!${NC}"
        # #                             else
        # #                                 echo "❌ ${RE}Failed to activate preference.${NC}"
        # #                             fi
        # #                             break
        # #                             ;;
        # #                         2)
        # #                             if apply_preference_change "$domain" "$key" "$inactive_val" "$type" "inactive"; then
        # #                                 echo "✅ ${GR}Preference deactivated successfully!${NC}"
        # #                             else
        # #                                 echo "❌ ${RE}Failed to deactivate preference.${NC}"
        # #                             fi
        # #                             break
        # #                             ;;
        # #                         3)
        # #                             if [[ -n "$reset_cmd" ]]; then
        # #                                 if reset_preference_to_default "$domain" "$key" "$reset_cmd" "$type"; then
        # #                                     echo "✅ ${GR}Preference reset to default successfully!${NC}"
        # #                                 else
        # #                                     echo "❌ ${RE}Failed to reset preference.${NC}"
        # #                                 fi
        # #                                 break
        # #                             else
        # #                                 echo "❌ ${RE}Reset not available for this preference.${NC}"
        # #                                 sleep 1
        # #                                 continue
        # #                             fi
        # #                             ;;
        # #                         *)
        # #                             echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
        # #                             sleep 1
        # #                             continue
        # #                             ;;
        # #                     esac
        # #                 done
                        
        # #                 echo
        # #                 show_navigation_prompt
        # #                 read -rp "➡️  ${GR}Process another preference? Press Enter (or ${BL}navigation${NC}): " input
        # #                 handle_navigation_input "$input"
        # #                 nav=$?
        # #                 if [[ $nav -eq $NAV_QUIT ]]; then
        # #                     return 0
        # #                 elif [[ $nav -eq $NAV_BACK ]]; then
        # #                     break 3  # Exit this while loop, back to main selection method menu
        # #                 else
        # #                     continue  # Continue with same preference selection
        # #                 fi
                        
        # #             else
        # #                 echo "❌ ${RE}Invalid option. Please choose 1-42.${NC}"
        # #                 sleep 1
        # #                 continue
        # #             fi
        # #         done
        # #         ;;
        # #     # 2)
        # #     #     # Multiple preference selection
        # #     #     while true; do
        # #     #         clear
        # #     #         echo "${GR}=============================${NC}"
        # #     #         echo "${NC}Multiple Preference Selection${NC}"
        # #     #         echo "${GR}=============================${NC}"
        # #     #         show_navigation_prompt
                    
        # #     #         # Show all 42 preference options again
        # #     #         echo "${BO}Key:${NC}"
        # #     #         echo "  ${GR}✅${NC} = Active"
        # #     #         echo "  ${RE}❌${NC} = Inactive" 
        # #     #         echo "  ${YE}❔${NC} = Default/Unknown/Not Set"
        # #     #         echo
        # #     #         echo "${BO}Available preferences:${NC}"
        # #     #         local i=1
        # #     #         for pref in "${preference_commands[@]}"; do
        # #     #             IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
        # #     #             local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        # #     #             local status_icon="❔"
        # #     #             if [[ "$current_state" == "activated" ]]; then
        # #     #                 status_icon="✅"
        # #     #             elif [[ "$current_state" == "deactivated" ]]; then
        # #     #                 status_icon="❌"
        # #     #             fi
        # #     #             printf "%2d) %s %s\n" "$i" "$status_icon" "$name"
        # #     #             ((i++))
        # #     #         done
        # #     #         echo
                    
        # #     #         echo "${BO}Selection Format Examples:${NC}"
        # #     #         echo "  • Single: ${GR}5${NC}"
        # #     #         echo "  • Multiple: ${GR}1,3,7${NC}"
        # #     #         echo "  • Range: ${GR}10-15${NC}"
        # #     #         echo "  • Mixed: ${GR}1,5,10-15,20${NC}"
        # #     #         echo
                    
        # #     #         read -rp "➡️  ${GR}Enter preference numbers: ${NC}" input
                    
        # #     #         # Check for navigation input first
        # #     #         handle_navigation_input "$input"
        # #     #         nav=$?
        # #     #         if [[ $nav -eq $NAV_QUIT ]]; then
        # #     #             return 0
        # #     #         elif [[ $nav -eq $NAV_BACK ]]; then
        # #     #             break 3  # Exit this while loop, back to main selection method menu
        # #     #         fi
                    
        # #     #         # Parse the input
        # #     #         local indices=()
        # #     #         local input_parts=(${input//,/ })
                    
        # #     #         for part in "${input_parts[@]}"; do
        # #     #             if [[ "$part" =~ ^([0-9]+)-([0-9]+)$ ]]; then
        # #     #                 local start=${BASH_REMATCH[1]}
        # #     #                 local end=${BASH_REMATCH[2]}
        # #     #                 if [[ $start -le $end ]] && [[ $start -ge 1 ]] && [[ $end -le 42 ]]; then
        # #     #                     for ((i=start; i<=end; i++)); do
        # #     #                         indices+=($i)
        # #     #                     done
        # #     #                 else
        # #     #                     echo "❌ ${RE}Invalid range: $part${NC}"
        # #     #                     sleep 1
        # #     #                     continue 2
        # #     #                 fi
        # #     #             elif [[ "$part" =~ ^[0-9]+$ ]] && [[ $part -ge 1 ]] && [[ $part -le 42 ]]; then
        # #     #                 indices+=($part)
        # #     #             else
        # #     #                 echo "❌ ${RE}Invalid input: $part${NC}"
        # #     #                 sleep 1
        # #     #                 continue 2
        # #     #             fi
        # #     #         done
                    
        # #     #         if [[ ${#indices[@]} -eq 0 ]]; then
        # #     #             echo "❌ ${RE}No valid preferences selected.${NC}"
        # #     #             sleep 1
        # #     #             continue
        # #     #         fi
                    
        # #     #         # Show selected preferences
        # #     #         echo
        # #     #         echo "${BO}Selected preferences:${NC}"
        # #     #         for idx in "${indices[@]}"; do
        # #     #             local pref="${preference_commands[$((idx-1))]}"
        # #     #             IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
        # #     #             echo "  $idx) $name"
        # #     #         done
        # #     #         echo
                    
        # #     #         # Action selection for multiple preferences
        # #     #         while true; do
        # #     #             echo "${BO}Choose action for all selected preferences:${NC}"
        # #     #             echo "1) ${GR}✅ Activate All${NC}"
        # #     #             echo "2) ${RE}❌ Deactivate All${NC}"
        # #     #             echo
                        
        # #     #             read -rp "➡️  ${GR}Select action: ${NC}" action_choice
                        
        # #     #             # Check for navigation input first
        # #     #             handle_navigation_input "$action_choice"
        # #     #             nav=$?
        # #     #             if [[ $nav -eq $NAV_QUIT ]]; then
        # #     #                 return 0
        # #     #             elif [[ $nav -eq $NAV_BACK ]]; then
        # #     #                 break 2  # Exit this while loop, back to preference selection
        # #     #             fi
                        
        # #     #             case $action_choice in
        # #     #                 1)
        # #     #                     local processed_count=0
        # #     #                     local processed_failed=0
                                
        # #     #                     for idx in "${indices[@]}"; do
        # #     #                         local pref="${preference_commands[$((idx-1))]}"
        # #     #                         IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
                                    
        # #     #                         if apply_preference_change "$domain" "$key" "$active_val" "$type" "active"; then
        # #     #                             echo "✅ ${GR}Activated:${NC} $name"
        # #     #                             ((processed_count++))
        # #     #                         else
        # #     #                             echo "❌ ${RE}Failed:${NC} $name"
        # #     #                             ((processed_failed++))
        # #     #                         fi
        # #     #                     done
                                
        # #     #                     echo
        # #     #                     echo "============================"
        # #     #                     echo "${BO}Results:${NC}"
        # #     #                     echo "✅ Total preferences ${GR}activated${NC}: $processed_count"
        # #     #                     echo "⚠️  Total preferences ${RE}failed${NC}: $processed_failed"
        # #     #                     echo "============================"
        # #     #                     break
        # #     #                     ;;
        # #     #                 2)
        # #     #                     local processed_count=0
        # #     #                     local processed_failed=0
                                
        # #     #                     for idx in "${indices[@]}"; do
        # #     #                         local pref="${preference_commands[$((idx-1))]}"
        # #     #                         IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
                                    
        # #     #                         if apply_preference_change "$domain" "$key" "$inactive_val" "$type" "inactive"; then
        # #     #                             echo "✅ ${GR}Deactivated:${NC} $name"
        # #     #                             ((processed_count++))
        # #     #                         else
        # #     #                             echo "❌ ${RE}Failed:${NC} $name"
        # #     #                             ((processed_failed++))
        # #     #                         fi
        # #     #                     done
                                
        # #     #                     echo
        # #     #                     echo "============================"
        # #     #                     echo "${BO}Results:${NC}"
        # #     #                     echo "✅ Total preferences ${GR}deactivated${NC}: $processed_count"
        # #     #                     echo "⚠️  Total preferences ${RE}failed${NC}: $processed_failed"
        # #     #                     echo "============================"
        # #     #                     break
        # #     #                     ;;
        # #     #                 *)
        # #     #                     echo "❌ ${RE}Invalid option. Please choose 1 or 2.${NC}"
        # #     #                     sleep 1
        # #     #                     continue
        # #     #                     ;;
        # #     #             esac
        # #     #         done
                    
        # #     #         echo
        # #     #         show_navigation_prompt
        # #     #         read -rp "➡️  ${GR}Process another batch? Press Enter (or ${BL}navigation${NC}): " input
        # #     #         handle_navigation_input "$input"
        # #     #         nav=$?
        # #     #         if [[ $nav -eq $NAV_QUIT ]]; then
        # #     #             return 0
        # #     #         elif [[ $nav -eq $NAV_BACK ]]; then
        # #     #             break 3  # Exit this while loop, back to main selection method menu
        # #     #         else
        # #     #             continue 3  # Continue with same batch selection
        # #     #         fi
        # #     #     done
        # #     #     ;;
        # #     # 3)
        # #     #     # Show current states of all preferences
        # #     #     while true; do
        # #     #         clear
        # #     #         echo "${GR}=========================${NC}"
        # #     #         echo "${BO}Current Preference States${NC}"
        # #     #         echo "${GR}=========================${NC}"
        # #     #         echo
                    
        # #     #         echo "${BO}Current states of all preferences:${NC}"
        # #     #         echo "${CY}Legend: ✅ Activated | ❌ Deactivated | ⚪ Default | 🔧 Custom | ❔ Unknown${NC}"
        # #     #         echo
        # #     #         echo "${YE}Reading preference states...${NC}"
        # #     #         local i=1
        # #     #         for pref in "${preference_commands[@]}"; do
        # #     #             IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
                        
        # #     #             # Show progress for long operations
        # #     #             printf "\r${CY}Processing preference %d/%d...${NC}" "$i" "${#preference_commands[@]}"
        # #     #             printf "\n"
                        
        # #     #             local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        # #     #             local current_value=$(get_preference_current_value "$domain" "$key" "$type")
        # #     #             local status_icon="⚪"
        # #     #             case "$current_state" in
        # #     #                 "activated")
        # #     #                     status_icon="✅"
        # #     #                     ;;
        # #     #                 "deactivated")
        # #     #                     status_icon="❌"
        # #     #                     ;;
        # #     #                 "default")
        # #     #                     status_icon="⚪"
        # #     #                     ;;
        # #     #                 "custom")
        # #     #                     status_icon="🔧"
        # #     #                     ;;
        # #     #                 "unknown")
        # #     #                     status_icon="❔"
        # #     #                     ;;
        # #     #                 *)
        # #     #                     status_icon="⚪"
        # #     #                     ;;
        # #     #             esac
                        
        # #     #             # Format the output cleanly with proper spacing
        # #     #             if [[ -n "$current_value" ]] && [[ "$current_value" != "not set" ]]; then
        # #     #                 printf "%2d) %s %-40s ${CY}(%s)${NC}\n" "$i" "$status_icon" "$name" "$current_value"
        # #     #             else
        # #     #                 printf "%2d) %s %-40s\n" "$i" "$status_icon" "$name"
        # #     #             fi
        # #     #             ((i++))
        # #     #         done
                    
        # #     #         # Add summary counts
        # #     #         echo
        # #     #         echo "${GR}========================${NC}"
        # #     #         echo "${BO}Summary:${NC}"
        # #     #         local activated_count=0
        # #     #         local deactivated_count=0
        # #     #         local default_count=0
        # #     #         local custom_count=0
        # #     #         local unknown_count=0
                    
        # #     #         for pref in "${preference_commands[@]}"; do
        # #     #             IFS='|' read -r name domain key active_val inactive_val reset_cmd type desc <<< "$pref"
        # #     #             local current_state=$(get_preference_current_state "$domain" "$key" "$type")
        # #     #             case "$current_state" in
        # #     #                 "activated") ((activated_count++)) ;;
        # #     #                 "deactivated") ((deactivated_count++)) ;;
        # #     #                 "default") ((default_count++)) ;;
        # #     #                 "custom") ((custom_count++)) ;;
        # #     #                 "unknown") ((unknown_count++)) ;;
        # #     #             esac
        # #     #         done
                    
        # #     #         echo "✅ Activated: ${GR}$activated_count${NC}"
        # #     #         echo "❌ Deactivated: ${RE}$deactivated_count${NC}"
        # #     #         echo "⚪ Default: ${CY}$default_count${NC}"
        # #     #         echo "🔧 Custom: ${YE}$custom_count${NC}"
        # #     #         echo "❔ Unknown: ${BL}$unknown_count${NC}"
        # #     #         echo "${GR}========================${NC}"
        # #     #         echo
                    
        # #     #         show_navigation_prompt
        # #     #         read -rp "Press Enter to continue (or ${BL}navigation${NC}): " input
        # #     #         handle_navigation_input "$input"
        # #     #         nav=$?
        # #     #         if [[ $nav -eq $NAV_QUIT ]]; then
        # #     #             return 0
        # #     #         elif [[ $nav -eq $NAV_BACK ]]; then
        # #     #             break 2  # Exit this while loop, back to main selection method menu
        # #     #         else
        # #     #             continue 2  # Continue showing current states
        # #     #         fi
        # #     #     done
        # #     #     ;;
        # #     *)
        # #         handle_navigation_input "$choice"
        # #         nav=$?
        # #         if [[ $nav -eq $NAV_QUIT ]]; then
        # #             return 0
        # #         elif [[ $nav -eq $NAV_BACK ]]; then
        # #             return 0
        # #         fi
        # #         echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
        # #         sleep 1
        # #         continue
        # #         ;;
        # # esac
        # done
    # done
    # done    

    # Restore Terminal window size after exiting menu
    set_terminal_height_to_512p
}

#====16==== mac_sharing
# Real-Time File System Monitoring
# function mac_sharing () {
#     return_to_menu=true
#     trap 'echo; echo "Returning to main menu...from func 1"; return_to_menu=true; return' SIGINT
#     echo
# }

#====15==== 🍏 Create macOS Installer
function create_macos_installer (){
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 15"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}==============================${NC}"
        echo "${BO}15) 🍏 Create macOS Installer${NC}"
        echo "${GR}==============================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        echo "Choose an option"
        echo "1) ${GR}Download macOS Installer${NC}"
        echo "2) ${GR}Create Bootable Installer${NC}"
        echo
        read -rp "➡️  ${GR}Choose option [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " choice

        handle_navigation_input "$choice"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break
        fi

        case $choice in
            1)
                while true; do
                    clear
                    echo "${GR}==============================${NC}"
                    echo "${BO}1) Download macOS Installer${NC}"
                    echo "${GR}==============================${NC}"
                    echo "↩️  Create macOS Installer"
                    show_navigation_prompt

                    echo "${CY}Listing available full installers...${NC}"
                    echo

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    softwareupdate --list-full-installers 2>/dev/null | sed 's/^/   /'

                    while true; do
                        echo
                        
                        read -rp "➡️  ${GR}Enter version (e.g., 15.6.1) (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            break 2
                        fi

                        eval "set -- $input"

                        if [[ $# -lt 1 ]]; then
                            echo "❌ ${RE}No version provided.${NC}"
                            echo "   Please try again."
                            sleep 1
                            continue
                        fi
                        
                        version="$1"

                        echo
                        # echo "${CY}Fetching full installer for version:${NC} ${BO}$version${NC}"

                        return_to_menu=false
                        interrupted=false
                        trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break 2' SIGINT

                        softwareupdate --fetch-full-installer --full-installer-version "$version"

                        if [[ $? -eq 0 ]]; then
                            while true; do
                                echo "✅ ${GR}Download requested. Checking /Applications for installer...${NC}"

                                found_installer=""

                                for p in /Applications/Install\ macOS*.app; do
                                    if [[ -d "$p" ]]; then 
                                        found_installer="$p"
                                    break
                                    fi
                                done

                                if [[ -n "$found_installer" ]]; then
                                    echo "${GR}Found:${NC} $found_installer"
                                else
                                    echo "${YE}Installer not immediately visible. It may finish shortly.${NC}"
                                    sleep 1
                                fi

                                echo
                                echo "🚪 Create a bootable installer? (Enter)"
                                echo "⬅️  Or browse more versions? (Back)"
                                echo
                                # show_navigation_prompt

                                return_to_menu=true
                                interrupted=false
                                trap 'echo; echo "returning from func 1"; return' SIGINT

                                read -rp "➡️  ${GR}Press Enter to return to macOS Installer Menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break 2
                                else [[ $nav -eq $NAV_CONT ]]
                                    break 3
                                fi
                            done
                        else
                            echo "❌ ${RE}Download failed. Verify version, network or free space available.${NC}"
                            sleep 1
                            continue
                        fi
                    done    
                done    
                ;;
            2)
                while true; do
                    clear
                    echo "${GR}============================${NC}"
                    echo "${BO}2) Create Bootable Installer${NC}"
                    echo "${GR}============================${NC}"
                    echo "↩️  Create macOS Installer"
                    show_navigation_prompt
                    echo "Step 1: Select an installer app (.app)"
                    echo

                    installers=()
                    idx=0

                    for p in /Applications/Install\ macOS*.app; do
                        if [[ -d "$p" ]]; then
                            installers[$idx]="$p"
                            idx=$((idx+1))
                        fi
                    done

                    selected_installer=""

                    if [[ ${#installers[@]} -gt 0 ]]; then
                        echo "${GR}Found installers${NC}:"
                        c=0

                        while [[ $c -lt ${#installers[@]} ]]; do
                            printf "  %s) %s\n" "$((c+1))" "${installers[$c]}"
                            c=$((c+1))
                        done
                        echo
                        echo "➡️  ${GR}Choose [1-${#installers[@]}] or drag-drop a .app${NC}:"
                        echo
                        read -rp "" choice_app

                        handle_navigation_input "$choice_app"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            break
                        fi
                        
                        if echo "$choice_app" | grep -E '^[0-9]+$' >/dev/null 2>&1; then
                            sel_index=$((choice_app-1))
                            if [[ $sel_index -ge 0 && $sel_index -lt ${#installers[@]} ]]; then
                                selected_installer="${installers[$sel_index]}"
                            fi
                        else
                            eval "set -- $choice_app"
                            
                            if [[ $# -ge 1 ]]; then 
                                selected_installer="$1"
                            fi
                        fi
                    else
                        echo "➡️  ${GR}Drag-drop an installer .app here${NC}:"
                        echo
                        read -rp "" dd_app

                        handle_navigation_input "$dd_app"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            break
                        fi
                        
                        eval "set -- $dd_app"
                        
                        if [[ $# -ge 1 ]]; then
                            selected_installer="$1"
                        fi
                    fi

                    if [[ -z "$selected_installer" || ! -d "$selected_installer" ]]; then
                        echo "❌ ${RE}No valid installer selected.${NC}"
                        echo "   Please try again."
                        sleep 1
                        continue
                    fi
                    
                    cim_path="$selected_installer/Contents/Resources/createinstallmedia"

                    if [[ ! -x "$cim_path" ]]; then
                        echo "❌ ${RE}createinstallmedia not found in installer.${NC}"
                        echo "   Please try again."
                        sleep 1
                        continue
                    fi

                    while true; do
                        clear
                        echo "${GR}=======================${NC}"
                        echo "${BO}📦 Select Target Volume${NC}"
                        echo "${GR}=======================${NC}"
                        echo "↩️  Create Bootable Installer"
                        show_navigation_prompt
                        echo "Mounted volumes:"
                        echo

                        for v in /Volumes/*; do
                            [ -d "$v" ] && printf "  - %s\n" "$v"
                        done
                        echo
                        echo "➡️  ${GR}Enter target volume path (e.g., /Volumes/MyUSB)${NC}:"
                        echo
                        read -rp "" tgt
                        
                        handle_navigation_input "$tgt"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            break
                        fi
                        
                        eval "set -- $tgt"
                        
                        if [[ $# -lt 1 ]]; then 
                            echo "❌ ${RE}No volume provided.${NC}"
                            echo "   Please try again."
                            sleep 1
                            continue
                        fi
                        
                        target_vol="$1"
                        
                        if [[ ! -d "$target_vol" ]]; then
                            echo "❌ ${RE}Target volume not found.${NC}"
                            echo "   Please try again."
                            sleep 1
                            continue
                        fi

                        while true; do
                            clear
                            echo "${GR}======================${NC}"
                            echo "${BO}🧼 Erase Target Volume${NC}"
                            echo "${GR}======================${NC}"
                            echo "↩️  Select Target Volume"
                            show_navigation_prompt

                            echo "${RE}This will ERASE the target volume.${NC} ${GR}Continue?${NC}"
                            echo
                            echo "${GR}Type YES to continue (or ${BL}navigation${NC} ${GR}choice)${NC}:"
                            read -rp "" confirm

                            handle_navigation_input "$confirm"
                            nav=$?
                            if [[ $nav -eq $NAV_QUIT ]]; then 
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then
                                break
                            fi

                            if [[ "$confirm" != "YES" ]]; then
                                echo "${YE}Cancelled.${NC}"
                                sleep 1
                                break
                            fi

                            return_to_menu=false
                            interrupted=false
                            trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                            sudo "$cim_path" --volume "$target_vol" --nointeraction

                            if [[ $? -eq 0 ]]; then
                                echo "✅ ${GR}Bootable installer created on${NC}"
                                echo "\"$target_vol\""
                            else
                                echo "❌ ${RE}createinstallmedia failed.${NC}"
                                echo "   Please try again."
                                sleep 1
                                continue
                            fi
                            while true; do
                                # echo "${GR}Done!${NC}"
                                # echo

                                return_to_menu=true
                                interrupted=false
                                trap 'echo; echo "returning from func 1"; return' SIGINT

                                read -rp "➡️  ${GR}Press Enter to return to macOS Installer Menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                
                                handle_navigation_input "$input"
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break
                                else [[ $nav -eq $NAV_CONT ]]
                                    break
                                fi
                            done    
                        done    
                    done
                done    
                # break 2
                ;;
            *)
                # handle_navigation_input "$choice"
                # nav=$?
                # if [[ $nav -eq $NAV_QUIT ]]; then
                #     return 0
                # elif [[ $nav -eq $NAV_BACK ]]; then
                #     break
                # fi
                echo "❌ ${RE}Invalid option. Please choose 1-3.${NC}"
                sleep 1
                continue
                ;;
        esac

    done

}

#====16==== 💾 Create Disk Image
function disk_image_utility () {
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 16"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=========================${NC}"
        echo "${BO}16) 💿 Disk Image Utility${NC}"
        echo "${GR}=========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        echo "${BO}Choose an option.${NC}"
        echo "1) ${GR}Create new disk image${NC}"
        echo "2) ${GR}Resize existing disk image${NC}"
        echo
        read -rp "➡️  ${GR}Choose option [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " disk_util_choice
        handle_navigation_input "$disk_util_choice"
        nav=$?
        if [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break
        fi
        # if chose Creation option
        if [[ "$disk_util_choice" == "1" ]]; then
            # Step 1: Enter creation mode (empty vs from existing)
            while true; do
                clear
                echo "${GR}=====================${NC}"
                echo "${BO}💿 Create Disk Images${NC}"
                echo "${GR}=====================${NC}"
                echo "↩️  Disk Image Utility"
                show_navigation_prompt
                echo "${BO}Choose an option.${NC}"
                echo "1) ${GR}Create empty disk image${NC}"
                echo "2) ${GR}Create disk image from existing files/folders${NC}"
                echo
                read -rp "➡️  ${GR}Choose option [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " disk_creation_choice
                handle_navigation_input "$disk_creation_choice"
                nav=$?
                if [[ $nav -eq $NAV_QUIT ]]; then
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then
                    continue 2
                fi
                # If from existing items, collect sources
                if [[ "$disk_creation_choice" == "2" ]]; then
                    sources_to_add=()                    
                    while true; do
                        clear
                        echo "${GR}===========================${NC}"
                        echo "${BO}Select Source Files/Folders${NC}"
                        echo "${GR}===========================${NC}"
                        echo "↩️  Create Disk Images"
                        show_navigation_prompt
                        echo "➡️  ${GR}Drag and drop one or more files/folders, then press Enter:${NC}"
                        echo
                        read -rp "" input
                        handle_navigation_input "$input"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            continue 2
                        fi

                        eval "set -- $input"

                        if [[ $# -eq 0 ]]; then
                            echo "❌ ${RE}No valid input provided.${NC}"
                            sleep 1
                            continue
                        fi

                        for item in "$@"; do
                            if [[ -e "$item" ]]; then
                                sources_to_add+=("$item")
                            else
                                echo "❌ ${RE}Skipping invalid path:${NC} $item"
                                sleep 1
                                continue
                            fi
                        done

                        if [[ ${#sources_to_add[@]} -gt 0 ]]; then
                            break
                        else
                            continue
                        fi
                    done
                # elif [[ "$disk_creation_choice" == "1" ]]; then # if create new
                #     continue 2
                fi    
                # Step 2: Name
                vol_name=""
                while true; do
                    clear
                    echo "${GR}===================${NC}"
                    echo "${BO}Set Disk Image Name${NC}"
                    echo "${GR}===================${NC}"
                    echo "↩️  Create Disk Images"
                    show_navigation_prompt
                    read -rp "➡️  ${GR}Enter a name for the disk image${NC}: " vol_name
                    handle_navigation_input "$vol_name"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break
                    fi

                    if [[ -n "$vol_name" ]]; then
                        # continue
                        echo
                        
                    else
                        echo "❌ ${RE}Name cannot be empty.${NC}"
                        sleep 1
                        continue
                    fi  
                    # Step 3: Size selection (sparse image)
                    disk_img_size=""
                    while true; do
                        clear
                        echo "${GR}======================${NC}"
                        echo "${BO}Choose Disk Image Size${NC}"
                        echo "${GR}======================${NC}"
                        echo "↩️  Set Disk Image Name"
                        show_navigation_prompt                        
                        echo "${YE}Note:${NC} A sparse disk image will not use this space until you fill it."
                        echo
                        echo "${BO}Choose an option${NC}"
                        echo "1) ${GR}1 GB${NC}"
                        echo "2) ${GR}5 GB${NC}"
                        echo "3) ${GR}25 GB${NC}"
                        echo "4) ${GR}Custom (GB)${NC}"
                        echo
                        read -rp "➡️  ${GR}Choose size [1-4] (or ${BL}navigation${NC} ${GR}choice)${NC}: " disk_img_size_choice
                        handle_navigation_input "$disk_img_size_choice"
                        nav=$?
                        if [[ $nav -eq $NAV_QUIT ]]; then
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then
                            break
                        fi

                        case "$disk_img_size_choice" in
                            1) disk_img_size="1g";;
                            2) disk_img_size="5g";;
                            3) disk_img_size="25g";;
                            4)
                                while true; do
                                    clear
                                    echo "${GR}======================${NC}"
                                    echo "${BO}Custom Disk Image Size${NC}"
                                    echo "${GR}======================${NC}"
                                    echo "↩️  Choose Disk Image Size"
                                    show_navigation_prompt
                                    read -rp "➡️  ${GR}Enter custom size in GB (e.g., 12)${NC}: " custom_size_in_gb
                                    handle_navigation_input "$custom_size_in_gb"
                                    nav=$?
                                    if [[ $nav -eq $NAV_QUIT ]]; then
                                        return 0
                                    elif [[ $nav -eq $NAV_BACK ]]; then
                                        break
                                    fi
                                    
                                    if echo "$custom_size_in_gb" | grep -E '^[0-9]+$' >/dev/null 2>&1; then
                                        if [[ "$custom_size_in_gb" -gt 0 ]]; then
                                            disk_img_size="${custom_size_in_gb}g"
                                            break
                                        else
                                            echo "❌ ${RE}Please enter a whole number in GB (e.g., 10).${NC}"
                                            sleep 1
                                            continue
                                        fi   
                                    else
                                        echo "❌ ${RE}Please enter a number in GB (e.g., 10).${NC}"
                                        sleep 1
                                        continue
                                    fi
                                done    
                                ;;
                            *)
                                echo "❌ ${RE}Invalid choice. Please select 1-4.${NC}"
                                sleep 1
                                continue
                                ;;
                        esac
                        while true; do
                            # Step 4: Optional password (AES-256)
                            use_password="no"
                            password_value=""
                            while true; do
                                clear
                                echo "${GR}=============================${NC}"
                                echo "${BO}Password Protection (AES-256)${NC}"
                                echo "${GR}=============================${NC}"
                                echo "↩️  Choose Disk Image Size"
                                show_navigation_prompt
                                read -rp "➡️  ${GR}Set a password? (y/N)${NC}: " pw_choice
                                handle_navigation_input "$pw_choice"
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break 2
                                fi

                                case "$pw_choice" in
                                    [Yy]|[Yy][Ee][Ss]) use_password="yes" ;;
                                    [Nn]|[Nn][Oo]) use_password="no" ;;
                                    *)
                                        echo "❌ ${RE}Please answer y/yes or n/no.${NC}"
                                        sleep 1
                                        continue
                                        ;;
                                esac

                                if [[ "$use_password" == "yes" ]]; then
                                    while true; do
                                        clear
                                        echo "${GR}=============================${NC}"
                                        echo "${BO}Password Protection (AES-256)${NC}"
                                        echo "${GR}=============================${NC}"
                                        echo "↩️  Choose Disk Image Size"
                                        show_navigation_prompt
                                        echo "${GR}Please choose password for the disk image.${NC}"
                                        # echo "${GR}You'll be asked to enter it twice.${NC}"
                                        # echo "${GR}It will also be hidden.${NC}"
                                        echo
                                        read -s -p "➡️  ${GR}Enter a password${NC}: " pw1
                                        handle_navigation_input "$pw1"
                                        nav=$?
                                        if [[ $nav -eq $NAV_QUIT ]]; then
                                            return 0
                                        elif [[ $nav -eq $NAV_BACK ]]; then
                                            break 2
                                        fi
                                        echo
                                        if [[ -z "$pw1" ]]; then
                                            echo "❌ ${RE}Password cannot be empty.${NC}"
                                            sleep 1
                                            continue
                                        fi    
                                        read -s -p "➡️  ${GR}Confirm password${NC}: " pw2
                                        handle_navigation_input "$pw2"
                                        nav=$?
                                        if [[ $nav -eq $NAV_QUIT ]]; then
                                            return 0
                                        elif [[ $nav -eq $NAV_BACK ]]; then
                                            break
                                        fi
                                        echo                 
                                        if [[ -z "$pw2" ]]; then
                                            echo "❌ ${RE}Password cannot be empty.${NC}"
                                            sleep 1
                                            continue
                                        fi      
                                        
                                        if [[ "$pw1" != "$pw2" ]]; then 
                                            echo "❌ ${RE}Passwords do not match. Try again.${NC}"
                                            sleep 1
                                            continue
                                        fi
                                        # fi
                                        # continue
                                        password_value="$pw1"
                                        break
                                    done
                                fi
                                # Step 5: Destination
                                dest_dir=""
                                while true; do
                                    clear
                                    echo "${GR}====================${NC}"
                                    echo "${BO}Choose Save Location${NC}"
                                    echo "${GR}====================${NC}"
                                    echo "↩️  Password Protection"
                                    show_navigation_prompt
                                    echo "${BO}Choose a location:${NC}"
                                    echo "1) ${GR}Save to Desktop${NC}"
                                    echo "2) ${GR}Choose a custom folder${NC}"
                                    echo
                                    read -rp "➡️  ${GR}Choose option [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " dest_choice
                                    handle_navigation_input "$dest_choice"
                                    nav=$?
                                    if [[ $nav -eq $NAV_QUIT ]]; then 
                                        return 0
                                    elif [[ $nav -eq $NAV_BACK ]]; then
                                        break
                                    fi

                                    if [[ "$dest_choice" == "1" ]]; then
                                        dest_dir="$HOME/Desktop" 
                                    elif [[ "$dest_choice" == "2" ]]; then
                                        custom_dest_dir=$(osascript -e 'try' \
                                                        -e 'set p to POSIX path of (choose folder with prompt "Choose destination folder for the disk image")' \
                                                        -e 'return p' \
                                                        -e 'on error' \
                                                        -e 'return ""' \
                                                        -e 'end try')
                                        if [[ -n "$custom_dest_dir" && -d "$custom_dest_dir" ]]; then
                                            dest_dir="${custom_dest_dir%/}"
                                        else
                                            echo "❌ ${RE}No folder chosen. Please try again.${NC}"
                                            sleep 1
                                            continue
                                        fi
                                    else
                                        echo "❌ ${RE}Invalid choice. Please select 1 or 2.${NC}"
                                        sleep 1
                                        continue
                                    fi
                                    # Disk Image Creation
                                    while true; do
                                        # Prepare path and create image via hdiutil
                                        disk_img_path="$dest_dir/$vol_name.sparseimage"
                                        # clear
                                        # echo "${GR}======================${NC}"
                                        # echo "${BO}Creating Disk Image...${NC}"
                                        # echo "${GR}======================${NC}"
                                        # echo "↩️  Disk Image Utility"
                                        # show_navigation_prompt
                                        # echo "📄 Name:        $vol_name"
                                        # echo "📦 Size:        $disk_img_size"
                                        # echo "🗂️  Location:    $dest_dir"
                                        # echo "🔒 Encrypted:   $( [[ "$use_password" == "yes" ]] && echo "Yes (AES-256)" || echo "No" )"
                                        # echo "📁 From Files:  $( [[ "$disk_creation_choice" == "2" ]] && echo "Yes" || echo "No" )"
                                        # echo

                                        create_ok=0
                                        if [[ "$use_password" == "yes" ]]; then
                                            printf "%s" "$password_value" | hdiutil create -type SPARSE -fs APFS -volname "$vol_name" -size "$disk_img_size" -encryption AES-256 -stdinpass "$disk_img_path" >/dev/null 2>&1
                                        else
                                            hdiutil create -type SPARSE -fs APFS -volname "$vol_name" -size "$disk_img_size" "$disk_img_path" >/dev/null 2>&1
                                        fi

                                        if [[ $? -eq 0 ]]; then 
                                            create_ok=1
                                        fi

                                        if [[ $create_ok -ne 1 ]]; then
                                            echo "❌ ${RE}Failed to create disk image.${NC}"
                                            echo "Please check that the name doesn't already exist"
                                            # echo
                                            show_navigation_prompt
                                            read -rp "➡️  ${GR}Press Enter to try again (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                            handle_navigation_input "$input"
                                            nav=$?
                                            if [[ $nav -eq $NAV_QUIT ]]; then
                                                return 0
                                            elif [[ $nav -eq $NAV_BACK ]]; then
                                                break
                                            else
                                                continue
                                            fi
                                        fi

                                        # If from existing, attach, copy, detach
                                        if [[ "$disk_creation_choice" == "2" && ${#sources_to_add[@]} -gt 0 ]]; then
                                            # echo "🔄 ${GR}Populating image with selected items...${NC}"      
                                            mount_point="/Volumes/$vol_name"
                                            
                                            if [[ "$use_password" == "yes" ]]; then
                                                printf "%s" "$password_value" | hdiutil attach -stdinpass -nobrowse -mountpoint "$mount_point" "$disk_img_path" >/dev/null 2>&1
                                            else
                                                hdiutil attach -nobrowse -mountpoint "$mount_point" "$disk_img_path" >/dev/null 2>&1
                                            fi
                                            
                                            if [[ $? -ne 0 ]]; then
                                                echo "❌ ${RE}Failed to attach disk image for copying.${NC}"
                                            else
                                                for src in "${sources_to_add[@]}"; do 
                                                    cp -R "$src" "$mount_point/" 2>/dev/null
                                                done
                                                sync
                                                hdiutil detach "$mount_point" >/dev/null 2>&1
                                            fi
                                        fi

                                        # Summary
                                        echo
                                        echo "================================================================================"
                                        echo "${BO}Results:${NC}"
                                        if [[ -f "$disk_img_path" ]]; then
                                            echo "✅ ${GR}Disk image created successfully!${NC}"
                                            echo "📄 Name:        $vol_name"
                                            echo "📦 Size:        $disk_img_size (sparseimage)"
                                            echo "🔒 Encrypted:   $( [[ "$use_password" == "yes" ]] && echo "Yes (AES-256)" || echo "No" )"
                                            echo "🗂️  Location:    $dest_dir"
                                            echo "📁 From Files:  $( [[ "$disk_creation_choice" == "2" ]] && echo "Yes" || echo "No" )"
                                            if [[ "$disk_creation_choice" == "2" ]]; then 
                                                echo "📁 Seeded:      ${#sources_to_add[@]} item(s)"
                                            fi
                                        else
                                            echo "❌ ${RE}Disk image not found at destination.${NC}"
                                        fi
                                        echo "================================================================================"
                                        echo
                                        # show_navigation_prompt
                                        read -rp "➡️  ${GR}Create another image? Press Enter (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                        handle_navigation_input "$input"
                                        nav=$?
                                        if [[ $nav -eq $NAV_QUIT ]]; then 
                                            return 0
                                        elif [[ $nav -eq $NAV_BACK ]]; then
                                            break
                                        else
                                            break 6
                                        fi
                                    done
                                done 
                            done 
                        done    
                    done                     
                done
            done
        # if chose Resizing option
        elif [[ "$disk_util_choice" == "2" ]]; then
            while true; do
                clear
                echo "${GR}====================${NC}"
                echo "${BO}Choose Disk Image...${NC}"
                echo "${GR}====================${NC}"
                echo "↩️  Disk Image Utility"
                show_navigation_prompt
                echo "➡️  ${GR}Drag and drop a .sparseimage (or .sparsebundle) here, then press Enter:${NC}"
                echo
                while true; do
                    read -rp "" disk_img_input
                    handle_navigation_input "$disk_img_input"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        continue 3
                    fi

                    eval "set -- $disk_img_input"
                    
                    if [[ $# -lt 1 ]]; then
                        echo "❌ ${RE}No path provided.${NC}"
                        sleep 1
                        continue 2
                    fi

                    while true; do
                        selected_disk_img_for_resize="$1"
                        if [[ ! -e "$selected_disk_img_for_resize" ]]; then
                            echo "❌ ${RE}Path not found.${NC}"
                            sleep 1
                            continue 3
                        fi

                        # Choose Resize Option
                        while true; do
                            clear
                            echo "${GR}================================================================================${NC}"
                            echo "${BO}Resize: $(basename "$selected_disk_img_for_resize")${NC}"
                            echo "${GR}================================================================================${NC}"
                            echo "↩️  Choose Disk Image..."
                            show_navigation_prompt
                            echo "1) ${GR}Grow maximum size${NC}"
                            echo "2) ${GR}Compact free space${NC}"
                            echo
                            read -rp "➡️  ${GR}Choose option [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " disk_resize_choice
                            handle_navigation_input "$disk_resize_choice"
                            nav=$?
                            if [[ $nav -eq $NAV_QUIT ]]; then
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then
                                break 3
                            fi
                            
                            # If Grow Image
                            if [[ "$disk_resize_choice" == "1" ]]; then
                                # Grow Image
                                while true; do
                                    clear
                                    echo "${GR}================================================================================${NC}"
                                    echo "${BO}Grow: $(basename "$selected_disk_img_for_resize")${NC}"
                                    echo "${GR}================================================================================${NC}"
                                    echo "↩️  Resize $(basename "$selected_disk_img_for_resize")"
                                    show_navigation_prompt
                                    handle_navigation_input
                                    nav=$?
                                    if [[ $nav -eq $NAV_QUIT ]]; then
                                        return 0
                                    elif [[ $nav -eq $NAV_BACK ]]; then
                                        break
                                    fi

                                    # Get size in bytes, then convert
                                    get_current_file_size() {
                                        # local file="$selected_disk_img_for_resize"
                                        local bytes=$(stat -f%z "$selected_disk_img_for_resize")
                                        if [ "$bytes" -ge 1000000000 ]; then
                                            awk "BEGIN {printf \"%.2f GB (%.2f GiB)\", $bytes/1000000000, $bytes/1073741824}"
                                        else
                                            awk "BEGIN {printf \"%.2f MB (%.2f MiB)\", $bytes/1000000, $bytes/1048576}"
                                        fi
                                    }
                                    
                                    size_before=$(get_current_file_size "$selected_disk_img_for_resize")
                                    
                                    # echo "Getting current encryption status..."
                                    # echo
                                    # Getting encryption status...${NC}"       
                                    get_image_info() {
                                        # local file="$selected_disk_img_for_resize"
                                        local info_output=$(hdiutil imageinfo "$selected_disk_img_for_resize" 2>/dev/null | grep "Encryption") # | head -20)
                                        
                                        # Check encryption from the header info
                                        if echo "$info_output" | grep -qi "AES-256"; then
                                            echo "Yes (AES-256)"
                                        else
                                            echo "None"
                                        fi
                                    }

                                    echo "${GR}Getting current image size...${NC}"       

                                    encryption_status=$(get_image_info "$selected_disk_img_for_resize")
                                    # size_before=$(stat -f%z "$selected_disk_img_for_resize")

                                    # size_after=$(stat -f%z "$selected_disk_img_for_resize")
                                    
                                    echo "📦 Old Size:    $size_before (sparseimage)"
                                    # echo
                                    read -rp "➡️  ${GR}Enter new maximum size (e.g., 10g)${NC}: " new_size
                                    
                                    handle_navigation_input "$new_size"
                                    nav=$?
                                    if [[ $nav -eq $NAV_QUIT ]]; then
                                        return 0
                                    elif [[ $nav -eq $NAV_BACK ]]; then
                                        continue 2
                                    fi

                                    if echo "$new_size" | grep -E '^[0-9]+[gGmMkKtT]$' >/dev/null 2>&1; then
                                        # echo
                                        echo "${GR}Growing...${NC}"
                                        hdiutil resize -size "$new_size" "$selected_disk_img_for_resize" >/dev/null 2>&1
                                        
                                        if [[ $? -eq 0 ]]; then
                                            echo "✅ ${GR}Grew successfully${NC}"
                                            sleep 1
                                            break
                                        else
                                            echo "❌ ${RE}Grow failed${NC}"
                                            sleep 1
                                            echo "${GR}Please try again - or try re-uploading.${NC}"
                                            sleep 2
                                            continue
                                        fi
                                    else
                                        echo "❌ ${RE}Use units like 10g, 500m, etc.${NC}"
                                        sleep 1
                                        continue
                                    fi
                                done
                            # If Compact Image
                            elif [[ "$disk_resize_choice" == "2" ]]; then
                                # Compact Image  
                                clear
                                echo "${GR}================================================================================${NC}"
                                echo "${BO}Compact: $(basename "$selected_disk_img_for_resize")${NC}"
                                echo "${GR}================================================================================${NC}"
                                echo "↩️  Resize $(basename "$selected_disk_img_for_resize")"
                                show_navigation_prompt
                                handle_navigation_input
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break 2
                                fi
                                
                                # Get size in bytes, then convert
                                # comp_old_size=$(hdiutil imageinfo "$disk_img_input" | grep "Total Bytes:" | awk '{if ($3 >= 1000000000) printf "%.2f GB (%.2f GiB)", $3/1000000000, $3/1073741824; else printf "%.2f MB (%.2f MiB)", $3/1000000, $3/1048576}')                            
                                get_current_file_size() {
                                    # local file="$selected_disk_img_for_resize"
                                    local bytes=$(stat -f%z "$selected_disk_img_for_resize")
                                    if [ "$bytes" -ge 1000000000 ]; then
                                        awk "BEGIN {printf \"%.2f GB (%.2f GiB)\", $bytes/1000000000, $bytes/1073741824}"
                                    else
                                        awk "BEGIN {printf \"%.2f MB (%.2f MiB)\", $bytes/1000000, $bytes/1048576}"
                                    fi
                                }

                                size_before=$(get_current_file_size "$selected_disk_img_for_resize")
                                
                                # echo "Getting current encryption status..."
                                # echo
                                
                                get_image_info() {
                                    # local file="$selected_disk_img_for_resize"
                                    local info_output=$(hdiutil imageinfo "$selected_disk_img_for_resize" 2>/dev/null | grep "Encryption") # | head -20)
                                    
                                    # Check encryption from the header info
                                    if echo "$info_output" | grep -qi "AES-256"; then
                                        echo "Yes (AES-256)"
                                    else
                                        echo "None"
                                    fi
                                }

                                echo "${GR}Getting current image size...${NC}"
                                
                                encryption_status=$(get_image_info "$selected_disk_img_for_resize")
                                # size_before=$(stat -f%z "$selected_disk_img_for_resize")

                                # size_after=$(stat -f%z "$selected_disk_img_for_resize")

                                echo "${GR}Compacting...${NC}"

                                hdiutil compact "$selected_disk_img_for_resize" >/dev/null 2>&1
                                if [[ $? -eq 0 ]]; then 
                                    echo "✅ ${GR}Compacted successfully${NC}"
                                    sleep 1
                                else
                                    echo "❌ ${RE}Compact failed.${NC}" 
                                    sleep 1
                                    echo "${GR}Please try again - or try re-uploading.${NC}"
                                    sleep 2
                                    continue
                                fi
                            else
                                echo "❌ ${RE}Invalid choice.${NC}"
                                sleep 1
                                continue
                            fi

                            # not using - requires password for each command
                            # is_comp_encrypted=($(hdiutil imageinfo $disk_img_input | grep "Encrypted" >/dev/null 2>&1))
                            # comp_new_size=$(hdiutil imageinfo "$selected_disk_img_for_resize" | grep "Total Bytes:" | awk '{if ($3 >= 1000000000) printf "%.2f GB (%.2f GiB)", $3/1000000000, $3/1073741824; else printf "%.2f MB (%.2f MiB)", $3/1000000, $3/1048576}')

                            size_after=$(get_current_file_size "$selected_disk_img_for_resize")

                            # Show Resize Summary
                            while true; do
                                echo
                                echo "================================================================================"
                                echo "${BO}Results:${NC}"
                                # echo "✅ ${GR}Resized to $new_size successfully${NC}"
                                # if [[ -f "$selected_disk_img_for_resize" ]]; then
                                # echo "✅ ${GR}Disk resized successfully!${NC}"
                                # echo "📄 Name:        $selected_disk_img_for_resize"
                                # if [[ -e "$comp_new_size" ]]; then
                                echo "📄 Name:        $(basename "$selected_disk_img_for_resize")"
                                echo "📦 Old Size:    $size_before (sparseimage)"
                                echo "📦 New Size:    $size_after (sparseimage)"
                                # fi
                                # if [[ $is_comp_Encrypted == true ]]; then
                                #     echo "Encrypted"
                                # else
                                #     echo "None"
                                # fi

                                # hdiutil -imageinfo $disk_img_input | grep "Name"
                                # if [[ $is_comp_Encrypted == true ]]; then
                                #     echo "🔒 Encrypted:   Yes (AES-256)"
                                # else
                                #     echo "🔒 Encrypted:   No"
                                # fi
                                echo "🔒 Encryption:  $( [[ "$$encryption_status" == "Yes (AES-256)" ]] && echo "Yes (AES-256)" || echo "None" )"
                                echo "🗂️  Location:    $disk_img_input"
                                echo "================================================================================"
                                # show_navigation_prompt
                                echo
                                read -rp "➡️  ${GR}Resize another image? Press Enter (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break 2
                                else [[ $nav -eq $NAV_CONT ]]
                                    break 2
                                fi
                            done
                        done
                    done
                done    
            done
        else
            echo "❌ ${RE}Invalid choice. Please select 1 or 2.${NC}"
            sleep 1
            continue
        fi
    done    
}

#====17==== ⚙️ Diff Tracker
function macos_diff_tracker() {
    # Configuration
    BACKUP_DIR="$HOME/preference_tracking"
    TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
    CURRENT_SESSION="$BACKUP_DIR/current_session"
    DISCOVERED_DOMAINS_FILE="$CURRENT_SESSION/discovered_domains.txt"

    # Common domains that should always be tracked
    PRIORITY_DOMAINS=(
        "NSGlobalDomain"
        "com.apple.WindowManager"
        "com.apple.Passwords" 
        "com.apple.CloudSubscriptionFeatures.optIn"
        "com.apple.dock"
        "com.apple.finder"
        "com.apple.screencapture"
        "com.apple.QuickTimePlayerX"
        "com.apple.ImageCapture"
        "com.apple.AppleMultitouchTrackpad"
        "com.apple.driver.AppleBluetoothMultitouch.trackpad"
        "com.apple.driver.AppleBluetoothMultitouch.mouse"
        "com.apple.DiskUtility"
        "com.apple.TimeMachine" 
        "com.apple.NetworkBrowser"
        "com.apple.TextEdit"
        "com.apple.menuextra.clock"
        "com.apple.universalcontrol"
        "com.apple.dashboard"
        # "/Library/Preferences/com.apple.RemoteManagement"
    )

    # Host-specific domains that require -currentHost flag
    HOST_SPECIFIC_DOMAINS=(
        "NSGlobalDomain"
        "com.apple.controlcenter"
        "com.apple.systemuiserver"
        "com.apple.dock"
        "com.apple.screensaver"
        "com.apple.ImageCapture"
        "com.apple.universalcontrol"
    )

    # Domains to exclude from tracking (reduce clutter)
    EXCLUDED_DOMAINS=(
        # Add domains you want to ignore here, for example:
        "ContextStoreAgent"
        # "~/Library/Preferences/ContextStoreAgent.plist"
        "com.apple.DuetExpertCenter.AppPredictionExpert"
        # "~/Library/Preferences/com.apple.DuetExpertCenter.AppPredictionExpert.plist"
        "com.apple.spaces"
        # "~/Library/Preferences/com.apple.spaces.plist"
        "com.apple.studentd"
        "com.apple.xpc.activity2"
        "com.apple.ncprefs"
        "com.apple.homeenergyd"
        "com.apple.appstored"
        "com.apple.icloud.searchpartyuseragent"
        "com.apple.Accessibility.Assets"
        "com.apple.SpeakSelection"
        "com.apple.protectedcloudstorage.protectedcloudkeysyncing"
        "com.apple.tipsd"
        "com.apple.CloudSubscriptionFeatures.diagnostic"
        "com.apple.networkserviceproxy"
        "com.apple.cloudphotod"
        "com.apple.spotlightknowledge"
        "com.apple.voicebankingd"
        "com.apple.routined"
        "com.apple.homed"
        "com.apple.financed"
        "com.apple.animoji"
        "com.apple.StatusKitAgent"
        "com.apple.Maps.mapssyncd"
        "MobileMeAccounts"
        "diagnostics_agent"
        "familycircled"
        "fudHelperAgent"
        "systemgroup.com.apple.icloud.searchpartyd.sharedsettings"

        # audio app prefs
        "Colossus"
        "EWQLSO Gold Ed"
        "STORMDRUM"
        "UADPluginMate"
        "com.Antares.*"
        "com.Output."
        "com.RPCX.*"
        "com.WavesAudio.*"
        "com.ableton.*"
        "com.avid.*"
        "com.celemony.*"
        "com.dmgaudio.*"
        "com.elgato.*"
        "com.fabfilter.*"
        "com.goodhertz*"
        "com.hitnmix.*"
        "com.hofa.*"
        "com.izotope*"
        "com.linplug.*"
        "com.mhlabs.*"
        "com.mixedinkey.*"
        "com.native-instruments.*"
        "com.Output.*"
        "com.paceap.*"
        "com.plugin-alliance*"
        "com.pluginalliance*"
        "com.rogueamoeba.*"
        "com.slatedigital.*"
        "com.solidstatelogic*"
        "com.sonible.*"
        "com.soundtoys*"
        "com.sugar-bytes.*"
        "com.synchroarts.*"
        "com.toontrack.*"
        "com.uaudio.*"
        "com.wibu.*"
        "com.yme.*"
        "de.cableguys.*"
        "de.waldorfmusic.*"
        "jp.aom*"
        "jp.co.korg.*"
        "jp.co.roland.*"
        "net.spectrasonics.*"
        "net.uvi.*"    
        "org.softube.*"
        "raduvarga.*"
        "com.josephlyncheski.*"
        "com.bluecataudio.*"
        "com.APUSoftware.*"
        "com.airmusictech.*"

        # cybersecurity app prefs
        "com.mothersruin.*"
        "*.com.macpaw.*"
        "com.macpaw.*"
        "at.obdev.*"
        "ch.protonvpn.mac"
        "com.etresoft.*"
        "com.objective-see.*"
        "com.samuellaska.*"

        # confrencing
        "ZoomChat"
        "net.whatsapp.*"
        "us.zoom.*"

        # Other
        "com.aone.*"
        "com.bitTorrent*"
        "com.cherpake.*"
        "com.cleverfiles.*"
        "com.crystalidea.*"
        "com.microsoft.*"
        "com.ohanaware.*"
        "com.parallels.*"
        "com.primatelabs.*"
        "com.stairways.*"
        "com.surteesstudios.*"
        "com.titanium.*"
        "net.mediaarea.*"
        "org.tempel.*"
        "com.sononym.*"
        "com.Sonosaurus.*"
        "com.spotify.*"
        "fr.whitebox.*"
        "com.utmapp.*"
        "com.cazoobi.*"
        "com.blackmagic-design.*"
        "Blackmagic*"
        "com.araeliumgroup.*"
        "com.nektony.*"
        "com.electron.*"
        "com.DigiDNA.*"
    )

    # Helper Functions
    discover_all_domains() {
        local temp_file
        temp_file=$(mktemp)
        
        # Get domains from defaults command
        if defaults domains >/dev/null 2>&1; then
            defaults domains | tr ',' '\n' | sed 's/^[ 	]*//' | sed 's/[ 	]*$//' | grep -v '^$' >> "$temp_file"
        fi
        
        # Check plist files in user preferences
        for plist in ~/Library/Preferences/*.plist; do
            if [ -f "$plist" ]; then
                basename=$(basename "$plist" .plist)
                echo "$basename" >> "$temp_file"
            fi
        done
        
        # Check ByHost preferences
        if [ -d ~/Library/Preferences/ByHost ]; then
            for plist in ~/Library/Preferences/ByHost/*.plist; do
                if [ -f "$plist" ]; then
                    basename=$(basename "$plist" .plist)
                    # Remove the hardware UUID suffix
                    clean_domain=$(echo "$basename" | sed 's/\.[A-F0-9-]*$//')
                    echo "$clean_domain" >> "$temp_file"
                fi
            done
        fi
        
        # Check system preferences
        if [ -d /Library/Preferences ]; then
            if ls /Library/Preferences/*.plist >/dev/null 2>&1; then
                for plist in /Library/Preferences/*.plist; do
                    if [ -f "$plist" ]; then
                        basename=$(basename "$plist" .plist)
                        echo "$basename" >> "$temp_file"
                    fi
                done
            fi
        fi
        
        # Sort and deduplicate, then output
        sort -u "$temp_file"
        rm "$temp_file"
    }

    is_domain_excluded() {
        local domain="$1"
        local i=0
        local array_length=${#EXCLUDED_DOMAINS[@]}
        
        while [ $i -lt $array_length ]; do
            local excluded="${EXCLUDED_DOMAINS[$i]}"
            
            # Support wildcard patterns
            case "$domain" in
                $excluded)
                    return 0  # Domain is excluded
                    ;;
            esac
            i=$((i + 1))
        done
        return 1  # Domain is not excluded
    }

    save_discovered_domains() {
        local output_file="$1"
        
        # Start with our priority domains
        local temp_combined
        temp_combined=$(mktemp)
        
        # Add priority domains first
        printf '%s\n' "${PRIORITY_DOMAINS[@]}" > "$temp_combined"
        
        # Add discovered domains
        local temp_discovered
        temp_discovered=$(mktemp)
        discover_all_domains > "$temp_discovered"
        
        # Filter out excluded domains
        while IFS= read -r domain; do
            if [ -n "$domain" ] && ! is_domain_excluded "$domain"; then
                echo "$domain" >> "$temp_combined"
            fi
        done < "$temp_discovered"
        
        rm "$temp_discovered"
        
        # Sort and deduplicate
        sort -u "$temp_combined" > "$output_file"
        
        local count
        count=$(wc -l < "$output_file")
        local excluded_count=${#EXCLUDED_DOMAINS[@]}
        echo "${GR}Saved $count domains to: $output_file${NC}"
        echo "${YE}Priority domains included: ${#PRIORITY_DOMAINS[@]}${NC}"
        if [ $excluded_count -gt 0 ]; then
            echo "${RE}Excluded domain patterns: $excluded_count${NC}"
        fi
        
        rm "$temp_combined"
    }

    capture_preferences() {
        local phase="$1"
        local output_dir="$CURRENT_SESSION/${phase}"
        
        echo "${BL}Capturing $phase preferences...${NC}"
        mkdir -p "$output_dir"
        
        local domains_file="$DISCOVERED_DOMAINS_FILE"
        
        if [ "$phase" = "before" ]; then
            echo "${CY}Auto-discovering preference domains...${NC}"
            save_discovered_domains "$domains_file"
        elif [ ! -f "$domains_file" ]; then
            echo "${RE}Error: No discovered domains file found. Run 'before' phase first.${NC}"
            return 1
        fi
        
        local captured_count=0
        local skipped_count=0
        
        # Capture regular domains
        echo
        echo "${BL}Capturing regular preference domains...${NC}"
        while IFS= read -r domain; do
            if [ -n "$domain" ]; then
                local output_file="$output_dir/${domain}.plist"
                if defaults read "$domain" > "$output_file" 2>/dev/null; then
                    captured_count=$((captured_count + 1))
                    echo "  ✓ $domain"
                else
                    skipped_count=$((skipped_count + 1))
                    rm -f "$output_file"
                fi
            fi
        done < "$domains_file"
        
        # Capture host-specific domains
        echo
        echo "${BL}Capturing host-specific preference domains...${NC}"
        local host_output_dir="$output_dir/host_specific"
        mkdir -p "$host_output_dir"
        
        local i=0
        local array_length=${#HOST_SPECIFIC_DOMAINS[@]}
        while [ $i -lt $array_length ]; do
            local domain="${HOST_SPECIFIC_DOMAINS[$i]}"
            local output_file="$host_output_dir/${domain}.plist"
            if defaults -currentHost read "$domain" > "$output_file" 2>/dev/null; then
                captured_count=$((captured_count + 1))
                echo "  ✓ $domain (host-specific)"
            else
                skipped_count=$((skipped_count + 1))
                rm -f "$output_file"
            fi
            i=$((i + 1))
        done
        
        # Capture complete defaults dump
        echo "${BL}Capturing complete defaults dump...${NC}"
        defaults read > "$output_dir/all_defaults.plist" 2>/dev/null || true
        defaults -currentHost read > "$output_dir/all_defaults_host.plist" 2>/dev/null || true
        
        # Capture system information
        local total_domains
        total_domains=$(wc -l < "$domains_file")
        local array_length=${#HOST_SPECIFIC_DOMAINS[@]}

        {
            printf "=== System Information ===\n"
            printf "Timestamp:.....%s\n" "$(date)"
            printf "macOS Version: %s\n" "$(sw_vers -productVersion)"
            printf "Build:.........%s\n" "$(sw_vers -buildVersion)"
            printf "User:..........%s\n" "$(whoami)"
            printf "Hostname:......%s\n" "$(hostname)"
            printf "\n"
            printf "=== Tracking Statistics ===\n"
            printf "Total domains discovered:......%s\n" "$total_domains"
            printf "Domains captured:..............%s\n" "$captured_count"
            printf "Domains skipped (empty):.......%s\n" "$skipped_count"
            printf "Host-specific domains tracked: %s\n" "$array_length"
        } > "$output_dir/session_info.txt"



        echo
        echo "${GR}$phase preferences captured:${NC}"
        echo "  • Regular domains:.......$captured_count captured, $skipped_count skipped"
        echo "  • Host-specific domains: $array_length tracked"
        echo "  • Output directory:......$output_dir"
    }

    compare_domain_files() {
        local domain_name="$1"
        local before_file="$2"
        local after_file="$3"
        local summary_file="$4"
        local detailed_dir="$5"
        
        local safe_domain_name
        safe_domain_name=$(echo "$domain_name" | tr '/' '_' | tr ' ' '_')
        local detail_file="$detailed_dir/${safe_domain_name}_changes.txt"
        
        if [ -f "$before_file" ] && [ -f "$after_file" ]; then
            if ! diff -q "$before_file" "$after_file" >/dev/null 2>&1; then
                echo "${YE}📝 Changes detected in $domain_name${NC}"
                echo "🔸 $domain_name: MODIFIED" >> "$summary_file"

                {
                    printf "=== CHANGES IN $domain_name ===\n"
                    printf "Generated: %s\n" "$(date)"
                    printf "\n"
                } > "$detail_file"

                diff -u "$before_file" "$after_file" >> "$detail_file" 2>/dev/null || true
                
                echo "   Preview:"
                diff -u "$before_file" "$after_file" 2>/dev/null | head -100 | sed 's/^/   /' || true
                echo "   (Full diff saved to: $detail_file)"
                echo ""
                return 0
            fi
        elif [ -f "$before_file" ] && [ ! -f "$after_file" ]; then
            echo "${RE}🗑️  Domain $domain_name was removed${NC}"
            echo "🔸 $domain_name: REMOVED" >> "$summary_file"
            return 0
        elif [ ! -f "$before_file" ] && [ -f "$after_file" ]; then
            echo "${GR}➕ Domain $domain_name was added${NC}"
            echo "🔸 $domain_name: ADDED" >> "$summary_file"
            return 0
        fi
        return 1
    }

    pref_compare_preferences() {
        local before_dir="$CURRENT_SESSION/before"
        local after_dir="$CURRENT_SESSION/after"
        
        if [ ! -d "$before_dir" ]; then
            echo "${RE}Error: No 'before' snapshot found. Run 'before' first.${NC}"
            return 1
        fi
        
        if [ ! -d "$after_dir" ]; then
            echo "${RE}Error: No 'after' snapshot found. Run 'after' first.${NC}"
            return 1
        fi
        
        echo "${BL}Comparing preferences...${NC}"
        echo "=========================="
        
        local changes_found=0
        local summary_file="$CURRENT_SESSION/changes_summary.txt"
        local detailed_changes="$CURRENT_SESSION/detailed_changes/"
        mkdir -p "$detailed_changes"

        {
            printf "=== macOS Preferences Changes Summary ===\n"
            printf "Generated: %s\n" "$(date)"
            printf "Before:....%s\n" "$(grep "Timestamp:" "$before_dir/session_info.txt" | cut -d' ' -f2-)"
            printf "After:.....%s\n" "$(grep "Timestamp:" "$after_dir/session_info.txt" | cut -d' ' -f2-)"
            printf "\n"
        } > "$summary_file"
        
        if [ ! -f "$DISCOVERED_DOMAINS_FILE" ]; then
            echo "${RE}Error: Cannot find discovered domains file${NC}"
            return 1
        fi
        
        local domain_count
        domain_count=$(wc -l < "$DISCOVERED_DOMAINS_FILE")
        echo "${CY}Comparing $domain_count regular domains...${NC}"
        
        # Compare regular domains
        while IFS= read -r domain; do
            if [ -n "$domain" ] && ! is_domain_excluded "$domain"; then
                local before_file="$before_dir/${domain}.plist"
                local after_file="$after_dir/${domain}.plist"
                if compare_domain_files "$domain" "$before_file" "$after_file" "$summary_file" "$detailed_changes"; then
                    changes_found=1
                fi
            fi
        done < "$DISCOVERED_DOMAINS_FILE"
        
        echo "${CY}Comparing host-specific domains...${NC}"
        
        # Compare host-specific domains
        local i=0
        local array_length=${#HOST_SPECIFIC_DOMAINS[@]}
        while [ $i -lt $array_length ]; do
            local domain="${HOST_SPECIFIC_DOMAINS[$i]}"
            local before_file="$before_dir/host_specific/${domain}.plist"
            local after_file="$after_dir/host_specific/${domain}.plist"
            
            if [ -f "$before_file" ] || [ -f "$after_file" ]; then
                if compare_domain_files "$domain (host-specific)" "$before_file" "$after_file" "$summary_file" "$detailed_changes"; then
                    changes_found=1
                fi
            fi
            i=$((i + 1))
        done
        
        echo
        echo "" >> "$summary_file"
        echo "=== END OF SUMMARY ===" >> "$summary_file"
        echo
        
        if [ $changes_found -eq 1 ]; then
            echo "${GR}Analysis complete! Files created:${NC}"
            echo "  📄 Summary:..........$summary_file"
            echo "  📁 Detailed changes: $detailed_changes"
        else
            echo "${GR}No changes detected in any tracked domains.${NC}"
        fi
    }

    pref_show_discovery() {
        echo "${CY}=== macOS Preference Domain Discovery ===${NC}"
        echo
        
        local temp_domains
        temp_domains=$(mktemp)
        discover_all_domains > "$temp_domains"
        
        local total_count
        total_count=$(wc -l < "$temp_domains")
        echo "${GR}Found $total_count preference domains:${NC}"
        echo ""
        
        local apple_temp
        local third_party_temp
        apple_temp=$(mktemp)
        third_party_temp=$(mktemp)
        
        while IFS= read -r domain; do
            case "$domain" in
                com.apple.*|NSGlobalDomain)
                    echo "$domain" >> "$apple_temp"
                    ;;
                *)
                    echo "$domain" >> "$third_party_temp"
                    ;;
            esac
        done < "$temp_domains"
        
        local apple_count
        local third_party_count
        apple_count=$(wc -l < "$apple_temp" 2>/dev/null || echo "0")
        third_party_count=$(wc -l < "$third_party_temp" 2>/dev/null || echo "0")
        
        if [ "$apple_count" -gt 0 ]; then
            echo "${BL}Apple/System Domains ($apple_count):${NC}"
            sort "$apple_temp" | sed 's/^/  • /'
            echo ""
        fi
        
        if [ "$third_party_count" -gt 0 ]; then
            echo "${BL}Third-party/Other Domains ($third_party_count):${NC}"
            sort "$third_party_temp" | sed 's/^/  • /'
            echo ""
        fi
        
        echo "${YE}Host-specific domains that will be tracked separately:${NC}"
        local i=0
        local array_length=${#HOST_SPECIFIC_DOMAINS[@]}
        while [ $i -lt $array_length ]; do
            echo "  • ${HOST_SPECIFIC_DOMAINS[$i]} (host-specific)"
            i=$((i + 1))
        done
        
        rm "$temp_domains" "$apple_temp" "$third_party_temp"
    }

    # Main Diff Tracker menu
    while true; do
        # return_to_menu=true
        # trap 'echo; echo "Returning to main menu...from func 17"; return_to_menu=true; return' SIGINT
        # set_terminal_height_to_512p
        clear
        echo "${GR}=========================${NC}"
        echo "${BO}17) ⚙️  macOS Diff Tracker${NC}"
        echo "${GR}=========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        echo "${BO}Choose Diff Tracker option:${NC}"
        echo "1) File System Tracker"
        echo "2) Preference Tracker"
        echo
        read -rp "➡️  ${GR}Choose [1 - 2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " diff_path
        handle_navigation_input "$diff_path"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            return 0
        # else [[ $nav -eq $NAV_CONT ]] 
        #     break
        fi

        # Main fs_usage options menu loop
        if   [[ $diff_path == "1" ]]; then 
            while true; do
                set_terminal_height_to_1200p
                clear
                echo "${GR}======================${NC}"
                echo "${BO}1) File System Tracker${NC}"
                echo "${GR}======================${NC}"
                echo "↩️  macOS Diff Tracker"
                show_navigation_prompt
                
                # Check sudo access
                if ! sudo -n true 2>/dev/null; then
                    echo "${YE}Note: fs_usage requires administrator privileges.${NC}"
                    echo "${YE}You may be prompted for your password.${NC}"
                    echo
                fi
                
                # Show menu options
                echo "${BO}Select monitoring option:${NC}"
                echo "1) Monitor all file system activity"
                echo "2) Monitor specific process by name"
                echo "3) Monitor specific process by PID"
                echo "4) Monitor specific directory"
                echo "5) Monitor file operations only"
                echo "6) Monitor network operations only"
                echo "7) Custom fs_usage command"
                echo "8) View active processes (to help choose PID)"
                echo ""
                
                read -rp "➡️  ${GR}Select option (1-8) (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                echo
                handle_navigation_input "$input"
                nav=$?
                if [[ $nav -eq $NAV_QUIT ]]; then
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then
                    set_terminal_height_to_512p
                    break
                # else [[ $nav -eq $NAV_CONT ]]; then
                #     break
                fi

                case "$input" in
                    1)
                        # Monitor all file system activity
                        echo "${GR}Monitoring all file system activity...${NC}"
                        echo "${YE}Press Ctrl+C to stop${NC}"
                        sudo fs_usage -f filesys
                        ;;
                    2)

                        # Monitor specific process by name
                        read -rp "Enter process name (e.g., TextEdit, Safari): " process_name
                        if [[ -z "$process_name" ]]; then
                            echo "${RE}Process name cannot be empty${NC}"
                            sleep 1
                            continue
                        fi
                        echo "${GR}Monitoring file system activity for process: ${process_name}${NC}"
                        echo "${YE}Press Ctrl+C to stop${NC}"
                        echo

                        sudo fs_usage | grep "$process_name"

                        ;;
                    3)
                        # Monitor process by PID
                        read -rp "Enter Process ID (PID): " pid
                        if [[ ! "$pid" =~ ^[0-9]+$ ]]; then
                            echo "${RE}Invalid PID. Must be a number.${NC}"
                            sleep 1
                            continue
                        fi
                        
                        echo "${GR}Monitoring file system activity for PID: ${pid}${NC}"
                        echo "${YE}Press Ctrl+C to stop${NC}"
                        echo ""
                        sudo fs_usage -p "$pid"
                        ;;
                    4)
                        # Function to monitor specific directory                        
                        while true; do
                            clear
                            echo "${GR}=============================${NC}"
                            echo "${BO}4) Monitor specific directory${NC}"
                            echo "${GR}=============================${NC}"
                            echo "↩️  File System Tracker"
                            show_navigation_prompt
                            read -rp "Drag in a folder or enter a directory path to monitor: " dir_path

                            handle_navigation_input "$dir_path"
                            nav=$?
                            if [[ $nav -eq $NAV_QUIT ]]; then
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then
                                continue 2
                            # else [[ $nav -eq $NAV_CONT ]]; then
                            #     break
                            fi

                            eval dir_path="$dir_path"

                            if [[ ! -d "$dir_path" ]]; then
                                echo "${RE}Directory does not exist: $dir_path${NC}"
                                sleep 1
                                continue
                            fi
                            
                            while true; do
                                echo
                                echo "${GR}Monitoring file system activity in${NC}:"
                                echo "${dir_path}"
                                echo
                                echo "${YE}Press Ctrl+C to stop${NC}"
                                echo ""

                                sudo fs_usage -f filesys | grep "$dir_path"

                                if [[ $? -eq 0 ]]; then
                                    echo
                                else
                                    break 2
                                fi
                            done
                        done
                        ;;
                    5)
                        # Monitor file operations only
                        echo "${GR}Monitoring file operations only...${NC}"
                        echo "${YE}Press Ctrl+C to stop${NC}"
                        echo ""
                        sudo fs_usage -f filesys
                        ;;
                    6)
                        # Monitor network operations only
                        echo "${GR}Monitoring network operations only...${NC}"
                        echo "${YE}Press Ctrl+C to stop${NC}"
                        echo ""
                        sudo fs_usage -f network
                        ;;
                    7)
                        while true; do
                            clear
                            echo "${GR}==========================${NC}"
                            echo "${BO}7) Custom fs_usage Command${NC}"
                            echo "${GR}==========================${NC}"
                            echo "↩️  File System Tracker"
                            show_navigation_prompt
                            # Run custom fs_usage command
                            echo "${GR}Available fs_usage options:${NC}"
                            echo
                            echo "${CY}  -f filesys    ${NC}- File system operations only"
                            echo "${CY}  -f network    ${NC}- Network operations only"
                            echo "${CY}  -f diskio     ${NC}- Disk I/O operations only"
                            echo "${CY}  -p <pid>      ${NC}- Monitor specific process ID"
                            echo "${CY}  -w            ${NC}- Wide output format"
                            echo "${CY}  -t <seconds>  ${NC}- Sample for specified seconds"
                            echo ""
                            
                            read -rp "${GR}Enter custom fs_usage arguments (without 'sudo fs_usage')${NC}: " custom_args
                            
                            handle_navigation_input "$custom_args"
                            nav=$?
                            if [[ $nav -eq $NAV_QUIT ]]; then
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then
                                # set_terminal_height_to_512p
                                continue 2
                            # else [[ $nav -eq $NAV_CONT ]]
                            #     continue 2
                            fi

                            while true; do
                                clear
                                echo "${GR}=======================${NC}"
                                echo "${BO}⚙️  [Now in Custom Mode]${NC}"
                                echo "${GR}=======================${NC}"
                                echo "↩️  Custom fs_usage Command"
                                show_navigation_prompt
                                echo "${GR}Running: sudo fs_usage ${custom_args}${NC}"
                                echo "${YE}Press Ctrl+C to stop${NC}"
                                # ADD TRAP
                                echo ""
                                sudo fs_usage $custom_args
                                echo
                                echo "✅ Done"
                                echo
                                echo "🚪  Back to sub menu?:"
                                echo
                                read -rp "${GR}Press Enter to return to Custom fs_usage menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " after_custom_args
                                handle_navigation_input "$custom_args"
                                nav=$?
                                if [[ $nav -eq $NAV_QUIT ]]; then
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    # set_terminal_height_to_512p
                                    continue 2
                                else [[ $nav -eq $NAV_CONT ]]
                                    continue 2
                                fi
                            done
                        done
                        ;;
                    8)
                        # Show active processes
                        echo "${GR}Active processes (showing top 20 by CPU usage):${NC}"
                        echo ""
                        ps aux | head -21
                        echo ""
                        echo "${YE}Press Enter to continue...${NC}"
                        read -r
                        continue
                        ;;
                    *)
                        echo "${RE}Invalid option. Please try again.${NC}"
                        sleep 1
                        continue
                        ;;
                esac
            
                # handle_navigation_input "$input"
                # nav=$?
                # if [[ $nav -eq $NAV_QUIT ]]; then
                #     return 0
                # elif [[ $nav -eq "$NAV_BACK" ]]; then
                #     return 0
                # else
                # After monitoring stops, ask user what to do next
                if [[ "$input" =~ ^[1-7]$ ]]; then
                    # echo ""
                    # echo "${GR}======================${NC}"
                    # echo "${BO}⚙️  [Now in Custom Mode${NC}"
                    # echo "${GR}======================${NC}"
                    # echo "↩️  Custom fs_usage Command"
                    show_navigation_prompt
                    echo "${YE}Monitoring stopped.${NC}"
                    echo
                    echo "🚪  Back to sub menu?:"
                    echo
                    read -rp "${GR}Press Enter to return to File System Tracker sub menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " -r
                    handle_navigation_input
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        # set_terminal_height_to_512p
                        return 0
                    else [[ $nav -eq $NAV_CONT ]]
                        continue
                    fi
                fi
            done    

        # Main Preference Tracker loop
        elif [[ $diff_path == "2" ]]; then 
            while true; do
                # setup_function_trap
                set_terminal_height_to_1200p
                clear
                echo "${GR}=====================${NC}"
                echo "${BO}2) Preference Tracker${NC}"
                echo "${GR}=====================${NC}"
                echo "↩️  macOS Diff Tracker"
                show_navigation_prompt
                echo "📝 This menu was made to automate the process of comparing changes to macOS's"
                echo "preference files. After each step completes, simply press Enter to continue on,"
                echo "or press 'b' to go back a step. Instructions will guide you at each step 🚀"
                echo
                echo "💡 This is useful to find the .plists/domains and their key & value pairs for"
                echo "making scripts that automate setting up a new macOS environment/virtual machine."
                echo
                echo "Tracking files get saved to: \"${GR}$BACKUP_DIR${NC}\""
                echo
                echo "A backup folder also gets created here in case you choose not to run a cleanup."
                echo
                echo "${BO}Choose an option:${NC}"
                echo
                echo "1). 🔄 Tracking Loop:"
                echo "    Step 1: 🧹 ${GR}Clean/Initialize Tracking Files${NC} (optional)"
                echo "    Step 2: 📸 ${GR}Capture Before Snapshot${NC} (Make your changes after this)"
                echo "    Step 3. 📸 ${GR}Capture After Snapshot${NC}"
                echo "    Step 4. 🔍 ${GR}Compare Before/After Changes${NC} (continue the loop as needed)"
                # echo "    ${NC}↩️  Continues to Step 1"
                echo "${NC}"
                echo "2). 🗂️  ${BO}Discover All Preference Domains${NC}"
                echo
                
                read -rp "➡️  ${GR}Choose [1-2] (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                handle_navigation_input "$input"
                nav=$?
                if   [[ $nav -eq $NAV_QUIT ]]; then 
                    return 0
                elif [[ $nav -eq $NAV_BACK ]]; then 
                    set_terminal_height_to_512p
                    break
                fi
                
                if   [[ $input == "1" ]]; then 
                    # 🧹 Clean Tracking Files
                    while true; do
                        clear
                        echo "${GR}================================${NC}"
                        echo "${BO}🧹 Clean Tracking Files (Step 1)${NC}"
                        echo "${GR}================================${NC}"
                        echo "↩️  Preference Tracker (Home)"
                        show_navigation_prompt

                        echo "${GR}If this is your first run, press Enter to continue.${NC}"
                        echo
                        echo "${GR}Otherwise:${NC}"
                        echo
                        echo "------------------------------------------------------"
                        echo "${RE}⚠️  Are you sure you want to remove all tracking files?${NC}"
                        echo
                        echo "This will permanently remove the folder located in:" 
                        echo
                        echo "\"${GR}$BACKUP_DIR${NC}\""
                        echo "------------------------------------------------------"
                        echo
                        read -rp "➡️  ${RE}Press (y/n)${GR} or Enter to 📸 Capture Before Snapshot (or ${BL}navigation${NC} ${GR}choice)${NC}: " reply
                        echo
                        
                        handle_navigation_input "$reply"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        # else [[ $nav -eq $NAV_CONT ]] 
                        #     break
                        fi

                        case "$reply" in
                            [Yy])
                                rm -rf "$BACKUP_DIR"
                                echo "${GR}✅ Cleanup Complete.${NC}"
                                sleep 1
                                echo
                                read -rp "➡️  ${GR}Press Enter to 📸 Capture Before Snapshot (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then 
                                    continue
                                fi
                                ;;
                            [Nn])
                                echo "${RE}❌ Cancelled.${NC}"
                                sleep 1
                                echo
                                read -rp "➡️  ${GR}Press Enter to 📸 Capture Before Snapshot (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then 
                                    continue
                                fi
                                ;;
                            "")
                                # echo "📸 Capturing Before Snapshot..."
                                # sleep 1
                                ;;
                            *)
                                echo "${RE}Invalid option. Use y/n or Enter to continue.${NC}"
                                sleep 1
                                continue
                                ;;
                        esac

                        # 📸 Capture Before Snapshot
                        while true; do
                            set_terminal_height_to_1200p
                            clear
                            echo "${GR}===================================${NC}"
                            echo "${BO}📸 Capture Before Snapshot (Step 2)${NC}"
                            echo "${GR}===================================${NC}"
                            echo "↩️  Clean Tracking Files (Step 1)"
                            show_navigation_prompt

                            # pref_backup_session
                            if [ -d "$CURRENT_SESSION" ]; then
                                local backup_name="session_$TIMESTAMP"
                                mv "$CURRENT_SESSION" "$BACKUP_DIR/$backup_name"
                                echo
                                echo "${CY}Previous session backed up to: $BACKUP_DIR/$backup_name${NC}"
                            fi
                            mkdir -p "$CURRENT_SESSION"
                            if capture_preferences "before"; then
                                echo
                                echo "${GR}===================================${NC}"
                                echo "${BO}📸 Capture Before Snapshot (Step 2)${NC}"
                                echo "${GR}===================================${NC}"
                                echo "↩️  Clean Tracking Files (Step 1)"
                                show_navigation_prompt
                                echo "${BO}✅ Before Capture Complete${NC}"
                                echo
                                echo "${GR}📝 Next steps:${NC}"
                                echo "2. Make your preference changes"
                                echo "3. Press Enter to 📸 ${GR}Capture After Snapshot${NC}"
                                echo
                                read -rp "➡️  ${GR}Press Enter to 📸 Capture After Snapshot (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break
                                # else [[ $nav -eq $NAV_CONT ]] 
                                #     return
                                fi
                            else
                                echo
                                echo "${RE}Error occurred during capture${NC}"
                                global_retry
                                continue
                            fi



                            # 📸 Capture After Snapshot
                            while true; do
                                set_terminal_height_to_1200p
                                clear
                                echo "${GR}==================================${NC}"
                                echo "${BO}📸 Capture After Snapshot (Step 3)${NC}"
                                echo "${GR}==================================${NC}"
                                echo "↩️  Capture Before Snapshot (Step 2)"
                                show_navigation_prompt
                                
                                if [ ! -d "$CURRENT_SESSION/before" ]; then
                                    echo "${RE}Error: No 'before' snapshot found. Run 'Capture Before Snapshot' first.${NC}"
                                else
                                    if capture_preferences "after"; then
                                        echo
                                        echo "${GR}==================================${NC}"
                                        echo "${BO}📸 Capture After Snapshot (Step 3)${NC}"
                                        echo "${GR}==================================${NC}"
                                        echo "↩️  Capture Before Snapshot (Step 2)"
                                        show_navigation_prompt
                                        echo "✅ ${BO}After Capture Complete${NC}"
                                        echo
                                        echo "${GR}📝 Next steps:${NC}"
                                        echo "4. Press enter to ${GR}🔍 Compare Before/After Changes${NC}"
                                    else
                                        echo "${RE}Error occurred during capture${NC}"
                                        # sleep 1
                                    fi
                                fi
                                echo
                                read -rp "➡️  ${GR}Press Enter to 🔍 Compare Before/After Changes (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                handle_navigation_input "$input"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then
                                    break
                                # else [[ $nav -eq $NAV_CONT ]] 
                                #     return
                                fi

                                # 🔍 Compare Before/After Changes
                                while true; do
                                    set_terminal_height_to_1200p
                                    clear
                                    echo "${GR}========================================${NC}"
                                    echo "${BO}🔍 Compare Before/After Changes (Step 4)${NC}"
                                    echo "${GR}========================================${NC}"
                                    echo "↩️  Capture After Snapshot (Step 3)"
                                    show_navigation_prompt
                                    if pref_compare_preferences; then
                                        echo
                                        echo "${GR}========================================${NC}"
                                        echo "${BO}🔍 Compare Before/After Changes (Step 4)${NC}"
                                        echo "${GR}========================================${NC}"
                                        echo "↩️  Capture After Snapshot (Step 3)"
                                        show_navigation_prompt
                                        echo "${BO}✅ Comparison Complete${NC}"
                                        echo
                                        echo "📝 Next step:"
                                        echo "1. Press Enter to return to clean up"
                                    else
                                        echo "${RE}Error occurred during comparison${NC}"
                                        echo
                                        read -rp "➡️  ${GR}Press Enter to try again (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                        handle_navigation_input "$input"
                                        nav=$?
                                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                                            return 0
                                        elif [[ $nav -eq $NAV_BACK ]]; then 
                                            break
                                        else [[ $nav -eq $NAV_CONT ]] 
                                            continue
                                        fi
                                    fi
                                    echo
                                    read -rp "➡️  ${GR}Press Enter to return to menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                                    handle_navigation_input "$input"
                                    nav=$?
                                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                                        return 0
                                    elif [[ $nav -eq $NAV_BACK ]]; then 
                                        break
                                    else [[ $nav -eq $NAV_CONT ]] 
                                        break 3
                                    fi
                                done    
                            done
                        done
                    done
                elif [[ $input == "2" ]]; then
                    # 🗂️ Discover All Preference Domains
                    while true; do
                        set_terminal_height_to_1200p
                        clear
                        echo "${GR}==================================${NC}"
                        echo "${BO}🗂️  Discover All Preference Domains${NC}"
                        echo "${GR}==================================${NC}"
                        echo "↩️  Preference Tracker (Home)"
                        show_navigation_prompt
                        pref_show_discovery
                        echo
                        echo "${GR}==================================${NC}"
                        echo "${BO}🗂️  Discover All Preference Domains${NC}"
                        echo "${GR}==================================${NC}"
                        echo "↩️  Preference Tracker (Home)"
                        show_navigation_prompt
                        echo "✅ ${BO}Discovery Complete${NC}"
                        echo
                        read -rp "➡️  ${GR}Press Enter to return to menu (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        else [[ $nav -eq $NAV_CONT ]] 
                            break
                        fi
                    done
                    # set_terminal_height_to_512p
                    
                else
                    echo "${RE}Invalid option. Please choose 1-2.${NC}"
                    sleep 1
                    continue
                fi
            done
        else
            echo "${RE}Invalid option. Please choose 1-2.${NC}"
            sleep 1
            continue
        fi
    done    
    # set_terminal_height_to_512p
}

#====18==== 🧼 Isolation Check
function vm_isolation_check(){
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 18"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}=========================${NC}"
        echo "${BO}🧼 18) VM Isolation Check ${NC}"
        echo "${GR}=========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        echo "${YE}1)${NC} Network Check"
        echo "${YE}2)${NC} Hardware Check"
        echo "${YE}3)${NC} Shared Filesystem Check"
        echo "${YE}4)${NC} Complete Isolation Check (All)"
        echo
        read -p "${GR}Select option [0-4] (or ${BL}navigation${NC} ${GR}choice)${NC}: " choice
        
        handle_navigation_input "$choice"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            break
        # else [[ $nav -eq $NAV_CONT ]] 
        #     break
        fi

        case $choice in
            1) 
                # network_isolation_check
                while true; do
                    clear
                    echo "${GR}================${NC}"
                    echo "${BO}1) Network Check${NC}"
                    echo "${GR}================${NC}"
                    echo "↩️  VM Isolation Check"
                    show_navigation_prompt
                    echo "${CY}Testing internet access...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    curl -I http://1.1.1.1 --max-time 3 2>/dev/null && echo "❌ ${RE}FAIL: Has internet${NC}" || echo "✅ ${GR}PASS: No internet${NC}"
                    echo
                    echo "${CY}Testing DNS...${NC}"
                    
                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    ping -c 1 google.com > /dev/null 2>&1 && echo "❌ ${RE}FAIL: DNS resolves${NC}" || echo "✅ ${GR}PASS: DNS blocked${NC}"
                    echo
                    echo "${CY}Testing local network scan...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local found_lan=false
                    for ip in $(seq 1 5); do
                        # return_to_menu=false
                        # interrupted=false
                        # trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT
                        if ping -c 1 192.168.1.$ip > /dev/null 2>&1; then
                            echo "❌ ${RE}FAIL: Found LAN IP${NC} 192.168.1.$ip"
                            found_lan=true
                            break
                        fi
                    done
                    if [ "$found_lan" = false ]; then
                        echo "✅ ${GR}PASS: No LAN devices found${NC}"
                    fi
                    echo

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 18"; return' SIGINT

                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: " input

                    handle_navigation_input "$input"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break
                    else
                        break
                    fi
                done
                ;;
            2) 
                # hardware_check 
                while true; do
                    clear
                    echo "${GR}=================${NC}"
                    echo "${BO}2) Hardware Check${NC}"
                    echo "${GR}=================${NC}"
                    echo "↩️  VM Isolation Check"
                    show_navigation_prompt
                    echo "${CY}Checking for virtualization...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local virt_found=$(system_profiler SPUSBDataType SPHardwareDataType | grep -iE 'virtual|utm|vmware|spice|redhat|parallels')
                    
                    if [ -n "$virt_found" ]; then
                        echo "✅ ${GR}PASS: Virtualization found${NC}"
                        echo "$virt_found"
                    else
                        echo "❌ ${RE}FAIL: No virtualization found${NC}"
                    fi

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 18"; return' SIGINT

                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: " input

                    handle_navigation_input "$input"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        break
                    else
                        break
                    fi
                done
                ;;
            3) 
                # shared_filesystem_check 
                while true; do
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}==========================${NC}"
                    echo "${BO}3) Shared Filesystem Check${NC}"
                    echo "${GR}==========================${NC}"
                    echo "↩️  VM Isolation Check"
                    show_navigation_prompt
                    echo "${CY}Checking mounted volumes...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local volumes=$(ls /Volumes 2>/dev/null)
                    if [ -n "$volumes" ]; then
                        echo "📁 ${YE}Found volumes:${NC}"
                        echo "$volumes"
                        echo
                        echo "${CY}Mount details:${NC}"
                        mount | grep -i 'Volumes'
                    else
                        echo "✅ ${GR}PASS: No additional volumes found${NC}"
                    fi

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 18"; return' SIGINT

                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: " input

                    handle_navigation_input "$input"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        set_terminal_height_to_512p
                        break
                    else
                        set_terminal_height_to_512p
                        break
                    fi
                done
                ;;
            4) 
                # complete_isolation_check 
                while true; do
                    set_terminal_height_to_1200p
                    clear
                    echo "${GR}===========================${NC}"
                    echo "${BO}4) Complete Isolation Check${NC}"
                    echo "${GR}===========================${NC}"
                    echo "↩️  VM Isolation Check"
                    show_navigation_prompt

                    # Network Check
                    echo "${BO}=== Network Check ===${NC}"
                    echo
                    echo "${CY}Testing internet access...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT
    
                    curl -I http://1.1.1.1 --max-time 3 2>/dev/null && echo "❌ ${RE}FAIL: Has internet${NC}" || echo "✅ ${GR}PASS: No internet${NC}"
                    echo
                    echo "${CY}Testing DNS...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    ping -c 1 google.com > /dev/null 2>&1 && echo "❌ ${RE}FAIL: DNS resolves${NC}" || echo "✅ ${GR}PASS: DNS blocked${NC}"
                    echo
                    echo "${CY}Testing local network scan...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local found_lan=false
                    for ip in $(seq 1 5); do
                        # return_to_menu=false
                        # interrupted=false
                        # trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT
                        if ping -c 1 192.168.1.$ip > /dev/null 2>&1; then
                            echo "❌ ${RE}FAIL: Found LAN IP${NC} 192.168.1.$ip"
                            found_lan=true
                            break
                        fi
                    done

                    if [ "$found_lan" = false ]; then
                        echo "✅ ${GR}PASS: No LAN devices found${NC}"
                    fi

                    # Hardware Check
                    echo
                    echo "${BO}=== Hardware Check ===${NC}"
                    echo
                    echo "${CY}Checking for virtualization...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local virt_found=$(system_profiler SPUSBDataType SPHardwareDataType | grep -iE 'virtual|utm|vmware|spice|redhat|parallels')
    
                    if [ -n "$virt_found" ]; then
                        echo "✅ ${GR}PASS: Virtualization found${NC}"
                        echo "$virt_found"
                    else
                        echo "❌ ${RE}FAIL: No virtualization found${NC}"
                    fi

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 18"; return' SIGINT

                    # Shared Filesystem Check
                    echo
                    echo "${BO}=== Shared Filesystem Check ===${NC}"
                    echo
                    echo "${CY}Checking mounted volumes...${NC}"

                    return_to_menu=false
                    interrupted=false
                    trap 'echo; echo "🛑 ${RE}Interrupted by user.${NC}"; interrupted=true; break' SIGINT

                    local volumes=$(ls /Volumes 2>/dev/null)
                    if [ -n "$volumes" ]; then
                        echo "📁 ${YE}Found volumes:${NC}"
                        echo "$volumes"
                        echo
                        echo "${CY}Mount details:${NC}"
                        mount | grep -i 'Volumes'
                    else
                        echo "✅ ${GR}PASS: No additional volumes found${NC}"
                    fi

                    return_to_menu=true
                    interrupted=false
                    trap 'echo; echo "returning from func 18"; return' SIGINT

                    echo
                    echo "${BO}${CY}=== ISOLATION CHECK COMPLETE ===${NC}"
                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice)${NC}: " input

                    handle_navigation_input "$input"
                    nav=$?
                    if [[ $nav -eq $NAV_QUIT ]]; then
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then
                        set_terminal_height_to_512p
                        break
                    else
                        set_terminal_height_to_512p
                        break
                    fi
                done
                ;;
            *) 
                echo "${RE}Invalid option. Please try again.${NC}"
                sleep 1
                continue
                ;;
        esac
    done
}

#====19==== ⏳ Time Machine Utility
function time_machine_utility() {
    return_to_menu=true
    trap 'echo; echo "Returning to main menu...from func 19"; return_to_menu=true; return' SIGINT

    # Function to convert bytes to human readable format
    bytes_to_human() {
        local bytes=$1
        if [ "$bytes" -ge 1073741824 ]; then
            echo "$(echo "scale=2; $bytes/1073741824" | bc)GB"
        elif [ "$bytes" -ge 1048576 ]; then
            echo "$(echo "scale=2; $bytes/1048576" | bc)MB"
        elif [ "$bytes" -ge 1024 ]; then
            echo "$(echo "scale=2; $bytes/1024" | bc)KB"
        else
            echo "${bytes}B"
        fi
    }

    # Function to get snapshot size
    get_snapshot_size() {
        local snapshot_name=$1
        # Extract date from snapshot name for du command
        local snapshot_date=$(echo "$snapshot_name" | grep -o '[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}-[0-9]\{6\}')
        if [ -n "$snapshot_date" ]; then
            # Use du to estimate size (this is approximate)
            local size_bytes=$(du -s "/.com.apple.timemachine.supported/${snapshot_date}" 2>/dev/null | awk '{print $1}')
            if [ -n "$size_bytes" ]; then
                echo $((size_bytes * 1024))
            else
                echo "Unknown"
            fi
        else
            echo "Unknown"
        fi
    }

    # Entry Point
    while true; do
        clear
        echo "${GR}===========================${NC}"
        echo "${BO}⏳ 19) Time Machine Utility${NC}"
        echo "${GR}===========================${NC}"
        echo "↩️  Main Menu"
        show_navigation_prompt
        echo "${YE}1)${NC} List Local Snapshots"
        echo "${YE}2)${NC} Delete Specific Snapshot"
        echo "${YE}3)${NC} Thin Snapshots (Free Space)"
        echo "${YE}4)${NC} Open tmutil Manual"
        # echo
        # echo "${YE}0)${NC} Back to Main Menu"
        echo
        read -p "${GR}Select option [1-4] (or ${BL}navigation${NC} ${GR}choice)${NC}: " choice
        handle_navigation_input "$choice"
        nav=$?
        if   [[ $nav -eq $NAV_QUIT ]]; then 
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then 
            break
        # else [[ $nav -eq $NAV_CONT ]] 
        #     break
        fi
        
        case $choice in
            1) 
                # list_snapshots
                while true; do
                    clear
                    echo "${GR}==============================${NC}"
                    echo "${BO}1) List Time Machine Snapshots${NC}"
                    echo "${GR}==============================${NC}"
                    echo "↩️  Time Machine Utility"
                    show_navigation_prompt
                    # echo "${BO}${CY}=== TIME MACHINE SNAPSHOTS ===${NC}"
                    # echo
                    
                    local snapshots=$(tmutil listlocalsnapshots / 2>/dev/null)
                    
                    if [ -z "$snapshots" ]; then
                        echo "${YE}No local Time Machine snapshots found.${NC}"
                        echo
                        read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        else [[ $nav -eq $NAV_CONT ]]
                            break
                        fi

                        # break
                        # return
                    fi
                    
                    echo "${GR}Loading snapshot information...${NC}"
                    echo
                    
                    # Header
                    printf "${BO}%-2s %-20s %-8s %s${NC}\n" "#" "DATE/TIME" "SIZE" "SNAPSHOT NAME"
                    echo "────────────────────────────────────────────────────────────────────────────────"
                    
                    local counter=1
                    echo "$snapshots" | while IFS= read -r snapshot; do
                        if [ -n "$snapshot" ]; then
                            # Extract readable date from snapshot name
                            local date_part=$(echo "$snapshot" | grep -o '[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}-[0-9]\{6\}')
                            if [ -n "$date_part" ]; then
                                local readable_date="${date_part:0:4}-${date_part:5:2}-${date_part:8:2} ${date_part:11:2}:${date_part:13:2}:${date_part:15:2}"
                            else
                                local readable_date="Unknown"
                            fi
                            
                            # Get approximate size (this is challenging with local snapshots)
                            local size_display="${YE}N/A     ${NC}"
                            
                            printf "${GR}%-2s${NC} %-20s %-10s %s\n" "$counter" "$readable_date" "$size_display" "$snapshot"
                            counter=$((counter + 1))
                        fi
                    done
                    
                    echo
                    echo "${YE}Note: Snapshot sizes are estimates and may not reflect actual disk usage.${NC}"
                    echo "${YE}Use 'tmutil listlocalsnapshots -s /' for more detailed size information.${NC}"
                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                    handle_navigation_input "$input"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break
                    else [[ $nav -eq $NAV_CONT ]]
                        break
                    fi   
                done
                ;;
            2) 
                # delete_snapshot
                while true; do
                    clear
                    echo "${GR}================================${NC}"
                    echo "${BO}2) Delete Time Machine Snapshots${NC}"
                    echo "${GR}================================${NC}"
                    echo "↩️  Time Machine Utility"
                    show_navigation_prompt

                    # echo "${BO}${CY}=== DELETE TIME MACHINE SNAPSHOT ===${NC}"
                    # echo
                    
                    local snapshots=$(tmutil listlocalsnapshots / 2>/dev/null)
                    
                    if [ -z "$snapshots" ]; then
                        echo "${YE}No local Time Machine snapshots found to delete.${NC}"
                        echo
                        read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        # else [[ $nav -eq $NAV_CONT ]]
                        #     break
                        fi   
                        # return
                    fi
                    
                    echo "${GR}Available snapshots:${NC}"
                    echo
                    
                    local counter=1
                    local snapshot_array=()
                    
                    echo "$snapshots" | while IFS= read -r snapshot; do
                        if [ -n "$snapshot" ]; then
                            local date_part=$(echo "$snapshot" | grep -o '[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}-[0-9]\{6\}')
                            if [ -n "$date_part" ]; then
                                local readable_date="${date_part:0:4}-${date_part:5:2}-${date_part:8:2} ${date_part:11:2}:${date_part:13:2}:${date_part:15:2}"
                            else
                                local readable_date="Unknown"
                            fi
                            printf "${GR}%2s)${NC} %s ${BL}(%s)${NC}\n" "$counter" "$readable_date" "$snapshot"
                            counter=$((counter + 1))
                        fi
                    done > /tmp/snapshot_list
                    
                    cat /tmp/snapshot_list
                    
                    # Store snapshots in array for selection
                    counter=1
                    while IFS= read -r snapshot; do
                        if [ -n "$snapshot" ]; then
                            snapshot_array[$counter]="$snapshot"
                            counter=$((counter + 1))
                        fi
                    done <<< "$snapshots"
                    
                    # echo
                    # echo "${YE}0)${NC} Back to menu"
                    echo
                    read -p "${GR}Select snapshot to delete [1-$((counter-1))] (or ${BL}navigation${NC} ${GR}choice${NC}): " choice
                    
                    handle_navigation_input "$choice"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break
                    # else [[ $nav -eq $NAV_CONT ]]
                    #     break
                    fi   

                    # if [ "$choice" = "0" ]; then
                    #     return
                    # fi

                    # integer issue needs fixing here?
                    while true; do
                        if [ "$choice" -ge 1 ] && [ "$choice" -lt "$counter" ]; then
                            local selected_snapshot="${snapshot_array[$choice]}"
                            echo
                            echo "${RE}WARNING: This will permanently delete the selected snapshot!${NC}"
                            echo "${GR}Snapshot: $selected_snapshot${NC}"
                            echo
                            read -p "${YE}Are you sure? (yes/no): ${NC}" confirm

                            handle_navigation_input "$confirm"
                            nav=$?
                            if   [[ $nav -eq $NAV_QUIT ]]; then 
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then 
                                break
                            # else [[ $nav -eq $NAV_CONT ]]
                            #     break
                            fi   
                            
                            if [ "$confirm" = "yes" ]; then
                                echo
                                echo "${GR}Deleting snapshot...${NC}"

                                if sudo tmutil deletelocalsnapshots "$selected_snapshot"; then
                                    echo "${GR}✅ Snapshot deleted successfully!${NC}"
                                else
                                    echo "${RE}❌ Failed to delete snapshot.${NC}"
                                    sleep 1
                                    break
                                fi
                            else
                                echo "${YE}Deletion cancelled.${NC}"
                                sleep 1
                                break
                            fi
                        else
                            echo "${RE}Invalid selection.${NC}"
                            sleep 1
                            break
                        fi

                        echo
                        read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        # else [[ $nav -eq $NAV_CONT ]]
                        #     break
                        fi   
                        # rm -f /tmp/snapshot_list
                        echo "would be removing /tmp/snapshot_list"
                        sleep 1
                        echo "done"

                        read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                        handle_navigation_input "$input"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        else [[ $nav -eq $NAV_CONT ]]
                            break
                        fi
                    done
                done       
                ;;
            3) 
                # thin_snapshots
                while true; do
                    # set_terminal_height_to_1200p
                    clear
                    echo "${GR}==============================${NC}"
                    echo "${BO}3) Thin Time Machine Snapshots${NC}"
                    echo "${GR}==============================${NC}"
                    echo "↩️  Time Machine Utility"
                    show_navigation_prompt
                    # echo "${BO}${CY}=== THIN TIME MACHINE SNAPSHOTS ===${NC}"
                    # echo
                    echo "${GR}This will thin local snapshots to reclaim disk space.${NC}"
                    echo "${YE}Thinning removes older snapshots automatically based on urgency level.${NC}"
                    echo
                    
                    # Show current disk usage
                    echo "${GR}Current disk usage:${NC}"
                    df -h / | tail -1 | awk '{printf "Used: %s/%s (%s full)\n", $3, $2, $5}'
                    echo
                    
                    echo "${GR}In the next steps, you'll be guided through the following:${NC}"
                    echo
                    echo "- Purge Amount"
                    echo "- Urgency Level"
                    echo "- Confirmation"
                    echo "- Summary"
                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input

                    handle_navigation_input "$input"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break
                    # else [[ $nav -eq $NAV_CONT ]]
                    #     break
                    fi

                    while true; do
                        clear
                        echo "${GR}===================${NC}"
                        echo "${BO}Select Purge Amount${NC}"
                        echo "${GR}===================${NC}"
                        echo "↩️  Thin Time Machine Snapshots"
                        show_navigation_prompt
                        echo "${GR}Purge Amount Options:${NC}"
                        echo "${YE}1)${NC} 1GB"
                        echo "${YE}2)${NC} 5GB"
                        echo "${YE}3)${NC} 10GB"
                        echo "${YE}4)${NC} 20GB"
                        echo "${YE}5)${NC} Custom amount"
                        echo "${YE}6)${NC} Auto (let system decide)"
                        # echo
                        # echo "${YE}0)${NC} Back to menu"
                        echo
                        read -p "${GR}Select purge amount [1-6] (or ${BL}navigation${NC} ${GR}choice${NC}): " choice

                        handle_navigation_input "$choice"
                        nav=$?
                        if   [[ $nav -eq $NAV_QUIT ]]; then 
                            return 0
                        elif [[ $nav -eq $NAV_BACK ]]; then 
                            break
                        # else [[ $nav -eq $NAV_CONT ]]
                        #     break
                        fi   
                        
                        case $choice in
                            1) purge_amount="1073741824" ;; # 1GB in bytes
                            2) purge_amount="5368709120" ;; # 5GB
                            3) purge_amount="10737418240" ;; # 10GB
                            4) purge_amount="21474836480" ;; # 20GB
                            5) 
                                # while true; do
                                clear
                                echo "${GR}===================${NC}"
                                echo "${BO}Custom Purge Amount${NC}"
                                echo "${GR}===================${NC}"
                                echo "↩️  Select Purge Amount"
                                show_navigation_prompt
                                
                                # Show current disk usage
                                echo "${GR}Current disk usage:${NC}"
                                df -h / | tail -1 | awk '{printf "Used: %s/%s (%s full)\n", $3, $2, $5}'
                                echo

                                read -p "${GR}Enter amount in GB: ${NC}" custom_gb
                                handle_navigation_input "$custom_gb"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then 
                                    continue
                                # else [[ $nav -eq $NAV_CONT ]]
                                #     break
                                fi
                                
                                if [[ "$custom_gb" =~ ^[0-9]+$ ]]; then
                                    echo "would be purging $custom_gb"
                                    # purge_amount=$((custom_gb * 1073741824))
                                else
                                    echo "${RE}Invalid input. Using 1GB default.${NC}"
                                    # purge_amount="1073741824"
                                fi
                                # done
                                ;;
                            6) 
                                # Auto mode
                                echo "would be purging an auto-amount"
                                # purge_amount=""
                                ;;
                            *) 
                                echo "${RE}Invalid selection.${NC}"
                                sleep 1
                                continue
                                ;;
                        esac

                        while true; do
                            clear
                            echo "${GR}====================${NC}"
                            echo "${BO}Select Urgency Level${NC}"
                            echo "${GR}====================${NC}"
                            echo "↩️  Select Purge Amount"
                            show_navigation_prompt
                            echo "${GR}Urgency Level (1=low, 4=aggressive):${NC}"
                            echo "${YE}1)${NC} Low urgency (preserve more snapshots)"
                            echo "${YE}2)${NC} Medium-low urgency"
                            echo "${YE}3)${NC} Medium-high urgency"
                            echo "${YE}4)${NC} High urgency (aggressive thinning)"
                            echo "${YE}5)${NC} Default urgency"
                            echo
                            read -p "${GR}Select urgency level [1-5]: ${NC}" urgency_choice
                            
                            handle_navigation_input "$urgency_choice"
                            nav=$?
                            if   [[ $nav -eq $NAV_QUIT ]]; then 
                                return 0
                            elif [[ $nav -eq $NAV_BACK ]]; then 
                                break
                            # else [[ $nav -eq $NAV_CONT ]]
                            #     break
                            fi   

                            while true; do
                                case $urgency_choice in
                                    1) urgency="1" ;;
                                    2) urgency="2" ;;
                                    3) urgency="3" ;;
                                    4) urgency="4" ;;
                                    5) urgency="" ;; # Default
                                    *) urgency="2" ;; # Default to medium-low
                                esac

                            # while true; do
                                echo
                                echo "${RE}WARNING: This will permanently delete older snapshots!${NC}"
                                echo "${GR}This action cannot be undone.${NC}"
                                echo
                                read -p "${YE}Continue with thinning? (yes/no): ${NC}" confirm

                                handle_navigation_input "$confirm"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then 
                                    break
                                # else [[ $nav -eq $NAV_CONT ]]
                                #     break
                                fi   

                                # while true; do
                                if [ "$confirm" = "yes" ]; then
                                    clear
                                    echo "${GR}====================${NC}"
                                    echo "${BO}Thinning Snapshot${NC}"
                                    echo "${GR}====================${NC}"
                                    echo "↩️  Select Urgency Level"
                                    show_navigation_prompt
                                    echo "${GR}Thinning snapshots... This may take several minutes.${NC}"
                                    echo
                                    # Show current disk usage
                                    echo "${GR}Current disk usage:${NC}"
                                    df -h / | tail -1 | awk '{printf "Used: %s/%s (%s full)\n", $3, $2, $5}'
                                    echo
                                    # Build tmutil command
                                    # local cmd="sudo tmutil thinlocalsnapshots /"
                                    # if [ -n "$purge_amount" ]; then
                                    #     # echo "would be executing cmd purge_amount"
                                    #     cmd="$cmd $purge_amount"
                                    # fi
                                    # if [ -n "$urgency" ]; then
                                    #     # echo "would be executing cmd urgency"
                                    #     cmd="$cmd $urgency"
                                    # fi
                                    
                                    # echo "${CY}Running: $cmd${NC}"
                                    # echo
                                    
                                    if [ $? -eq 0 ]; then
                                    # if eval "$cmd"; then
                                        echo
                                        echo "${GR}✅ Snapshot thinning completed successfully!${NC}"
                                        echo
                                        echo "${CY}Updated disk usage:${NC}"
                                        df -h / | tail -1 | awk '{printf "Used: %s/%s (%s full)\n", $3, $2, $5}'
                                    else
                                        echo
                                        echo "${RE}❌ Snapshot thinning failed or was interrupted.${NC}"
                                        sleep 1
                                        # break
                                    fi
                                else
                                    echo "${YE}Thinning cancelled.${NC}"
                                    sleep 1
                                    break
                                fi
                                
                                echo
                                read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                                handle_navigation_input "$input"
                                nav=$?
                                if   [[ $nav -eq $NAV_QUIT ]]; then 
                                    return 0
                                elif [[ $nav -eq $NAV_BACK ]]; then 
                                    break
                                # else [[ $nav -eq $NAV_CONT ]]
                                #     break
                                fi
                                #     done
                                # done
                            done
                        done
                    done
                done
                ;;
            4) 
                # open_man_page
                while true; do
                    clear
                    echo "${GR}================${NC}"
                    echo "${BO}4) tmutil Manual${NC}"
                    echo "${GR}================${NC}"
                    echo "↩️  Time Machine Utility"
                    show_navigation_prompt

                    # echo "${BO}${CY}=== TIME MACHINE MANUAL ===${NC}"
                    # echo
                    echo "${GR}Opening tmutil man page...${NC}"
                    echo "${YE}Press 'q' to quit the manual and return to menu.${NC}"
                    echo
                    read -p "${GR}Press Enter to continue (or ${BL}navigation${NC} ${GR}choice${NC}): " input
                    handle_navigation_input "$input"
                    nav=$?
                    if   [[ $nav -eq $NAV_QUIT ]]; then 
                        return 0
                    elif [[ $nav -eq $NAV_BACK ]]; then 
                        break
                    # else [[ $nav -eq $NAV_CONT ]]
                    #     break
                    fi
                    set_terminal_height_to_1200p
                    man tmutil
                    set_terminal_height_to_512p
                done
                ;;
            *) 
                echo "${RE}Invalid option. Please try again.${NC}"
                sleep 1
                continue
                ;;
        esac
    done
}

#====20==== 📝 ChangeLog
function change_log() {
    set_terminal_height_to_1200p
    while true; do
        return_to_menu=true
        trap 'echo; echo "Returning to main menu...from func 18"; return_to_menu=true; return' SIGINT
        clear
        echo "${GR}===========================${NC}"
        echo "${BO}20) 📝 OneCommand ChangeLog${NC} ${CY}[For the latest updates, visit shop.ryansummer.com]${NC}"
        echo "${GR}===========================${NC}                    ${BL}Coming Soon${NC}                     "
        echo
        echo "${BO}Beta v0.5.0 - 09/12-2025${NC}"
        echo "- Added a 'User Account Details' option to menu item: 12) ℹ️  System Information'"
        echo
        echo "${BO}Beta v0.4.0 - 09/04-2025${NC}"
        echo "- Added 2 new menu options/functions:"
        echo "    🧼 VM Isolation Check: (check VM leakage for testing untrusted software)"
        echo "    ⏳ Time Machine Utility: (view, delete and thin local snapshots)"
        echo "- Fine-tuned all traps for interrupting sudo password prompts, etc."
        echo "- Removed 'fn ⬆️  Page Up | fn ⬇️  Page Down | ^C Quit' from the navigation bar"
        echo "- Added '^C Interrupt/Exit | Q Main Menu' to the navigation bar"
        echo "- Added '↩️  Main Menu' under each menu item header"
        echo "- Added '↩️  <Previous Step>' under most sub menu headers"
        echo "    ${YE}(This helps better understand what pressing 'b' will go back to).${NC}"
        echo
        echo "${BO}Beta v0.3.0 - 08/30/2025${NC}"
        echo "- Added 4 new menu options/functions:"
        echo "    📝 OneCommand ChangeLog: (Built in changeLog for this script)"
        echo "    💿 Create Disk Image: (create/resize/password protect disk images)"
        echo "    🍏 Create macOS Installer: (create a bootable macOS installer)"
        echo "    ⚙️  macOS Diff Tracker: (compare differences/changes in the file system)"
        echo "- Added over 100+ more customizations to ⚙️  MacOS Defaults (175 in total!)"
        echo "- Added 'fn ⬆️  Page Up | fn ⬇️  Page Down' to the navigation bar"
        echo
        echo "${BO}Beta v0.2.0 - 08/07/2025${NC}"
        echo "- Added 6 new menu options/functions:"
        echo "    📊 Activity Monitor (Top): (a CLI activity monitor)"
        echo "    📡 Speed Test: (a CLI speed test)"
        echo "    🔄 iCloud Sync Refresh: (for forcing iCloud sync)"
        echo "    ℹ️  System Information: (displays a more complete system profile overview)"
        echo "    🌐 DNS Utility: (for testing, showing or flushing DNS settings)"
        echo "    ⚙️  MacOS Defaults: (contains over 75+ customizations)"
        echo "- Condensed the Navigation controls to 1 line instead of 4"
        echo "- Updated some menu option emojis to better represent their functions"
        echo
        echo "${BO}Beta v0.1.0 - 7/27/2025${NC}"
        echo "- Public Beta"

        show_navigation_prompt # already padded
        read -rp "➡️  ${GR}Press Enter to get latest version (or ${BL}navigation${NC} ${GR}choice)${NC}: " input
        handle_navigation_input "$input"
        nav=$?
        if [[ $nav -eq $NAV_QUIT ]]; then
            return 0
        elif [[ $nav -eq $NAV_BACK ]]; then
            break # back to main menu
        else # [[ $nav -eq $NAV_CONT ]]
            open https://shop.ryansummer.com
            # break # restart operation selection
        fi
    done    
}

# Script entry point
main_menu
# intentionally left blank